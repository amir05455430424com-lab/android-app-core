package com.emir.englishapp.domain.model

data class PhraseCategory(
    val key: String,
    val titleEn: String,
    val titleAr: String,
    val order: Int,
    val icon: String
)
