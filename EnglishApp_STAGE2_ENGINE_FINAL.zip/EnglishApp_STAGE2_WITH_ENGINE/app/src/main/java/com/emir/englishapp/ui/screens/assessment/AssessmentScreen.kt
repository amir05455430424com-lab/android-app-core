package com.emir.englishapp.ui.screens.assessment

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.emir.englishapp.domain.model.exercise.ExerciseTemplate
import com.emir.englishapp.domain.model.exercise.LearningModality
import com.emir.englishapp.ui.widgets.character.CharacterMood
import com.emir.englishapp.ui.widgets.character.LearningCharacterBanner

// ─────────────────────────────────────────────────────────────
// Colors
// ─────────────────────────────────────────────────────────────
private val Green = Color(0xFF58CC02)
private val GreenDark = Color(0xFF46A302)
private val GreenLight = Color(0xFFD7FFB8)
private val Red = Color(0xFFEA2B2B)
private val RedLight = Color(0xFFFFDFE0)
private val Blue = Color(0xFF1CB0F6)
private val AudioOrange = Color(0xFFFF9600)
private val TextDark = Color(0xFF4B4B4B)
private val TextMuted = Color(0xFFAFAFAF)

// ─────────────────────────────────────────────────────────────
// Root screen
// ─────────────────────────────────────────────────────────────

@Composable
fun AssessmentScreen(
    viewModel: AssessmentViewModel,
    onBack: () -> Unit,
    onSessionComplete: (SessionResultUi) -> Unit,
) {
    val state by viewModel.uiState.collectAsState()

    // Navigate to reward screen when result is ready
    state.result?.let { result ->
        onSessionComplete(result)
        return
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
            .statusBarsPadding()
            .navigationBarsPadding(),
    ) {
        when {
            state.isLoading -> LoadingView()
            state.error != null -> ErrorView(error = state.error!!, onRetry = {
                viewModel.onEvent(AssessmentEvent.RestartSession)
            })
            else -> SessionContent(
                state = state,
                onEvent = viewModel::onEvent,
                onBack = onBack,
            )
        }
    }
}

// ─────────────────────────────────────────────────────────────
// Session content
// ─────────────────────────────────────────────────────────────

@Composable
private fun SessionContent(
    state: AssessmentUiState,
    onEvent: (AssessmentEvent) -> Unit,
    onBack: () -> Unit,
) {
    val snap = state.snapshot

    Column(modifier = Modifier.fillMaxSize()) {

        // ── 1. Top Bar ─────────────────────────────────────────
        TopBar(
            progress = snap.progressFraction,
            correctCount = snap.correctCount,
            streakCount = snap.streakCorrect,
            isFavourite = snap.currentExercise?.id in state.favoriteIds,
            onClose = onBack,
            onFavourite = { onEvent(AssessmentEvent.ToggleFavourite) },
        )

        // ── 2. Scrollable exercise area ─────────────────────────
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp),
        ) {
            Spacer(Modifier.height(12.dp))

            // Character banner (mood adapts to feedback)
            LearningCharacterBanner(
                mood = when {
                    snap.isAnswered && snap.isCorrect == true -> CharacterMood.HAPPY
                    snap.isAnswered && snap.isCorrect == false -> CharacterMood.ENCOURAGE
                    snap.shouldInsertReview -> CharacterMood.THINKING
                    else -> CharacterMood.IDLE
                },
                message = exercisePrompt(snap.currentExercise),
                bubbleText = null,
            )

            Spacer(Modifier.height(20.dp))

            // Question transition animation
            AnimatedContent(
                targetState = snap.currentIndex,
                transitionSpec = {
                    (fadeIn(tween(220)) + slideInVertically { it / 6 }) togetherWith
                    (fadeOut(tween(140)) + slideOutVertically { -it / 6 })
                },
                label = "exercise_transition",
            ) {
                ExerciseScreenEngine(state = state, onEvent = onEvent)
            }

            Spacer(Modifier.height(100.dp)) // breathing room above feedback panel
        }

        // ── 3. Feedback panel + action button ──────────────────
        FeedbackPanel(
            snap = snap,
            showExplanation = state.showExplanation,
            onNext = { onEvent(AssessmentEvent.Next) },
            onToggleExplanation = { onEvent(AssessmentEvent.ToggleExplanation) },
        )
    }
}

// ─────────────────────────────────────────────────────────────
// Top bar with progress
// ─────────────────────────────────────────────────────────────

@Composable
private fun TopBar(
    progress: Float,
    correctCount: Int,
    streakCount: Int,
    isFavourite: Boolean,
    onClose: () -> Unit,
    onFavourite: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconButton(onClick = onClose) {
            Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = TextMuted)
        }

        LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier
                .weight(1f)
                .height(14.dp)
                .padding(horizontal = 6.dp),
            color = Green,
            trackColor = Color(0xFFE5E5E5),
            strokeCap = StrokeCap.Round,
        )

        // XP score display
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                Icons.Default.Star,
                contentDescription = null,
                tint = Color(0xFFFFC107),
                modifier = Modifier.size(22.dp),
            )
            Text(
                text = correctCount.toString(),
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(start = 3.dp, end = 4.dp),
                color = TextDark,
            )
        }

        if (streakCount >= 3) {
            Text(
                text = "🔥$streakCount",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 4.dp),
            )
        }

        IconButton(onClick = onFavourite) {
            Icon(
                if (isFavourite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                contentDescription = "مفضلة",
                tint = if (isFavourite) Red else TextMuted,
            )
        }
    }
}

// ─────────────────────────────────────────────────────────────
// Feedback panel (slides up from bottom after answer)
// ─────────────────────────────────────────────────────────────

@Composable
private fun FeedbackPanel(
    snap: com.emir.englishapp.domain.engine.SessionOrchestrator.SessionSnapshot,
    showExplanation: Boolean,
    onNext: () -> Unit,
    onToggleExplanation: () -> Unit,
) {
    AnimatedVisibility(
        visible = snap.isAnswered,
        enter = slideInVertically(tween(280)) { it },
        exit = slideOutVertically(tween(200)) { it },
    ) {
        val isCorrect = snap.isCorrect == true
        val panelBg = if (isCorrect) GreenLight else RedLight
        val accentColor = if (isCorrect) Green else Red
        val accentDark = if (isCorrect) GreenDark else Color(0xFFC42525)
        val emoji = if (isCorrect) "✅" else "❌"
        val title = if (isCorrect) "إجابة صحيحة!" else "إجابة خاطئة"

        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = panelBg,
            shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
        ) {
            Column(
                modifier = Modifier.padding(horizontal = 24.dp, vertical = 20.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(text = emoji, fontSize = 24.sp)
                    Spacer(Modifier.size(10.dp))
                    Text(
                        text = title,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = accentColor,
                    )
                }

                // Explanation (collapsible)
                snap.feedbackText?.let { feedback ->
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = feedback,
                        fontSize = 15.sp,
                        color = TextDark,
                        fontWeight = FontWeight.Medium,
                    )
                }

                Spacer(Modifier.height(16.dp))

                // Next / Continue button
                Button(
                    onClick = onNext,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = accentColor),
                ) {
                    Text(
                        text = if (snap.currentIndex + 1 >= snap.totalCount) "عرض النتائج" else "التالي ←",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White,
                    )
                }
            }
        }
    }

    // Floating continue button when not yet answered (for non-auto-confirm types)
    AnimatedVisibility(
        visible = !snap.isAnswered,
        enter = fadeIn(),
        exit = fadeOut(),
    ) {
        // Empty spacer so layout doesn't shift — no action button shown until answered
        Spacer(Modifier.height(0.dp))
    }
}

// ─────────────────────────────────────────────────────────────
// Loading / Error states
// ─────────────────────────────────────────────────────────────

@Composable
private fun LoadingView() {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            CircularProgressIndicator(color = Green, modifier = Modifier.size(48.dp))
            Text(
                text = "جارٍ تحضير التمارين...",
                fontSize = 17.sp,
                color = TextMuted,
                fontWeight = FontWeight.Medium,
            )
        }
    }
}

@Composable
private fun ErrorView(error: String, onRetry: () -> Unit) {
    Box(modifier = Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(20.dp),
        ) {
            Text(text = "⚠️", fontSize = 48.sp)
            Text(
                text = error,
                fontSize = 15.sp,
                color = TextDark,
                textAlign = TextAlign.Center,
            )
            Button(
                onClick = onRetry,
                colors = ButtonDefaults.buttonColors(containerColor = Green),
                shape = RoundedCornerShape(14.dp),
            ) {
                Text("حاول مرة أخرى", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────
// Helper: derive character prompt from current exercise type
// ─────────────────────────────────────────────────────────────

private fun exercisePrompt(ex: ExerciseTemplate?): String = when (ex) {
    is ExerciseTemplate.TranslateEnToAr   -> "ترجم إلى العربية"
    is ExerciseTemplate.TranslateArToEn   -> "ترجم إلى الإنجليزية"
    is ExerciseTemplate.FillBlank         -> "أكمل الفراغ"
    is ExerciseTemplate.SentenceReorder   -> "رتّب الكلمات"
    is ExerciseTemplate.SpotTheError      -> "حدّد الخطأ"
    is ExerciseTemplate.MatchPairs        -> "طابق الكلمات"
    is ExerciseTemplate.DictationReorder  -> "استمع ورتّب"
    is ExerciseTemplate.ListenAndPick     -> "استمع واختر"
    is ExerciseTemplate.TypeWhatYouHear   -> "اسمع واختر الكلمة"
    is ExerciseTemplate.SentenceComplete  -> "أكمل الجملة"
    is ExerciseTemplate.WordSort          -> "صنّف الكلمات"
    is ExerciseTemplate.PronunciationBridge -> "اختر النطق"
    null -> "اختر الإجابة الصحيحة"
}
