package com.emir.englishapp.ui.screens.path

import com.emir.englishapp.domain.model.course.CourseUnit

data class PathUiState(
    val isLoading: Boolean = true,
    val error: String? = null,
    val currentUnitGlobalIndex: Int = 1,
    val units: List<CourseUnitUi> = emptyList()
)

data class CourseUnitUi(
    val unit: CourseUnit,
    val status: UnitStatus,
    val stepIndex: Int, // 0..stepsTotal (completed steps)
    val stepsTotal: Int
)

enum class UnitStatus { Locked, Current, Completed }
