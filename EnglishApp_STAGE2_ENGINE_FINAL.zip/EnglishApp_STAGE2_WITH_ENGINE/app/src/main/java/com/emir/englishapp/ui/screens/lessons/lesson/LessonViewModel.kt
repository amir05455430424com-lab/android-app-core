package com.emir.englishapp.ui.screens.lessons.lesson

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.emir.englishapp.data.repository.AppRepository
import com.emir.englishapp.domain.model.lesson.CardItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class LessonUiState(
    val isLoading: Boolean = true,
    val title: String = "",
    val cards: List<CardItem> = emptyList(),
    val index: Int = 0,
    val isFinished: Boolean = false,
    val error: String? = null
)

class LessonViewModel(
    private val repo: AppRepository,
    val levelId: Int,
    val lessonId: String
) : ViewModel() {

    private val _uiState = MutableStateFlow(LessonUiState())
    val uiState: StateFlow<LessonUiState> = _uiState.asStateFlow()

    fun load() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, error = null)
            runCatching { repo.getLessonLevel(levelId) }
                .onSuccess { level ->
                    if (level == null) {
                        _uiState.value = LessonUiState(isLoading = false, error = "لم يتم العثور على المستوى")
                        return@onSuccess
                    }

                    var foundTitle = ""
                    var foundCards: List<CardItem> = emptyList()

                    outer@ for (unit in level.units) {
                        for (lesson in unit.lessons) {
                            if (lesson.lessonId == lessonId) {
                                foundTitle = lesson.titleAr.ifBlank { unit.titleAr }
                                foundCards = normalizeCards(lesson.cards)
                                break@outer
                            }
                        }
                    }

                    if (foundCards.isEmpty()) {
                        _uiState.value = LessonUiState(isLoading = false, error = "لم يتم العثور على الدرس أو لا يوجد محتوى")
                        return@onSuccess
                    }

                    val key = "$levelId|$lessonId"
                    val savedIndex = repo.getLessonStepIndex(key).coerceIn(0, (foundCards.size - 1).coerceAtLeast(0))

                    _uiState.value = LessonUiState(
                        isLoading = false,
                        title = foundTitle,
                        cards = foundCards,
                        index = savedIndex
                    )
                }
                .onFailure { e ->
                    _uiState.value = LessonUiState(isLoading = false, error = e.message ?: "خطأ غير معروف")
                }
        }
    }

    fun next() {
        val state = _uiState.value
        val nextIndex = state.index + 1
        if (nextIndex >= state.cards.size) {
            _uiState.value = state.copy(isFinished = true)
            viewModelScope.launch {
                repo.addCompletedLessonId(levelId, lessonId)
                repo.setLessonStepIndex("$levelId|$lessonId", state.cards.size)
                // Unlock next lesson in global order (flattened list)
                val level = repo.getLessonLevel(levelId)
                if (level != null) {
                    val flat = buildList {
                        level.units.forEach { u -> u.lessons.forEach { add(it.lessonId) } }
                    }
                    val myIndex = flat.indexOf(lessonId)
                    val unlocked = repo.getUnlockedLessonIndex(levelId)
                    if (myIndex >= 0 && myIndex >= unlocked) {
                        repo.setUnlockedLessonIndex(levelId, myIndex + 1)
                    }
                }
            }
        } else {
            _uiState.value = state.copy(index = nextIndex)
            viewModelScope.launch {
                repo.setLessonStepIndex("$levelId|$lessonId", nextIndex)
            }
        }
    }

    fun prev() {
        val state = _uiState.value
        val prev = (state.index - 1).coerceAtLeast(0)
        _uiState.value = state.copy(index = prev)
        viewModelScope.launch {
            repo.setLessonStepIndex("$levelId|$lessonId", prev)
        }
    }

    private fun normalizeCards(cards: List<CardItem>): List<CardItem> {
        // Ensure type always present so UI can render safely
        return cards.map { it.copy(type = it.type.ifBlank { "text" }) }
    }

    init {
        load()
    }
}
