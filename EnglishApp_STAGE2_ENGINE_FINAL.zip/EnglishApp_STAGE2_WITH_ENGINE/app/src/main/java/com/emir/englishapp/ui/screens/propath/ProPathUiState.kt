package com.emir.englishapp.ui.screens.propath

import com.emir.englishapp.ui.screens.path.CourseUnitUi

data class ProPathUiState(
    val isLoading: Boolean = true,
    val error: String? = null,
    val currentUnitGlobalIndex: Int = 1,
    val units: List<CourseUnitUi> = emptyList()
)
