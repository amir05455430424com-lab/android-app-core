package com.emir.englishapp.ui.screens.proquestion

sealed interface ProQuestionEvent {
    data class SelectOption(val index: Int) : ProQuestionEvent
    data class PickWord(val word: String) : ProQuestionEvent
    data class UnpickWord(val word: String) : ProQuestionEvent
    object Confirm : ProQuestionEvent
    object Next : ProQuestionEvent
}
