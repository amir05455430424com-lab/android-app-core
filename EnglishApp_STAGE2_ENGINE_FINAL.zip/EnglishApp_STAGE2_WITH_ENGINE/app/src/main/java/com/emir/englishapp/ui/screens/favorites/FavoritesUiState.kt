package com.emir.englishapp.ui.screens.favorites

import com.emir.englishapp.domain.model.question.Question
import com.emir.englishapp.domain.model.PhraseItem

data class FavoriteLessonEntry(
    val key: String, // "levelId|lessonId"
    val titleAr: String,
    val titleEn: String
)

data class FavoritesUiState(
    val isLoading: Boolean = true,
    val error: String? = null,
    val favoriteQuestions: List<Question> = emptyList(),
    val favoritePhrases: List<PhraseItem> = emptyList(),
    val favoriteLessons: List<FavoriteLessonEntry> = emptyList()
)
