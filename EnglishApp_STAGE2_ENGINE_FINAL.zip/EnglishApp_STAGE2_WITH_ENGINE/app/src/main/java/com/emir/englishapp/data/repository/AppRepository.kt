package com.emir.englishapp.data.repository

import com.emir.englishapp.domain.model.PhraseCategory
import com.emir.englishapp.domain.model.PhraseItem
import com.emir.englishapp.domain.model.course.CourseCurriculum
import com.emir.englishapp.domain.model.course.CourseUnit
import com.emir.englishapp.domain.model.daily.DailySummary
import com.emir.englishapp.domain.model.lesson.LevelMeta
import com.emir.englishapp.domain.model.lesson.LessonLevel
import com.emir.englishapp.domain.model.question.Question
import com.emir.englishapp.domain.model.questionv2.QuestionV2
import kotlinx.coroutines.flow.Flow

interface AppRepository {
    // ===== Progress (existing) =====
    val momentum: Flow<Int>
    val currentUnitGlobalIndex: Flow<Int>

    // ===== Stage 4 high-level stats (for Smart Home) =====
    val totalXp: Flow<Int>
    val dailyXpToday: Flow<Int>
    val streakDays: Flow<Int>

    // ===== Favorites =====
    val favoriteQuestionIds: Flow<Set<String>>
    suspend fun toggleFavoriteQuestion(id: String)

    val favoritePhraseIds: Flow<Set<String>>
    suspend fun toggleFavoritePhrase(id: String)

    val favoriteLessonIds: Flow<Set<String>>
    suspend fun toggleFavoriteLesson(id: String)

    suspend fun setMomentum(value: Int)
    suspend fun setCurrentUnitGlobalIndex(value: Int)

    // Raw assets helper
    suspend fun readAssetJsonOnce(assetPath: String): String

    // ===== Stage 2 (Phrases) =====
    suspend fun getPhraseCategories(): List<PhraseCategory>
    suspend fun getPhrasesForCategory(categoryKey: String): List<PhraseItem>
    suspend fun getAllPhrases(): List<PhraseItem>

    // ===== Quiz stats (smart training) =====
    suspend fun getQuizCorrectCounts(): Map<Int, Int>
    suspend fun incrementQuizCorrect(id: Int)

    // ===== Stage 3 (Lessons/Levels) =====
    suspend fun getLevelsIndex(): List<LevelMeta>
    suspend fun getLessonLevel(levelId: Int): LessonLevel?

    // Per-level progress
    suspend fun getUnlockedLessonIndex(levelId: Int): Int
    suspend fun setUnlockedLessonIndex(levelId: Int, value: Int)

    suspend fun getCompletedLessonIds(levelId: Int): Set<String>
    suspend fun addCompletedLessonId(levelId: Int, lessonId: String)

    // Persist last viewed step within a lesson (key = "levelId|lessonId")
    suspend fun getLessonStepIndex(key: String): Int
    suspend fun setLessonStepIndex(key: String, index: Int)

    // ===== Stage 4 (Duolingo-like Course + Questions) =====
    suspend fun getCourseCurriculum(): CourseCurriculum
    suspend fun getAllUnitsFlat(): List<CourseUnit>
    suspend fun getQuestionByIdMap(): Map<String, Question>
    suspend fun getQuestionsForUnit(globalIndex: Int): List<Question>

    /** Daily Session (short): always 7 questions (or passed count). */
    suspend fun getDailySessionQuestionsForUnit(globalIndex: Int, count: Int, today: String): List<Question>

    /** Unit Lesson (long): one Unit is split into steps (nodes), each step has stepSize questions. */
    suspend fun getUnitLessonStepQuestions(globalIndex: Int, stepIndex: Int, stepsTotal: Int, stepSize: Int): List<Question>

    /** Persist per-unit step progress (0..stepsTotal). */
    suspend fun getUnitStepIndex(globalIndex: Int): Int
    suspend fun getUnitStepIndexMap(): Map<Int, Int>
    suspend fun setUnitStepIndex(globalIndex: Int, stepIndex: Int)

    /** In-progress unit run accumulators used to compute mastery across 5 steps. */
    suspend fun resetUnitRun(globalIndex: Int)
    suspend fun addToUnitRun(globalIndex: Int, correctDelta: Int, totalDelta: Int, timeDeltaMs: Long)
    suspend fun getUnitRun(globalIndex: Int): Triple<Int, Int, Long>

    /** Records a single answered question to update tag stats + anti-repeat history. */
    suspend fun recordQuestionAttempt(question: Question, correct: Boolean)


// ===== Daily Session / Unit progress (Stage 4.1) =====
suspend fun resetDailyIfNewDay(today: String)
suspend fun isDailySessionDone(today: String): Boolean
suspend fun markDailySessionDone(today: String)
suspend fun addTotalXp(delta: Int)
suspend fun saveUnitResult(globalIndex: Int, scorePercent: Int, masteryPercent: Int, stars: Int)


    // ===== Pro Path (100 Units + 5000Q) =====
    /** Separate progress index for Pro Path (1-based). */
    val proCurrentUnitGlobalIndex: Flow<Int>

    suspend fun setProCurrentUnitGlobalIndex(value: Int)

    /** Pro course curriculum (course_5levels_100units_smart.json). */
    suspend fun getProCourseCurriculum(): CourseCurriculum
    suspend fun getAllProUnitsFlat(): List<CourseUnit>

    /** Pro question bank (questions_5000_smart_bidir.json). */
    suspend fun getProQuestionByIdMap(): Map<String, Question>
    suspend fun getProQuestionsForUnit(globalIndex: Int): List<Question>

    /** Pro question bank V2 (multi-type). Used by the new Pro Question Engine only. */
    suspend fun getProQuestionV2ByIdMap(): Map<String, QuestionV2>
    suspend fun getProQuestionsV2ForUnit(globalIndex: Int): List<QuestionV2>

    /** Pro Unit lesson steps (nodes). */
    suspend fun getProUnitLessonStepQuestions(globalIndex: Int, stepIndex: Int, stepsTotal: Int, stepSize: Int): List<Question>

    /** Pro Unit lesson steps (nodes) — V2 question engine. */
    suspend fun getProUnitLessonStepQuestionsV2(globalIndex: Int, stepIndex: Int, stepsTotal: Int, stepSize: Int): List<QuestionV2>

    /** Persist per-unit step progress (0..stepsTotal) for Pro Path. */
    suspend fun getProUnitStepIndex(globalIndex: Int): Int
    suspend fun getProUnitStepIndexMap(): Map<Int, Int>
    suspend fun setProUnitStepIndex(globalIndex: Int, stepIndex: Int)

    /** In-progress pro unit run accumulators used to compute mastery across steps. */
    suspend fun resetProUnitRun(globalIndex: Int)
    suspend fun addToProUnitRun(globalIndex: Int, correctDelta: Int, totalDelta: Int, timeDeltaMs: Long)
    suspend fun getProUnitRun(globalIndex: Int): Triple<Int, Int, Long>

    suspend fun saveProUnitResult(globalIndex: Int, scorePercent: Int, masteryPercent: Int, stars: Int)

    // Last Daily summary (for Smart Home)
    suspend fun saveLastDailySummary(summary: DailySummary)
    suspend fun getLastDailySummary(): DailySummary?

}

