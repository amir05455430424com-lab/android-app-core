package com.emir.englishapp.ui.screens.audiopro

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.emir.englishapp.data.repository.AppRepository
import com.emir.englishapp.domain.model.questionv2.McqQuestionV2
import com.emir.englishapp.domain.model.questionv2.QuestionV2
import com.emir.englishapp.domain.model.questionv2.ReorderQuestionV2
import com.emir.englishapp.ui.screens.proquestion.ProQuestionEvent
import com.emir.englishapp.ui.screens.proquestion.ProQuestionUiState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.util.Random



enum class AudioProMode {
    MIXED,
    MCQ,
    REORDER_WORDS,
    REORDER_LETTERS
}
/**
 * Audio Pro Test engine:
 * - 20 questions (4 steps × 5)
 * - Mix: Audio MCQ + Audio Reorder
 * - Uses assets/audio_pro/ (audios, json)
 */
class AudioProViewModel(
    private val repo: AppRepository,
    private val stepsTotal: Int = 4,
    private val stepSize: Int = 5,
) : ViewModel() {

    private val _uiState = MutableStateFlow(
        ProQuestionUiState(
            globalIndex = 1,
            stepIndex = 0,
            stepsTotal = stepsTotal,
            unitTitleAr = "اختبار صوت PRO",
            unitTitleEn = "Audio Pro"
        )
    )
    val uiState: StateFlow<ProQuestionUiState> = _uiState

    /** Map questionId -> asset relative audio path */
    private val audioPathByQid: MutableMap<String, String> = LinkedHashMap()

    val currentAudioPath: String?
        get() = _uiState.value.questions.getOrNull(_uiState.value.index)?.id?.let { audioPathByQid[it] }

    init {
        // Do not auto-generate session; user picks a mode.
        viewModelScope.launch {

            repo.favoriteQuestionIds.collect { ids ->
                _uiState.update { it.copy(favoriteIds = ids) }
            }
        }
    }

    fun toggleFavoriteCurrent() {
        val q = _uiState.value.questions.getOrNull(_uiState.value.index) ?: return
        viewModelScope.launch { repo.toggleFavoriteQuestion(q.id) }
    }

    fun start(mode: AudioProMode = AudioProMode.MIXED) {
        viewModelScope.launch {
            // New seed each time user enters/starts
            load(mode = mode, sessionSeed = System.nanoTime())
        }
    }

    fun restart(mode: AudioProMode = AudioProMode.MIXED) {
        start(mode)
    }


    fun onEvent(event: ProQuestionEvent) {
        when (event) {
            is ProQuestionEvent.SelectOption -> selectOption(event.index)
            is ProQuestionEvent.PickWord -> pickWord(event.word)
            is ProQuestionEvent.UnpickWord -> unpickWord(event.word)
            ProQuestionEvent.Confirm -> confirm()
            ProQuestionEvent.Next -> next { }
        }
    }

    fun next(onDone: (Boolean) -> Unit) {
        val st = _uiState.value
        if (!st.isAnswered) return

        val nextIndex = st.index + 1
        if (nextIndex >= st.questions.size) {
            onDone(true)
            return
        }

        val now = System.currentTimeMillis()
        _uiState.update {
            it.copy(
                index = nextIndex,
                stepIndex = (nextIndex / stepSize).coerceIn(0, stepsTotal - 1),
                selectedIndex = null,
                reorderAvailable = buildReorderAvailable(it.questions[nextIndex]),
                reorderSelected = emptyList(),
                isAnswered = false,
                isCorrect = null,
                feedbackText = null,
                questionStartedAtMs = now
            )
        }
        onDone(false)
    }

    private suspend fun load(mode: AudioProMode, sessionSeed: Long) {
        _uiState.update { it.copy(isLoading = true, error = null) }

        try {
            val contentJson = JSONObject(repo.readAssetJsonOnce("audio_pro/content_v1.json"))
            val unitsJson = JSONObject(repo.readAssetJsonOnce("audio_pro/pro_path_units_v1.json"))
            val bankJson = JSONObject(repo.readAssetJsonOnce("audio_pro/question_bank_v1.json"))

            // Unit 1 by default (A1 easy start)
            val unit1 = unitsJson.getJSONArray("units").getJSONObject(0)
            val lessonIds = unit1.getJSONArray("lessonIds").toIntList().toSet()

            // Build item pool from lessons
            val lessonsArr = contentJson.getJSONArray("lessons")
            val items = ArrayList<AudioItem>()
            for (i in 0 until lessonsArr.length()) {
                val lessonObj = lessonsArr.getJSONObject(i)
                val lessonId = lessonObj.getInt("lessonId")
                if (lessonId !in lessonIds) continue
                val itemsArr = lessonObj.getJSONArray("items")
                for (j in 0 until itemsArr.length()) {
                    val itObj = itemsArr.getJSONObject(j)
                    if (!itObj.optBoolean("hasAudio", false)) continue
                    val audio = itObj.optString("audio").trim()
                    if (audio.isBlank()) continue
                    items.add(
                        AudioItem(
                            key = itObj.optString("key"),
                            lessonId = lessonId,
                            en = itObj.optString("en"),
                            ar = itObj.optString("ar"),
                            difficulty = itObj.optString("difficulty"),
                            audioFile = audio
                        )
                    )
                }
            }

            // Reorder pool
            val reorderQs = ArrayList<AudioReorder>()
            val questionsArr = bankJson.getJSONArray("questions")
            for (i in 0 until questionsArr.length()) {
                val qObj = questionsArr.getJSONObject(i)
                if (qObj.optString("type") != "reorder_words") continue
                val lessonId = qObj.optInt("lessonId")
                if (lessonId !in lessonIds) continue
                val audio = qObj.optString("audio").trim()
                if (audio.isBlank()) continue
                val payload = qObj.getJSONObject("payload")
                val tokens = payload.getJSONArray("answerTokens").toStringList()
                if (tokens.isEmpty()) continue
                reorderQs.add(
                    AudioReorder(
                        key = qObj.optString("key"),
                        lessonId = lessonId,
                        difficulty = qObj.optString("difficulty"),
                        audioFile = audio,
                        correctTokens = tokens
                    )
                )
            }

            if (items.isEmpty()) {
                _uiState.update { it.copy(isLoading = false, error = "لا توجد عناصر صوتية كافية.") }
                return
            }

            // Dedup by normalized EN to avoid repeating the same sentence across MCQ picks.
            val normSeen = HashSet<String>()
            fun normEn(s: String): String = s.lowercase().trim().replace(Regex("\\s+"), " ")

            // Use nanoTime to avoid repeated seeds when user re-enters quickly.
            val rnd = Random(sessionSeed)
            val easyItems = items
                .filter { it.difficulty == "easy" }
                .sortedBy { it.en.split(Regex("\\s+")).size }

            val questions = ArrayList<QuestionV2>(20)

            // Helper to create MCQ
            fun makeMcq(item: AudioItem, promptAr: String): McqQuestionV2 {
                val correctAr = item.ar.trim()

                // Guard against bad/placeholder AR like "1", "2" ...
                fun hasArabic(s: String): Boolean = s.any { it in '\u0600'..'\u06FF' }
                require(correctAr.isNotBlank()) { "blank ar" }
                require(!correctAr.all { it.isDigit() }) { "numeric ar" }
                require(hasArabic(correctAr)) { "non-arabic ar" }

                val options = LinkedHashSet<String>()
                options.add(correctAr)

                // Distractors from same pool but: non-blank, not numeric, has Arabic, not equal to correct
                var guard = 0
                while (options.size < 4 && guard < 5000) {
                    guard++
                    val cand = items[rnd.nextInt(items.size)].ar.trim()
                    if (cand.isBlank()) continue
                    if (cand == correctAr) continue
                    if (cand.all { it.isDigit() }) continue
                    if (!hasArabic(cand)) continue
                    options.add(cand)
                }

                // If still not enough, pad with a safe fallback to avoid crashing (but keep meaningful options)
                while (options.size < 4) options.add("—")

                val optsList = options.toList().shuffled(rnd)
                val id = "a_mcq_${item.key}_${item.audioFile}"
                audioPathByQid[id] = "audio_pro/audios/${item.audioFile}"
                return McqQuestionV2(
                    id = id,
                    cefr = "A1",
                    direction = "listen",
                    promptAr = promptAr,
                    sentenceEn = item.en.trim().ifBlank { null },
                    optionsAr = optsList,
                    answerIndex = optsList.indexOf(correctAr).coerceAtLeast(0),
                    difficultyScore = if (item.difficulty == "easy") 1 else 2,
                    explanationAr = null
                )
            }

            // Helper to create reorder

            fun makeReorder(r: AudioReorder, promptEn: String, showArHint: String?): ReorderQuestionV2 {
                val shuffled = r.correctTokens.toMutableList().also { it.shuffle(rnd) }
                val id = "a_re_${r.key}_${r.audioFile}"
                audioPathByQid[id] = "audio_pro/audios/${r.audioFile}"
                return ReorderQuestionV2(
                    id = id,
                    cefr = "A1",
                    direction = "audio",
                    promptEn = promptEn,
                    words = shuffled,
                    correctOrder = r.correctTokens,
                    difficultyScore = if (r.difficulty == "easy") 1 else 2,
                    explanationAr = showArHint
                )
            }

            

            // Helper to create reorder letters (word)
            fun makeReorderLetters(item: AudioItem, promptEn: String, showArHint: String?): ReorderQuestionV2 {
                // pick a single word (A1-friendly)
                val word = item.en.trim()
                    .split(Regex("\\s+"))
                    .firstOrNull()
                    .orEmpty()
                val letters = word.toCharArray().map { it.toString() }.filter { it.isNotBlank() }
                val shuffled = letters.toMutableList().also { it.shuffle(rnd) }

                val id = "a_rl_${item.key}_${item.audioFile}"
                audioPathByQid[id] = "audio_pro/audios/${item.audioFile}"
                return ReorderQuestionV2(
                    id = id,
                    cefr = "A1",
                    direction = "audio_letters",
                    promptEn = promptEn,
                    words = shuffled,
                    correctOrder = letters,
                    difficultyScore = if (item.difficulty == "easy") 1 else 2,
                    explanationAr = showArHint
                )
            }
fun pickUnique(pool: List<AudioItem>, tries: Int = 24): AudioItem {
                // Prefer unseen. If pool is small or everything is "seen", fall back to random.
                repeat(tries) {
                    val cand = pool[rnd.nextInt(pool.size)]
                    if (normEn(cand.en) !in normSeen) return cand
                }
                // Last resort
                return pool[rnd.nextInt(pool.size)]
            }

            // Build session questions by mode (always 20Q).
            // Stages: 4 stages × 5 questions (matches Pro pattern).
            val stageCount = stepsTotal
            val perStage = stepSize
            val total = stageCount * perStage

            // Pools
            val firstPool = (easyItems.ifEmpty { items }).take(300).ifEmpty { items }
            val reorderPool = reorderQs.sortedBy { if (it.difficulty == "easy") 0 else 1 }
            val lettersPool = firstPool.filter { it.en.trim().split(Regex("\\s+")).firstOrNull()?.length in 3..10 }

            fun addMcqA1(count: Int) {
                repeat(count) {
                    val pick = pickUnique(firstPool)
                    normSeen.add(normEn(pick.en))
                    questions.add(makeMcq(pick, promptAr = "استمع واختر المعنى الصحيح"))
                }
            }

            fun addReorderWords(count: Int) {
                var idx = 0
                repeat(count) {
                    if (idx < reorderPool.size) {
                        val r = reorderPool[idx++]
                        questions.add(makeReorder(r, promptEn = "Arrange the words:", showArHint = "(استخدم الترجمة للمساعدة)"))
                    } else {
                        // fallback to mcq
                        val pick = pickUnique(items)
                        normSeen.add(normEn(pick.en))
                        questions.add(makeMcq(pick, promptAr = "استمع واختر المعنى الصحيح"))
                    }
                }
            }

            fun addReorderLetters(count: Int) {
                repeat(count) {
                    val pick = pickUnique(lettersPool.ifEmpty { firstPool })
                    normSeen.add(normEn(pick.en))
                    questions.add(makeReorderLetters(pick, promptEn = "Arrange the letters:", showArHint = "(رتّب الحروف)"))
                }
            }

            when (mode) {
                AudioProMode.MCQ -> {
                    addMcqA1(total)
                }
                AudioProMode.REORDER_WORDS -> {
                    addReorderWords(total)
                }
                AudioProMode.REORDER_LETTERS -> {
                    addReorderLetters(total)
                }
                AudioProMode.MIXED -> {
                    // Stage-wise mix:
                    // Stage 1: all MCQ (very easy)
                    addMcqA1(perStage)
                    // Stage 2: mix MCQ + reorder words
                    addReorderWords(2)
                    addMcqA1(3)
                    // Stage 3: mix reorder letters + reorder words + mcq
                    addReorderLetters(2)
                    addReorderWords(2)
                    addMcqA1(1)
                    // Stage 4: harder mix (more reorder)
                    addReorderWords(2)
                    addReorderLetters(2)
                    addMcqA1(1)
                    // Ensure size exactly 20
                    if (questions.size > total) {
                        // Use removeAt(lastIndex) for maximum Kotlin compatibility.
                        while (questions.size > total && questions.isNotEmpty()) {
                            questions.removeAt(questions.lastIndex)
                        }
                    } else if (questions.size < total) {
                        addMcqA1(total - questions.size)
                    }
                }
            }

            // Shuffle within each stage to avoid same ordering, but keep stage boundaries stable.
            // NOTE: kotlin.random.Random takes an Int seed, not Long.
            // Hash the Long into an Int to keep deterministic shuffling.
            // Shuffle within each stage to avoid same ordering

            val mixedSeedLong = sessionSeed xor (-7046029254386353131L)
            val mixedSeedInt = (mixedSeedLong xor (mixedSeedLong ushr 32)).toInt()

            val rnd2 = kotlin.random.Random(mixedSeedInt)

            val staged = questions
                .chunked(perStage)
                .flatMap { it.shuffled(rnd2) }

            questions.clear()
            questions.addAll(staged.take(total))

            val now = System.currentTimeMillis()
            val firstQ = questions.firstOrNull()
            _uiState.update {
                it.copy(
                    isLoading = false,
                    error = null,
                    questions = questions,
                    index = 0,
                    stepIndex = 0,
                    selectedIndex = null,
                    reorderAvailable = firstQ?.let { q -> buildReorderAvailable(q) } ?: emptyList(),
                    reorderSelected = emptyList(),
                    isAnswered = false,
                    isCorrect = null,
                    feedbackText = null,
                    correctCount = 0,
                    streakCorrect = 0,
                    questionStartedAtMs = now,
                    totalAnswerTimeMs = 0L
                )
            }
        } catch (t: Throwable) {
            // Keep the app alive and show a safe error instead of crashing.
            _uiState.update { it.copy(isLoading = false, error = "فشل تحميل اختبار الصوت. حاول مرة أخرى.") }
        }
    }

    private fun buildReorderAvailable(q: QuestionV2): List<String> {
        return if (q is ReorderQuestionV2) q.words else emptyList()
    }

    private fun selectOption(index: Int) {
        val before = _uiState.value
        if (before.isAnswered) return
        _uiState.update { st ->
            if (st.isAnswered) return@update st
            st.copy(selectedIndex = index)
        }
        confirm()
    }

    private fun pickWord(word: String) {
        _uiState.update { st ->
            if (st.isAnswered) return@update st
            if (word !in st.reorderAvailable) return@update st
            if (word in st.reorderSelected) return@update st
            st.copy(reorderSelected = st.reorderSelected + word)
        }

        val st = _uiState.value
        val q = st.questions.getOrNull(st.index)
        if (!st.isAnswered && q is ReorderQuestionV2 && st.reorderSelected.size >= q.correctOrder.size) {
            confirm()
        }
    }

    private fun unpickWord(word: String) {
        _uiState.update { st ->
            if (st.isAnswered) return@update st
            val idx = st.reorderSelected.indexOfLast { it == word }
            if (idx < 0) return@update st
            val next = st.reorderSelected.toMutableList().apply { removeAt(idx) }
            st.copy(reorderSelected = next)
        }
    }

    private fun confirm() {
        _uiState.update { st ->
            if (st.isAnswered) return@update st
            val q = st.questions.getOrNull(st.index) ?: return@update st

            val hasSelection = when (q) {
                is ReorderQuestionV2 -> st.reorderSelected.isNotEmpty()
                is McqQuestionV2 -> st.selectedIndex != null
                else -> st.selectedIndex != null
            }
            if (!hasSelection) return@update st

            val ok = when (q) {
                is McqQuestionV2 -> (st.selectedIndex == q.answerIndex)
                is ReorderQuestionV2 -> (st.reorderSelected == q.correctOrder)
                else -> false
            }

            val feedback = if (ok) "إجابة صحيحة ✅" else "إجابة غير صحيحة ❌"
            val nextStreak = if (ok) st.streakCorrect + 1 else 0

            st.copy(
                isAnswered = true,
                isCorrect = ok,
                feedbackText = feedback,
                streakCorrect = nextStreak,
                correctCount = st.correctCount + if (ok) 1 else 0
            )
        }
    }

    private data class AudioItem(
        val key: String,
        val lessonId: Int,
        val en: String,
        val ar: String,
        val difficulty: String,
        val audioFile: String,
    )

    private data class AudioReorder(
        val key: String,
        val lessonId: Int,
        val difficulty: String,
        val audioFile: String,
        val correctTokens: List<String>,
    )
}

class AudioProViewModelFactory(
    private val repo: AppRepository
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(AudioProViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return AudioProViewModel(repo) as T
        }
        throw IllegalArgumentException("Unknown ViewModel")
    }
}

private fun JSONArray.toIntList(): List<Int> {
    val out = ArrayList<Int>(length())
    for (i in 0 until length()) out.add(getInt(i))
    return out
}

private fun JSONArray.toStringList(): List<String> {
    val out = ArrayList<String>(length())
    for (i in 0 until length()) {
        val v = optString(i).trim()
        if (v.isNotBlank()) out.add(v)
    }
    return out
}
