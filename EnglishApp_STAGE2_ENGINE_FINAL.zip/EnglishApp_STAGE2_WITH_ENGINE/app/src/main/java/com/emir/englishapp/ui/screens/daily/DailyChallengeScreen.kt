package com.emir.englishapp.ui.screens.daily

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Composable
fun DailyChallengeScreen(
    state: DailyChallengeUiState,
    onBack: () -> Unit,
    onSelect: (Int) -> Unit,
    onNext: () -> Unit,
    onToggleFavorite: () -> Unit
) {
    val success = Color(0xFF2E7D32)
    val error = Color(0xFFC62828)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(onClick = onBack) { Text("رجوع") }
            Text("⚔️ تحدي سريع", style = MaterialTheme.typography.titleLarge)
        }

        if (state.isLoading) {
            Text("تحميل...", style = MaterialTheme.typography.bodyMedium)
            return
        }
        state.error?.let {
            Text(it, style = MaterialTheme.typography.bodyMedium)
            return
        }

        Text(state.unitTitleEn, style = MaterialTheme.typography.titleMedium)
        Text(state.unitTitleAr, style = MaterialTheme.typography.bodyMedium)

        val total = state.questions.size.coerceAtLeast(1)
        val idx = (state.index + 1).coerceIn(1, total)
        Text("السؤال $idx / $total", style = MaterialTheme.typography.titleMedium)
        LinearProgressIndicator(progress = idx / total.toFloat(), modifier = Modifier.fillMaxWidth())

        val q = state.questions.getOrNull(state.index)
        if (q == null) {
            Text("لا يوجد سؤال.", style = MaterialTheme.typography.bodyMedium)
            return
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("سؤال", style = MaterialTheme.typography.labelMedium)
                    val isFav = state.favoriteIds.contains(q.id)
                    IconButton(onClick = onToggleFavorite) {
                        if (isFav) {
                            Icon(Icons.Filled.Star, contentDescription = "favorite")
                        } else {
                            Icon(Icons.Outlined.StarBorder, contentDescription = "favorite")
                        }
                    }
                }
                val prompt = q.promptEn.ifBlank { q.promptAr.orEmpty() }
                Text(prompt, style = MaterialTheme.typography.titleMedium)
            }
        }

        Spacer(Modifier.height(4.dp))

        val answered = state.selected != null

        val options = if (q.optionsAr.isNotEmpty()) q.optionsAr else q.optionsEn.orEmpty()

        if (options.isEmpty()) {
            Text("لا يوجد خيارات لهذا السؤال.", style = MaterialTheme.typography.bodyMedium)
            return
        }

        options.forEachIndexed { optIdx, opt ->
            val isSelected = state.selected == optIdx
            val isCorrectOption = optIdx == q.answerIndex

            val showCorrect = answered && isCorrectOption
            val showWrongSelected = answered && isSelected && !isCorrectOption

            val container = when {
                showCorrect -> success.copy(alpha = 0.22f)
                showWrongSelected -> error.copy(alpha = 0.18f)
                else -> MaterialTheme.colorScheme.surface
            }
            val content = when {
                showCorrect -> success
                showWrongSelected -> error
                else -> MaterialTheme.colorScheme.onSurface
            }
            val borderColor = when {
                showCorrect -> success
                showWrongSelected -> error
                else -> MaterialTheme.colorScheme.outline
            }

            Button(
                onClick = { onSelect(optIdx) },
                modifier = Modifier.fillMaxWidth(),
                enabled = !answered,
                shape = RoundedCornerShape(24.dp),
                border = BorderStroke(1.dp, borderColor),
                colors = ButtonDefaults.buttonColors(
                    containerColor = container,
                    contentColor = content
                )
            ) {
                Text(opt)
            }
        }

        Spacer(Modifier.height(6.dp))

        Button(
            onClick = onNext,
            modifier = Modifier.fillMaxWidth(),
            enabled = answered
        ) { Text("التالي") }
    }
}