package com.emir.englishapp.domain.model.exercise

/**
 * Assessment Hierarchy
 * =====================
 * Path
 *  └─ Level           (e.g. A1 Beginner, A2 Elementary …)
 *      └─ Module      (e.g. Family & People, Daily Life …)
 *          └─ Node    (circular learning point — up to 8 per module)
 *              └─ Lesson (instructional set of exercises)
 *                   └─ Assessment (single exercise, up to 200 per module total)
 *
 * Rules:
 *  - Nodes are circular (a learner loops back after completing all nodes in a module).
 *  - Each module may contain UP TO 200 unique assessment activities distributed
 *    across its nodes and lessons.
 *  - `isUnlocked` and `completionPercent` are computed by SessionOrchestrator,
 *    never stored here (pure domain model, no persistence coupling).
 */

// ─────────────────────────────────────────────────────────────
// Path (top-level learning track)
// ─────────────────────────────────────────────────────────────
data class AssessmentPath(
    val pathId: String,
    val titleEn: String,
    val titleAr: String,
    val cefr: String,               // "A1" | "A1-A2" | "B1" …
    val levels: List<AssessmentLevel>,
    val iconResName: String = "",   // drawable res name for path card
)

// ─────────────────────────────────────────────────────────────
// Level (major milestone within a path)
// ─────────────────────────────────────────────────────────────
data class AssessmentLevel(
    val levelId: String,
    val pathId: String,
    val ordinal: Int,               // 1-based position in path
    val titleEn: String,
    val titleAr: String,
    val cefrRange: String,          // e.g. "A1"
    val modules: List<AssessmentModule>,
)

// ─────────────────────────────────────────────────────────────
// Module (subject-specific unit within a level, max 200 assessments)
// ─────────────────────────────────────────────────────────────
data class AssessmentModule(
    val moduleId: String,
    val levelId: String,
    val ordinal: Int,
    val titleEn: String,
    val titleAr: String,
    val topic: String,              // aligns with data.json category keys
    val iconResName: String = "",
    val nodes: List<AssessmentNode>,
    val maxAssessments: Int = 200,  // hard cap enforced by SmartLocalEngine
) {
    /** Flat list of all assessments across all nodes in this module. */
    val allAssessmentIds: List<String>
        get() = nodes.flatMap { node -> node.lessons.flatMap { lesson -> lesson.assessmentIds } }

    init {
        require(allAssessmentIds.size <= maxAssessments) {
            "Module '$moduleId' exceeds $maxAssessments assessment limit " +
            "(has ${allAssessmentIds.size})"
        }
    }
}

// ─────────────────────────────────────────────────────────────
// Node (circular, interconnected learning point within a module)
// ─────────────────────────────────────────────────────────────
data class AssessmentNode(
    val nodeId: String,
    val moduleId: String,
    val ordinal: Int,               // position within module's circular ring
    val titleEn: String,
    val titleAr: String,
    val modality: LearningModality, // primary modality for this node
    val lessons: List<AssessmentLesson>,
) {
    /**
     * Next node in the circular ring.
     * Resolution is delegated to [AssessmentModule]; index is wrapping.
     */
    fun nextOrdinal(totalNodes: Int): Int = (ordinal % totalNodes) + 1
}

// ─────────────────────────────────────────────────────────────
// Lesson (specific instructional set within a node)
// ─────────────────────────────────────────────────────────────
data class AssessmentLesson(
    val lessonId: String,
    val nodeId: String,
    val ordinal: Int,
    val titleEn: String,
    val titleAr: String,
    /** IDs into the [SmartLocalEngine]-generated exercise pool. */
    val assessmentIds: List<String>,
    val targetCorrectPercent: Int = 80,   // mastery threshold (0..100)
)

// ─────────────────────────────────────────────────────────────
// Runtime progress snapshot (read-only, produced by SessionOrchestrator)
// ─────────────────────────────────────────────────────────────
data class ModuleProgress(
    val moduleId: String,
    val completedAssessmentIds: Set<String>,
    val masteredAssessmentIds: Set<String>,
) {
    val completionPercent: Int
        get() = if (completedAssessmentIds.isEmpty()) 0
                else (completedAssessmentIds.size * 100) / completedAssessmentIds.size

    fun isNodeComplete(node: AssessmentNode): Boolean =
        node.lessons.all { lesson ->
            lesson.assessmentIds.all { id -> id in masteredAssessmentIds }
        }
}
