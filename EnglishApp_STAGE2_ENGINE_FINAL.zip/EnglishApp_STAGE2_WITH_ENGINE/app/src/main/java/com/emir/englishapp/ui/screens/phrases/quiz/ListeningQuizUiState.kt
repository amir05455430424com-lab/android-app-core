package com.emir.englishapp.ui.screens.phrases.quiz

data class ListeningQuizUiState(
    val isLoading: Boolean = true,
    val errorMessage: String? = null,

    val categoryKey: String = "",

    // Session progress
    val currentIndex: Int = 1,      // 1-based
    val totalQuestions: Int = 10,
    val correctCount: Int = 0,
    val xpEarned: Int = 0,
    val isFinished: Boolean = false,

    // Current question
    val questionId: Int? = null,
    val questionEn: String = "",
    val options: List<OptionItem> = emptyList(),

    // For UI coloring/locking once the user answers
    val correctOptionId: Int? = null,

    val selectedOptionId: Int? = null,
    val isCorrect: Boolean? = null,
    val feedbackMessage: String? = null,
    val canGoNext: Boolean = false
) {
    data class OptionItem(
        val id: Int,
        val arText: String
    )
}
