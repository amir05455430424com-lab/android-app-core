package com.emir.englishapp.ui.screens.phrases.list

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.emir.englishapp.domain.model.PhraseItem
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder

@Composable
fun PhrasesListScreen(
    state: PhrasesListUiState,
    onBack: () -> Unit,
    onPlayEn: (PhraseItem) -> Unit,
    onPlayAr: (PhraseItem) -> Unit,
    onToggleFavorite: (PhraseItem) -> Unit,
    onOpenQuiz: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) {
            Text("رجوع")
        }

        Text("الجمل", style = MaterialTheme.typography.titleLarge)

        Button(onClick = onOpenQuiz, modifier = Modifier.fillMaxWidth()) {
            Text("🎧 Listening Quiz")
        }

        Spacer(Modifier.height(6.dp))

        if (state.isLoading) {
            Text("تحميل...", style = MaterialTheme.typography.bodyMedium)
            return
        }

        state.errorMessage?.let {
            Text(it, style = MaterialTheme.typography.bodyMedium)
            return
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(state.phrases, key = { it.id }) { item ->
                PhraseRow(
                    item = item,
                    isFavorite = state.favoritePhraseIds.contains(item.id.toString()),
                    onPlayEn = { onPlayEn(item) },
                    onPlayAr = { onPlayAr(item) },
                    onToggleFavorite = { onToggleFavorite(item) }
                )
            }
        }
    }
}

@Composable
private fun PhraseRow(
    item: PhraseItem,
    isFavorite: Boolean,
    onPlayEn: () -> Unit,
    onPlayAr: () -> Unit,
    onToggleFavorite: () -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(item.ar, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                IconButton(onClick = onToggleFavorite) {
                    Icon(
                        imageVector = if (isFavorite) Icons.Filled.Star else Icons.Filled.StarBorder,
                        contentDescription = null
                    )
                }
            }
            Text(item.en, style = MaterialTheme.typography.bodyMedium)

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = onPlayEn) { Text("▶ EN") }
                OutlinedButton(onClick = onPlayAr) { Text("▶ AR") }
            }
        }
    }
}
