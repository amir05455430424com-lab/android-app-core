package com.emir.englishapp.domain.model.daily

/**
 * Snapshot of the last completed Daily Session.
 * Stored in UserProgressStore as JSON for Smart Home UI.
 */
data class DailySummary(
    val date: String,
    val globalIndex: Int,
    val correct: Int,
    val total: Int,
    val scorePercent: Int,
    val masteryPercent: Int,
    val stars: Int,
    val xpEarned: Int
)
