package com.emir.englishapp.ui.screens.phrases.list

import com.emir.englishapp.domain.model.PhraseItem

data class PhrasesListUiState(
    val isLoading: Boolean = true,
    val errorMessage: String? = null,
    val categoryKey: String = "",
    val phrases: List<PhraseItem> = emptyList(),
    val favoritePhraseIds: Set<String> = emptySet()
)
