package com.emir.englishapp.ui.screens.unitlesson

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun UnitRewardScreen(
    globalIndex: Int,
    stepIndex: Int,
    stepsTotal: Int,
    scorePercent: Int,
    masteryPercent: Int,
    stars: Int,
    correct: Int,
    total: Int,
    xp: Int,
    unlockedNext: Boolean,
    isFinal: Boolean,
    onBackToPath: () -> Unit,
    onNextStep: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(onClick = onBackToPath) { Text("رجوع") }
            Text("🏁 نتيجة الدرس", style = MaterialTheme.typography.titleLarge)
        }

        Text("الوحدة: $globalIndex", style = MaterialTheme.typography.titleMedium)
        Text("الخطوة: ${stepIndex + 1} / $stepsTotal", style = MaterialTheme.typography.titleMedium)

        Text("الصحيح: $correct / $total")
        Text("النتيجة: $scorePercent%")
        Text("Mastery: $masteryPercent%")
        Text("⭐ النجوم: $stars")
        Text("XP: +$xp")

        if (isFinal) {
            if (unlockedNext) {
                Text("✅ تم فتح الوحدة التالية")
            } else {
                Text("ℹ️ تحتاج Mastery 80% لفتح الوحدة التالية")
            }
            Spacer(Modifier.height(8.dp))
            Button(onClick = onBackToPath, modifier = Modifier.fillMaxWidth()) {
                Text("العودة للمسار")
            }
        } else {
            Spacer(Modifier.height(8.dp))
            Button(onClick = onNextStep, modifier = Modifier.fillMaxWidth()) {
                Text("الخطوة التالية")
            }
            OutlinedButton(onClick = onBackToPath, modifier = Modifier.fillMaxWidth()) {
                Text("العودة للمسار")
            }
        }
    }
}
