package com.emir.englishapp.ui.navigation

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.compose.currentBackStackEntryAsState
import com.emir.englishapp.EnglishApp
import kotlinx.coroutines.launch
import androidx.compose.material3.Switch
import androidx.compose.material3.Divider
import com.emir.englishapp.data.local.SettingsStore

/**
 * Global Duolingo-Pro style shell:
 * - Top App Bar with XP + Streak
 * - Navigation Drawer (main menu)
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppScaffold(
    navController: NavHostController,
    title: String = "English App",
    content: @Composable () -> Unit = {},
) {

    val context = LocalContext.current
    val app = context.applicationContext as EnglishApp
    val repo = app.container.repository

    val totalXp by repo.totalXp.collectAsState(initial = 0)
    val streak by repo.streakDays.collectAsState(initial = 0)

    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    val backStack by navController.currentBackStackEntryAsState()
    val route = backStack?.destination?.route.orEmpty()

    val canGoBack = navController.previousBackStackEntry != null &&
        // treat these as root destinations
        route != Routes.HOME && route != Routes.PATH && route != Routes.PHRASES_CATEGORIES && route != Routes.LESSONS &&
        route != Routes.FAVORITES && route != Routes.SETTINGS

    fun openDrawer() = scope.launch { drawerState.open() }
    fun closeDrawer() = scope.launch { drawerState.close() }

    ModalNavigationDrawer(
        drawerState = drawerState,
        scrimColor = MaterialTheme.colorScheme.scrim.copy(alpha = 0.45f),
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = MaterialTheme.colorScheme.surface,
                drawerTonalElevation = 0.dp
            ) {
                DrawerContent(
                    currentRoute = route,
                                        onNavigate = { dest ->
                        closeDrawer()
                        navController.navigate(dest) {
                            // keep back stack clean for top-level destinations
                            popUpTo(Routes.HOME) { inclusive = false }
                            launchSingleTop = true
                        }
                    }
                )
            }
        }
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    navigationIcon = {
                        IconButton(
                            onClick = {
                                if (canGoBack) navController.popBackStack() else openDrawer()
                            }
                        ) {
                            Icon(
                                imageVector = if (canGoBack) Icons.Filled.ArrowBack else Icons.Filled.Menu,
                                contentDescription = "nav"
                            )
                        }
                    },
                    title = {
                        Text(
                            text = titleForRoute(route),
                            fontWeight = FontWeight.SemiBold
                        )
                    },
                    actions = {
                    AnimatedStatPill(prefix = "⚡", value = totalXp)
                    Spacer(Modifier.width(10.dp))
                    AnimatedStatPill(prefix = "🔥", value = streak)
                    Spacer(Modifier.width(6.dp))
                }
                )
            }
        ) { innerPadding ->
            // The real navigation graph
            androidx.compose.foundation.layout.Box(modifier = Modifier.padding(innerPadding)) {
                AppNavHost(navController = navController)
            }
        }
    }
}

@Composable
private fun AnimatedStatPill(prefix: String, value: Int) {
    androidx.compose.material3.Surface(
        shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.primaryContainer
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "$prefix ",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.SemiBold
            )
            AnimatedContent(
                targetState = value,
                transitionSpec = {
                    (slideInVertically(animationSpec = tween(180)) { it / 2 } + fadeIn(tween(180))) togetherWith
                        (slideOutVertically(animationSpec = tween(180)) { -it / 2 } + fadeOut(tween(180)))
                },
                label = "stat_pill"
            ) { v ->
                Text(
                    text = v.toString(),
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

@Composable
private fun DrawerContent(
    currentRoute: String,
    onNavigate: (String) -> Unit
) {
    val context = LocalContext.current.applicationContext
    val settingsStore = remember { SettingsStore(context) }
    val darkMode by settingsStore.darkModeFlow.collectAsState(initial = false)
    val scope = rememberCoroutineScope()

    val items = listOf(
        DrawerItem("الرئيسية", Routes.HOME, Icons.Filled.Home),
        DrawerItem("المسار", Routes.PATH, Icons.Filled.School),
        DrawerItem("PRO Path", Routes.PRO_PATH, Icons.Filled.Star),
        DrawerItem("جلسة اليوم", Routes.DAILY_START, Icons.Filled.PlayArrow),
        DrawerItem("الدروس", Routes.LESSONS, Icons.Filled.School),
        DrawerItem("الجمل", Routes.PHRASES_CATEGORIES, Icons.Filled.Chat),
        DrawerItem("المفضلة", Routes.FAVORITES, Icons.Filled.Star),
        DrawerItem("الإعدادات", Routes.SETTINGS, Icons.Filled.Settings),
    )

    androidx.compose.foundation.layout.Column(
        modifier = androidx.compose.ui.Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // --- Header خرافي ---
        androidx.compose.foundation.layout.Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 32.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                "English Pro",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Black,
                color = MaterialTheme.colorScheme.primary
            )
        }
        Divider(color = MaterialTheme.colorScheme.outlineVariant)
        Spacer(Modifier.height(16.dp))

        // --- عناصر القائمة ---
        items.forEach { item ->
            val selected = currentRoute == item.route
            NavigationDrawerItem(
                label = { 
                    Text(
                        item.label, 
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                    ) 
                },
                selected = selected,
                onClick = { onNavigate(item.route) },
                icon = { Icon(item.icon, contentDescription = null) },
                modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
            )
        }

        Spacer(Modifier.weight(1f))
        Divider(color = MaterialTheme.colorScheme.outlineVariant)
        Spacer(Modifier.height(16.dp))

        // --- التبديل الليلي ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "الوضع الليلي",
                modifier = Modifier.weight(1f),
                style = MaterialTheme.typography.bodyLarge
            )
            Switch(
                checked = darkMode,
                onCheckedChange = { enabled ->
                    scope.launch { settingsStore.setDarkMode(enabled) }
                }
            )
        }
        Spacer(Modifier.height(16.dp))
    }
}

private data class DrawerItem(
    val label: String,
    val route: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector
)

private fun titleForRoute(route: String): String {
    return when {
        route == Routes.HOME -> "الرئيسية"
        route == Routes.PATH -> "المسار"
        route == Routes.PRO_PATH -> "PRO Path"
        route == Routes.DAILY_START -> "جلسة اليوم"
        route.startsWith("daily/") -> "جلسة اليوم"
        route.startsWith("unit/") -> "درس الوحدة"
        route == Routes.LESSONS || route.startsWith("lessons/") -> "الدروس"
        route == Routes.PHRASES_CATEGORIES || route.startsWith("phrases/") -> "الجمل"
        route == Routes.FAVORITES -> "المفضلة"
        route == Routes.SETTINGS -> "الإعدادات"
        else -> "English App"
    }
}