package com.emir.englishapp.ui.screens.audiopro

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.emir.englishapp.ui.screens.proquestion.ProQuestionEvent
import com.emir.englishapp.ui.screens.proquestion.ProQuestionScreen
import com.emir.englishapp.ui.screens.proquestion.ProQuestionUiState

@Composable
fun AudioProScreen(
    state: ProQuestionUiState,
    onBack: () -> Unit,
    onToggleFavorite: () -> Unit,
    onEvent: (ProQuestionEvent) -> Unit,
    onNext: () -> Unit,
    currentAudioPath: String?,
    onPlayAudio: (String) -> Unit,
    onStartMode: (AudioProMode) -> Unit,
) {
    // If no session yet, show mode picker
    if (!state.isLoading && state.error == null && state.questions.isEmpty()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("اختبار صوت PRO", style = MaterialTheme.typography.headlineSmall)
            Text("اختر نوع الاختبار أو ابدأ جلسة مختلطة.", style = MaterialTheme.typography.bodyMedium)

            ModeCard(
                title = "استمع واختر المعنى",
                subtitle = "MCQ — أسهل نمط للبداية",
                onClick = { onStartMode(AudioProMode.MCQ) }
            )
            ModeCard(
                title = "استمع ورتّب الكلمات",
                subtitle = "Reorder Words — للجمل",
                onClick = { onStartMode(AudioProMode.REORDER_WORDS) }
            )
            ModeCard(
                title = "استمع ورتّب الحروف",
                subtitle = "Reorder Letters — للكلمات",
                onClick = { onStartMode(AudioProMode.REORDER_LETTERS) }
            )

            Spacer(Modifier.height(8.dp))

            Button(
                modifier = Modifier.fillMaxWidth().height(54.dp),
                onClick = { onStartMode(AudioProMode.MIXED) }
            ) {
                Text("ابدأ جلسة مختلطة (20 سؤال)")
            }

            OutlinedButton(
                modifier = Modifier.fillMaxWidth(),
                onClick = onBack
            ) {
                Text("رجوع")
            }
        }
    } else {
        ProQuestionScreen(
            state = state,
            onBack = onBack,
            onToggleFavorite = onToggleFavorite,
            onEvent = onEvent,
            onNext = onNext,
            currentAudioPath = currentAudioPath,
            onPlayAudio = onPlayAudio,
        )
    }
}

@Composable
private fun ModeCard(
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        onClick = onClick
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(subtitle, style = MaterialTheme.typography.bodySmall)
        }
    }
}
