package com.emir.englishapp.ui.screens.phrases.list

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.emir.englishapp.data.repository.AppRepository
import com.emir.englishapp.domain.audio.AssetAudioPlayer

class PhrasesListViewModelFactory(
    private val repo: AppRepository,
    private val audioPlayer: AssetAudioPlayer,
    private val categoryKey: String
) : ViewModelProvider.Factory {

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(PhrasesListViewModel::class.java)) {
            return PhrasesListViewModel(repo, audioPlayer, categoryKey) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
    }
}
