package com.emir.englishapp.domain.model

/**
 * Source sentence item used for dynamic question generation.
 * Mirrors `sentences_daily_8000_clean_classified_v2.json` entries.
 */
data class SentenceItem(
    val id: Int,
    val en: String,
    val ar: String,
    val level: String,
    val topic: String? = null,
    val wordCount: Int? = null,
    val complexityScore: Double? = null,
)
