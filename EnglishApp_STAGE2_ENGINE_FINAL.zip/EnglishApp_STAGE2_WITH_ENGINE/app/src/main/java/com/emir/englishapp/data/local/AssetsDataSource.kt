package com.emir.englishapp.data.local

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

class AssetsDataSource(
    private val appContext: Context
) {
    private val mutex = Mutex()
    private val cache = mutableMapOf<String, String>()

    suspend fun readTextOnce(assetPath: String): String = mutex.withLock {
        cache[assetPath] ?: run {
            val text = withContext(Dispatchers.IO) {
                appContext.assets.open(assetPath).bufferedReader().use { it.readText() }
            }
            cache[assetPath] = text
            text
        }
    }
}
