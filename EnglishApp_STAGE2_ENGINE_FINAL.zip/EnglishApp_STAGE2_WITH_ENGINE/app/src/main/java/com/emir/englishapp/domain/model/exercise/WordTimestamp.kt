package com.emir.englishapp.domain.model.exercise

/**
 * WordTimestamp — Millisecond-precise audio-to-word alignment.
 *
 * Produced by the EduCMS TTS pipeline (Google/Azure word-boundary events).
 * Consumed by the Screen Engine to highlight words during audio playback.
 *
 * JSON schema (asset side):
 * {
 *   "word":    "school",
 *   "startMs": 320,
 *   "endMs":   680
 * }
 *
 * Usage in UI:
 *   val highlightedIndex by derivedStateOf {
 *       timestamps.indexOfLast { it.startMs <= playbackPositionMs }
 *   }
 */
data class WordTimestamp(
    val word: String,
    val startMs: Long,
    val endMs: Long,
) {
    /** Duration of this word in milliseconds. */
    val durationMs: Long get() = endMs - startMs

    /** Returns true if [positionMs] falls within this word's window (inclusive). */
    fun contains(positionMs: Long): Boolean = positionMs in startMs..endMs
}

/**
 * AudioSyncMeta — Full sentence audio descriptor bundling all word timestamps.
 *
 * Stored alongside exercise data and loaded lazily (only when audio screen is active).
 */
data class AudioSyncMeta(
    val assetPath: String,              // e.g. "audio_pro/audios/lesson_01_sent_003.mp3"
    val totalDurationMs: Long,
    val words: List<WordTimestamp>,
) {
    /**
     * Returns the index of the word actively being spoken at [positionMs].
     * Returns -1 if no word is active (gap between words or before first word).
     */
    fun activeWordIndex(positionMs: Long): Int =
        words.indexOfFirst { it.contains(positionMs) }

    /**
     * Returns words that have completed playback (startMs <= positionMs).
     * Used to highlight "heard so far" portion of a dictation exercise.
     */
    fun completedWordCount(positionMs: Long): Int =
        words.count { it.startMs <= positionMs }
}
