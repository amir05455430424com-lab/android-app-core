package com.emir.englishapp.ui.widgets.character

import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.emir.englishapp.R

/**
 * Ultra-lightweight mascot banner for Compose.
 * - No bitmaps
 * - No canvas
 * - No infinite animations
 * Safe to keep above long LazyLists.
 */
@Composable
fun LearningCharacterBanner(
    mood: CharacterMood,
    message: String,
    modifier: Modifier = Modifier,
    size: CharacterSize = CharacterSize.MEDIUM,
    bubbleText: String? = null
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        tonalElevation = 0.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box {
                MascotFace(mood = mood, size = size)

                // Show speech bubble only when explicitly provided.
                if (!bubbleText.isNullOrBlank()) {
                    SpeechBubble(
                        text = bubbleText,
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(start = 36.dp)
                    )
                }
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = titleFor(mood),
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    text = message,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun MascotFace(mood: CharacterMood, size: CharacterSize) {
    val faceSize = when (size) {
        CharacterSize.SMALL -> 38.dp
        CharacterSize.MEDIUM -> 44.dp
        CharacterSize.LARGE -> 56.dp
    }

    val resId = when (mood) {
        CharacterMood.IDLE -> R.drawable.lingo_idle
        CharacterMood.THINKING -> R.drawable.lingo_thinking
        CharacterMood.HAPPY -> R.drawable.lingo_happy
        CharacterMood.ENCOURAGE -> R.drawable.lingo_encourage
        CharacterMood.WARNING -> R.drawable.lingo_warning
        CharacterMood.LEVEL_UP -> R.drawable.lingo_levelup
    }

    // Static bitmap asset: lightweight and stable on low-end devices.
    Image(
        painter = painterResource(resId),
        contentDescription = "LINGO",
        modifier = Modifier
            .size(faceSize)
            .clip(RoundedCornerShape(14.dp)),
        contentScale = ContentScale.Fit
    )
}

@Composable
private fun SpeechBubble(text: String, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 0.dp,
        shadowElevation = 0.dp
    ) {
        Text(
            text = text,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

enum class CharacterSize { SMALL, MEDIUM, LARGE }

private fun titleFor(mood: CharacterMood): String = when (mood) {
    CharacterMood.IDLE -> "LINGO"
    CharacterMood.HAPPY -> "LINGO"
    CharacterMood.ENCOURAGE -> "LINGO"
    CharacterMood.THINKING -> "LINGO"
    CharacterMood.WARNING -> "LINGO"
    CharacterMood.LEVEL_UP -> "LINGO"
}
