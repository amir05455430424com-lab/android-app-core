package com.emir.englishapp.ui.screens.lessons.levels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.emir.englishapp.data.repository.AppRepository

class LevelPickerViewModelFactory(
    private val repo: AppRepository
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return LevelPickerViewModel(repo) as T
    }
}
