package com.emir.englishapp.domain.model

data class PhraseItem(
    val id: Int,
    val ar: String,
    val en: String,
    val lessonId: Int? = null,
    val categoryKey: String? = null
)
