package com.emir.englishapp.domain.model.exercise

/**
 * ExerciseTemplate — The unified domain model for the Dynamic Offline Assessment Engine.
 *
 * Design principles:
 *  - Sealed class hierarchy: exhaustive `when` dispatch with no runtime casts.
 *  - Each subtype is self-contained: the renderer needs nothing beyond what's in the model.
 *  - Audio is optional everywhere; the engine degrades gracefully without assets.
 *  - `modality` drives the adaptive session scheduler (Visual / Auditory / Kinetic).
 *  - `difficultyScore` is 0..100, used by the SmartLocalEngine for exercise ordering.
 *
 * Exercise taxonomy:
 *  TRANSLATE_AR_EN  — AR prompt  → pick EN answer (MCQ, 4 options)
 *  TRANSLATE_EN_AR  — EN prompt  → pick AR answer (MCQ, 4 options)
 *  SENTENCE_REORDER — Scrambled EN words → tap to arrange in correct order
 *  FILL_BLANK       — EN sentence with one blank → pick correct word chip
 *  LISTEN_AND_PICK  — Play audio → pick matching AR or EN meaning
 *  SPOT_THE_ERROR   — Sentence with one wrong word → tap to identify it
 *  MATCH_PAIRS      — Two columns (EN | AR) → tap to connect matching pairs
 *  DICTATION_REORDER— Hear sentence → arrange word chips in correct order
 *  TYPE_WHAT_YOU_HEAR— Hear isolated word → pick correct EN spelling (MCQ)
 *  SENTENCE_COMPLETE — First half of sentence shown → pick correct completion
 *  WORD_SORT        — Pool of words → drag into correct category buckets
 *  PRONUNCIATION_BRIDGE — EN word shown → pick matching phonetic representation
 */

enum class LearningModality { VISUAL, AUDITORY, KINETIC }

sealed class ExerciseTemplate {

    abstract val id: String
    abstract val cefr: String               // A1 | A2 | B1 | B2 | C1
    abstract val difficultyScore: Int       // 0..100
    abstract val modality: LearningModality
    abstract val topic: String              // e.g. "family", "food", "greetings"
    abstract val explanationAr: String?     // shown in feedback overlay
    abstract val audioAssetPath: String?    // relative to assets/, null = TTS fallback

    // ─────────────────────────────────────────────────────────────
    // 1. MCQ: Arabic → English
    // ─────────────────────────────────────────────────────────────
    data class TranslateArToEn(
        override val id: String,
        override val cefr: String,
        override val difficultyScore: Int,
        override val topic: String,
        override val explanationAr: String? = null,
        override val audioAssetPath: String? = null,
        val promptAr: String,               // "ما معنى 'التفاحة'؟"
        val optionsEn: List<String>,        // 4 EN candidates
        val answerIndex: Int,
        override val modality: LearningModality = LearningModality.VISUAL,
    ) : ExerciseTemplate()

    // ─────────────────────────────────────────────────────────────
    // 2. MCQ: English → Arabic
    // ─────────────────────────────────────────────────────────────
    data class TranslateEnToAr(
        override val id: String,
        override val cefr: String,
        override val difficultyScore: Int,
        override val topic: String,
        override val explanationAr: String? = null,
        override val audioAssetPath: String? = null,
        val promptEn: String,               // full EN sentence or word
        val optionsAr: List<String>,        // 4 AR candidates
        val answerIndex: Int,
        override val modality: LearningModality = LearningModality.VISUAL,
    ) : ExerciseTemplate()

    // ─────────────────────────────────────────────────────────────
    // 3. Kinetic: Arrange scrambled words into correct EN sentence
    // ─────────────────────────────────────────────────────────────
    data class SentenceReorder(
        override val id: String,
        override val cefr: String,
        override val difficultyScore: Int,
        override val topic: String,
        override val explanationAr: String? = null,
        override val audioAssetPath: String? = null,
        val promptAr: String,               // AR translation shown as hint
        val shuffledWords: List<String>,    // word chips to arrange
        val correctOrder: List<String>,     // ground truth for validation
        override val modality: LearningModality = LearningModality.KINETIC,
    ) : ExerciseTemplate()

    // ─────────────────────────────────────────────────────────────
    // 4. MCQ: Cloze / Gap-fill — EN sentence with one blank
    // ─────────────────────────────────────────────────────────────
    data class FillBlank(
        override val id: String,
        override val cefr: String,
        override val difficultyScore: Int,
        override val topic: String,
        override val explanationAr: String? = null,
        override val audioAssetPath: String? = null,
        val sentenceWithPlaceholder: String,// "I ___ to school every day."
        val optionsEn: List<String>,        // word chips (one correct)
        val answerIndex: Int,
        val arHint: String? = null,         // optional AR translation of full sentence
        override val modality: LearningModality = LearningModality.VISUAL,
    ) : ExerciseTemplate()

    // ─────────────────────────────────────────────────────────────
    // 5. Auditory: Listen to audio → pick matching meaning (AR or EN)
    // ─────────────────────────────────────────────────────────────
    data class ListenAndPick(
        override val id: String,
        override val cefr: String,
        override val difficultyScore: Int,
        override val topic: String,
        override val explanationAr: String? = null,
        override val audioAssetPath: String?,   // REQUIRED; fallback = TTS of `correctText`
        val correctText: String,                // the phrase spoken in the audio
        val targetLanguage: AnswerLanguage,     // ARABIC or ENGLISH options shown
        val options: List<String>,              // 4 options in `targetLanguage`
        val answerIndex: Int,
        val wordTimestamps: List<WordTimestamp> = emptyList(), // ms-precise word highlighting
        override val modality: LearningModality = LearningModality.AUDITORY,
    ) : ExerciseTemplate()

    // ─────────────────────────────────────────────────────────────
    // 6. Visual: Spot the grammatically incorrect word in a sentence
    // ─────────────────────────────────────────────────────────────
    data class SpotTheError(
        override val id: String,
        override val cefr: String,
        override val difficultyScore: Int,
        override val topic: String,
        override val explanationAr: String? = null,
        override val audioAssetPath: String? = null,
        val sentenceTokens: List<String>,   // individual word chips
        val errorIndex: Int,                // which token is wrong
        val correctedWord: String,          // what the correct word should be
        val arHint: String? = null,
        override val modality: LearningModality = LearningModality.VISUAL,
    ) : ExerciseTemplate()

    // ─────────────────────────────────────────────────────────────
    // 7. Kinetic: Match pairs — two columns AR | EN
    // ─────────────────────────────────────────────────────────────
    data class MatchPairs(
        override val id: String,
        override val cefr: String,
        override val difficultyScore: Int,
        override val topic: String,
        override val explanationAr: String? = null,
        override val audioAssetPath: String? = null,
        val pairs: List<WordPair>,          // 4–6 pairs; shuffled columns derived in engine
        override val modality: LearningModality = LearningModality.KINETIC,
    ) : ExerciseTemplate()

    // ─────────────────────────────────────────────────────────────
    // 8. Auditory+Kinetic: Hear sentence → arrange word chips
    // ─────────────────────────────────────────────────────────────
    data class DictationReorder(
        override val id: String,
        override val cefr: String,
        override val difficultyScore: Int,
        override val topic: String,
        override val explanationAr: String? = null,
        override val audioAssetPath: String?,   // REQUIRED (sentence audio)
        val shuffledWords: List<String>,        // word chips shown to learner
        val correctOrder: List<String>,         // ground truth
        val wordTimestamps: List<WordTimestamp> = emptyList(),
        override val modality: LearningModality = LearningModality.AUDITORY,
    ) : ExerciseTemplate()

    // ─────────────────────────────────────────────────────────────
    // 9. Auditory: Hear isolated word → pick correct EN spelling
    // ─────────────────────────────────────────────────────────────
    data class TypeWhatYouHear(
        override val id: String,
        override val cefr: String,
        override val difficultyScore: Int,
        override val topic: String,
        override val explanationAr: String? = null,
        override val audioAssetPath: String?,   // REQUIRED (isolated word audio)
        val correctSpelling: String,            // the EN word to identify
        val options: List<String>,              // 4 EN spellings (MCQ)
        val answerIndex: Int,
        override val modality: LearningModality = LearningModality.AUDITORY,
    ) : ExerciseTemplate()

    // ─────────────────────────────────────────────────────────────
    // 10. Visual: Complete the second half of an EN sentence
    // ─────────────────────────────────────────────────────────────
    data class SentenceComplete(
        override val id: String,
        override val cefr: String,
        override val difficultyScore: Int,
        override val topic: String,
        override val explanationAr: String? = null,
        override val audioAssetPath: String? = null,
        val sentencePrefix: String,         // "She goes to school ___"
        val optionsEn: List<String>,        // completions (MCQ, one correct)
        val answerIndex: Int,
        val arHint: String? = null,
        override val modality: LearningModality = LearningModality.VISUAL,
    ) : ExerciseTemplate()

    // ─────────────────────────────────────────────────────────────
    // 11. Kinetic: Sort a pool of words into category buckets
    // ─────────────────────────────────────────────────────────────
    data class WordSort(
        override val id: String,
        override val cefr: String,
        override val difficultyScore: Int,
        override val topic: String,
        override val explanationAr: String? = null,
        override val audioAssetPath: String? = null,
        val categoryA: SortCategory,        // e.g. "Verbs / أفعال"
        val categoryB: SortCategory,        // e.g. "Nouns / أسماء"
        val wordPool: List<SortWord>,       // words to drag into buckets
        override val modality: LearningModality = LearningModality.KINETIC,
    ) : ExerciseTemplate()

    // ─────────────────────────────────────────────────────────────
    // 12. Visual: EN word → pick matching phonetic/pronunciation hint
    // ─────────────────────────────────────────────────────────────
    data class PronunciationBridge(
        override val id: String,
        override val cefr: String,
        override val difficultyScore: Int,
        override val topic: String,
        override val explanationAr: String? = null,
        override val audioAssetPath: String?,
        val wordEn: String,                 // word shown to user
        val options: List<String>,          // phonetic transcriptions or AR transliterations
        val answerIndex: Int,
        override val modality: LearningModality = LearningModality.VISUAL,
    ) : ExerciseTemplate()
}

// ─────────────────────────────────────────────────────────────
// Supporting value types
// ─────────────────────────────────────────────────────────────

enum class AnswerLanguage { ARABIC, ENGLISH }

data class WordPair(
    val en: String,
    val ar: String,
)

data class SortCategory(
    val labelEn: String,
    val labelAr: String,
)

data class SortWord(
    val text: String,
    val correctCategory: Int,   // 0 = categoryA, 1 = categoryB
)
