package com.emir.englishapp.domain.model.course

/**
 * Mirrors `course_5levels_75units_smart.json`.
 * Root: { meta, curriculum: { levels: [...], bonus_question_ids: [...] } }
 */

data class CourseMeta(
    val version: String,
    val style: String,
    val notes: String
)

data class CourseFile(
    val meta: CourseMeta,
    val curriculum: CourseCurriculum
)

data class CourseCurriculum(
    val levels: List<CourseLevel>,
    val bonusQuestionIds: List<String>
)

data class CourseLevel(
    val level: Int,
    val titleEn: String,
    val titleAr: String,
    val focusEn: String,
    val focusAr: String,
    val units: List<CourseUnit>
)

data class CourseUnit(
    val unitId: String,
    val globalIndex: Int,
    val titleEn: String,
    val titleAr: String,
    val isVip: Boolean,
    val xpReward: Int,
    val recommendedQuestions: Int,
    val pathStyle: PathStyle,
    val questionIds: List<String>
)

data class PathStyle(
    val type: String,
    val amplitude: Float,
    val step: Float,
    val xOffset: Float
)
