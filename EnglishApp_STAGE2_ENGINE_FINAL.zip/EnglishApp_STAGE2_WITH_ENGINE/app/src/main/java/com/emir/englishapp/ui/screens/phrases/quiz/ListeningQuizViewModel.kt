package com.emir.englishapp.ui.screens.phrases.quiz

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.emir.englishapp.data.repository.AppRepository
import com.emir.englishapp.domain.audio.AssetAudioPlayer
import com.emir.englishapp.domain.model.PhraseItem
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

class ListeningQuizViewModel(
    private val repo: AppRepository,
    private val audioPlayer: AssetAudioPlayer,
    private val categoryKey: String,
    private val sessionSize: Int = 10
) : ViewModel() {

    companion object {
        /** Special key for "mixed/random" training across all categories. */
        const val MIXED_CATEGORY_KEY = "__MIXED__"

        /** A phrase becomes "mastered" when answered correctly this many times. */
        private const val MASTERED_THRESHOLD = 2
    }

    private val _uiState = MutableStateFlow(
        ListeningQuizUiState(categoryKey = categoryKey, totalQuestions = sessionSize)
    )
    val uiState: StateFlow<ListeningQuizUiState> = _uiState.asStateFlow()

    /** Guard to prevent awarding XP multiple times (e.g., repeated finish events). */
    private var xpAwarded: Boolean = false

    // Full pool for this quiz mode (category or mixed)
    private var pool: List<PhraseItem> = emptyList()

    // Session state
    private val usedInSession = HashSet<Int>()
    private val usedByCategoryInSession = HashMap<String, HashSet<Int>>() // for mixed balancing

    // Mastery stats loaded from DataStore
    private val correctCounts: MutableMap<Int, Int> = HashMap()

    private var correctPhrase: PhraseItem? = null

    init {
        load()
    }

    private fun load() {
        viewModelScope.launch {
            _uiState.value = ListeningQuizUiState(
                isLoading = true,
                categoryKey = categoryKey,
                currentIndex = 1,
                totalQuestions = sessionSize,
                correctCount = 0,
                isFinished = false
            )

            // Load mastery map first
            correctCounts.clear()
            correctCounts.putAll(runCatching { repo.getQuizCorrectCounts() }.getOrDefault(emptyMap()))

            val loader = suspend {
                if (categoryKey == MIXED_CATEGORY_KEY) repo.getAllPhrases()
                else repo.getPhrasesForCategory(categoryKey)
            }

            runCatching { loader() }
                .onSuccess { list ->
                    pool = list
                        .filter { it.id > 0 && it.ar.isNotBlank() && it.en.isNotBlank() }
                        .distinctBy { it.id }

                    if (pool.size < 4) {
                        _uiState.value = ListeningQuizUiState(
                            isLoading = false,
                            categoryKey = categoryKey,
                            errorMessage = "هذا القسم لا يحتوي على جمل كافية للاختبار (يجب 4 على الأقل).",
                            currentIndex = 1,
                            totalQuestions = sessionSize,
                            correctCount = 0,
                            isFinished = false
                        )
                        return@onSuccess
                    }

                    usedInSession.clear()
                    usedByCategoryInSession.clear()

                    // Session length: for mixed, keep requested size; for tiny categories, shrink.
                    val total = if (categoryKey == MIXED_CATEGORY_KEY) sessionSize
                    else min(sessionSize, max(1, pool.size))
                    _uiState.value = _uiState.value.copy(totalQuestions = total)

                    // Auto-play audio when the first question appears.
                    buildNewQuestion(play = true)
                }
                .onFailure { e ->
                    _uiState.value = ListeningQuizUiState(
                        isLoading = false,
                        categoryKey = categoryKey,
                        errorMessage = e.message ?: "Error loading quiz",
                        currentIndex = 1,
                        totalQuestions = sessionSize,
                        correctCount = 0,
                        isFinished = false
                    )
                }
        }
    }

    // -------- Smart selection --------

    private fun isMastered(id: Int): Boolean = (correctCounts[id] ?: 0) >= MASTERED_THRESHOLD

    private fun difficultyScore(p: PhraseItem): Int {
        // Simple but effective heuristic: longer sentences & more tokens are harder.
        // Stable and offline-friendly (no NLP required).
        val en = p.en.trim()
        val tokens = en.split(Regex("\\s+")).filter { it.isNotBlank() }.size
        val chars = en.length
        val punctuation = en.count { it in listOf(',', ';', ':', '!', '?') }
        return tokens * 20 + chars + punctuation * 15
    }

    private fun pickCorrectCandidate(): PhraseItem {
        val total = _uiState.value.totalQuestions.coerceAtLeast(1)
        val idx = _uiState.value.currentIndex.coerceIn(1, total)

        // Difficulty ramp: from easy -> hard
        val t = if (total == 1) 0f else (idx - 1).toFloat() / (total - 1).toFloat()

        // Build candidates not used in this session
        val available = pool.filter { it.id !in usedInSession }

        // Prefer non-mastered as "correct answers"
        val primary = available.filter { !isMastered(it.id) }

        val base = if (primary.size >= 4) primary else available

        // Mixed mode: try to balance categories (round-robin feel)
        val balanced = if (categoryKey == MIXED_CATEGORY_KEY) {
            val groups = base.groupBy { it.categoryKey ?: "unknown" }
            // pick from category with least picks in this session
            val targetCat = groups.keys.minByOrNull { usedByCategoryInSession[it]?.size ?: 0 } ?: "unknown"
            val catItems = groups[targetCat].orEmpty().filter { it.id !in (usedByCategoryInSession[targetCat] ?: emptySet()) }
            if (catItems.isNotEmpty()) catItems else base
        } else base

        // Difficulty band selection using sorted list
        val sorted = balanced.sortedBy { difficultyScore(it) }
        val n = sorted.size
        if (n == 0) return pool.random()

        val center = (t * (n - 1)).toInt()
        var radius = max(3, (n * 0.15f).toInt())

        // Expand band until we find something
        for (attempt in 0..4) {
            val from = max(0, center - radius)
            val to = min(n - 1, center + radius)
            val band = sorted.subList(from, to + 1)

            val pick = band.randomOrNull()
            if (pick != null) return pick

            radius = min(n, radius * 2)
        }

        // Fallback
        return sorted[center]
    }

    private fun buildOptions(correctItem: PhraseItem): List<ListeningQuizUiState.OptionItem> {
        // Options can include mastered items; that's fine. Just keep them distinct.
        val optionSet = LinkedHashSet<PhraseItem>()
        optionSet.add(correctItem)

        val available = pool.filter { it.id != correctItem.id }
        while (optionSet.size < 4 && available.isNotEmpty()) {
            optionSet.add(available[Random.nextInt(available.size)])
        }

        return optionSet.toList()
            .shuffled()
            .map { ListeningQuizUiState.OptionItem(it.id, it.ar) }
    }

    private fun buildNewQuestion(play: Boolean) {
        val s = _uiState.value
        if (s.isFinished) return

        // If we've used almost everything, reset "no repeats" guard (bank exhausted).
        // This keeps the quiz always playable even with small pools.
        if (usedInSession.size >= pool.size - 1) {
            usedInSession.clear()
            usedByCategoryInSession.clear()
        }

        val correctItem = pickCorrectCandidate()
        correctPhrase = correctItem

        // Mark used for session balance
        usedInSession.add(correctItem.id)
        val cat = correctItem.categoryKey ?: "unknown"
        usedByCategoryInSession.getOrPut(cat) { HashSet() }.add(correctItem.id)

        val options = buildOptions(correctItem)

        _uiState.value = s.copy(
            isLoading = false,
            errorMessage = null,
            questionId = correctItem.id,
            questionEn = correctItem.en,
            options = options,
            correctOptionId = correctItem.id,
            selectedOptionId = null,
            isCorrect = null,
            feedbackMessage = null,
            canGoNext = false
        )

        if (play) playQuestionAudio()
    }

    // -------- Public API --------

    fun playQuestionAudio() {
        val id = _uiState.value.questionId ?: return
        audioPlayer.play("sounds/e$id.mp3")
    }

    fun selectAnswer(optionId: Int) {
        if (_uiState.value.selectedOptionId != null) return

        val correctId = correctPhrase?.id ?: return
        val ok = optionId == correctId

        val correctAr = _uiState.value.options.firstOrNull { it.id == correctId }?.arText.orEmpty()
        val feedback = if (ok) {
            "🔥 ممتاز! إجابة صحيحة."
        } else {
            if (correctAr.isBlank()) "❌ ليست صحيحة. جرّب التالي!" else "❌ ليست صحيحة. الصحيح: $correctAr"
        }

        _uiState.value = _uiState.value.copy(
            selectedOptionId = optionId,
            isCorrect = ok,
            feedbackMessage = feedback,
            canGoNext = true,
            correctCount = _uiState.value.correctCount + (if (ok) 1 else 0)
        )

        if (ok) {
            // Persist mastery progress (async)
            viewModelScope.launch {
                repo.incrementQuizCorrect(correctId)
                correctCounts[correctId] = (correctCounts[correctId] ?: 0) + 1
            }
        }
    }

    fun nextQuestion() {
        val s = _uiState.value
        if (s.isFinished) return
        if (!s.canGoNext) return

        val nextIndex = s.currentIndex + 1
        if (nextIndex > s.totalQuestions) {
            val earned = s.correctCount * 10
            _uiState.value = s.copy(
                isFinished = true,
                canGoNext = false,
                xpEarned = earned
            )

            // Persist XP once.
            if (!xpAwarded) {
                xpAwarded = true
                if (earned > 0) {
                    viewModelScope.launch { repo.addTotalXp(earned) }
                }
            }
            return
        }

        _uiState.value = s.copy(
            currentIndex = nextIndex,
            canGoNext = false,
            selectedOptionId = null,
            isCorrect = null,
            feedbackMessage = null
        )

        // Auto-play audio for the next question.
        buildNewQuestion(play = true)
    }

    fun restart() {
        audioPlayer.stop()
        load()
    }

    override fun onCleared() {
        audioPlayer.stop()
        super.onCleared()
    }

    // Extension: randomOrNull for older Kotlin stdlib
    private fun <T> List<T>.randomOrNull(): T? = if (isEmpty()) null else this[Random.nextInt(size)]
}
