package com.emir.englishapp.ui.screens.assessment

import androidx.compose.runtime.Composable
import com.emir.englishapp.domain.model.exercise.ExerciseTemplate

/**
 * ExerciseScreenEngine — Compose dispatcher (the "View" side of the decoupled engine).
 *
 * Contract:
 *  - PURE UI: no business logic, no state mutation. Reads [state], fires [onEvent].
 *  - EXHAUSTIVE: every ExerciseTemplate subtype is handled; missing branches → compile error.
 *  - EXTENSIBLE: to add a new exercise type, implement the composable in ExerciseBlocks.kt
 *    and add one branch here. Zero changes to the engine core.
 *
 * The engine is decoupled from the view layer by the [ExerciseTemplate] contract:
 * the Screen Engine only receives the template (data) and the state snapshot (read-only),
 * never touching the SessionOrchestrator directly.
 */
@Composable
fun ExerciseScreenEngine(
    state: AssessmentUiState,
    onEvent: (AssessmentEvent) -> Unit,
) {
    val snapshot = state.snapshot
    val ex = snapshot.currentExercise ?: return

    when (ex) {

        // ── Visual ──────────────────────────────────────────────────────────

        is ExerciseTemplate.TranslateEnToAr -> TranslateEnToArBlock(
            exercise = ex,
            selectedIndex = snapshot.selectedIndex,
            isAnswered = snapshot.isAnswered,
            isCorrect = snapshot.isCorrect,
            onSelect = { onEvent(AssessmentEvent.SelectOption(it)) },
        )

        is ExerciseTemplate.TranslateArToEn -> TranslateArToEnBlock(
            exercise = ex,
            selectedIndex = snapshot.selectedIndex,
            isAnswered = snapshot.isAnswered,
            isCorrect = snapshot.isCorrect,
            onSelect = { onEvent(AssessmentEvent.SelectOption(it)) },
        )

        is ExerciseTemplate.FillBlank -> FillBlankBlock(
            exercise = ex,
            selectedIndex = snapshot.selectedIndex,
            isAnswered = snapshot.isAnswered,
            isCorrect = snapshot.isCorrect,
            onSelect = { onEvent(AssessmentEvent.SelectOption(it)) },
        )

        is ExerciseTemplate.SpotTheError -> SpotTheErrorBlock(
            exercise = ex,
            tappedIndex = snapshot.tappedTokenIndex,
            isAnswered = snapshot.isAnswered,
            isCorrect = snapshot.isCorrect,
            onTapToken = { onEvent(AssessmentEvent.TapToken(it)) },
        )

        is ExerciseTemplate.SentenceComplete -> SentenceCompleteBlock(
            exercise = ex,
            selectedIndex = snapshot.selectedIndex,
            isAnswered = snapshot.isAnswered,
            isCorrect = snapshot.isCorrect,
            onSelect = { onEvent(AssessmentEvent.SelectOption(it)) },
        )

        is ExerciseTemplate.PronunciationBridge -> PronunciationBridgeBlock(
            exercise = ex,
            selectedIndex = snapshot.selectedIndex,
            isAnswered = snapshot.isAnswered,
            isCorrect = snapshot.isCorrect,
            onSelect = { onEvent(AssessmentEvent.SelectOption(it)) },
            onPlayAudio = { onEvent(AssessmentEvent.PlayAudio) },
            audioState = state.audioState,
        )

        // ── Kinetic ─────────────────────────────────────────────────────────

        is ExerciseTemplate.SentenceReorder -> SentenceReorderBlock(
            exercise = ex,
            available = snapshot.reorderAvailable,
            selected = snapshot.reorderSelected,
            isAnswered = snapshot.isAnswered,
            isCorrect = snapshot.isCorrect,
            onPick = { onEvent(AssessmentEvent.PickWord(it)) },
            onUnpick = { onEvent(AssessmentEvent.UnpickWord(it)) },
        )

        is ExerciseTemplate.MatchPairs -> MatchPairsBlock(
            exercise = ex,
            matchState = snapshot.matchState,
            isAnswered = snapshot.isAnswered,
            isCorrect = snapshot.isCorrect,
            onTapLeft = { onEvent(AssessmentEvent.TapMatchLeft(it)) },
            onTapRight = { onEvent(AssessmentEvent.TapMatchRight(it)) },
        )

        is ExerciseTemplate.WordSort -> WordSortBlock(
            exercise = ex,
            sortState = snapshot.sortState,
            isAnswered = snapshot.isAnswered,
            isCorrect = snapshot.isCorrect,
            onSort = { word, cat -> onEvent(AssessmentEvent.SortWord(word, cat)) },
        )

        // ── Auditory ────────────────────────────────────────────────────────

        is ExerciseTemplate.ListenAndPick -> ListenAndPickBlock(
            exercise = ex,
            selectedIndex = snapshot.selectedIndex,
            isAnswered = snapshot.isAnswered,
            isCorrect = snapshot.isCorrect,
            audioState = state.audioState,
            onSelect = { onEvent(AssessmentEvent.SelectOption(it)) },
            onPlayAudio = { onEvent(AssessmentEvent.PlayAudio) },
        )

        is ExerciseTemplate.DictationReorder -> DictationReorderBlock(
            exercise = ex,
            available = snapshot.reorderAvailable,
            selected = snapshot.reorderSelected,
            isAnswered = snapshot.isAnswered,
            isCorrect = snapshot.isCorrect,
            audioState = state.audioState,
            onPick = { onEvent(AssessmentEvent.PickWord(it)) },
            onUnpick = { onEvent(AssessmentEvent.UnpickWord(it)) },
            onPlayAudio = { onEvent(AssessmentEvent.PlayAudio) },
        )

        is ExerciseTemplate.TypeWhatYouHear -> TypeWhatYouHearBlock(
            exercise = ex,
            selectedIndex = snapshot.selectedIndex,
            isAnswered = snapshot.isAnswered,
            isCorrect = snapshot.isCorrect,
            audioState = state.audioState,
            onSelect = { onEvent(AssessmentEvent.SelectOption(it)) },
            onPlayAudio = { onEvent(AssessmentEvent.PlayAudio) },
        )
    }
}
