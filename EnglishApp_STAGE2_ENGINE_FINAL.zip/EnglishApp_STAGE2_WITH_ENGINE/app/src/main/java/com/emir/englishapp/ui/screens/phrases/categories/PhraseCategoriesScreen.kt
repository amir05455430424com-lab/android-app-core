package com.emir.englishapp.ui.screens.phrases.categories

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.emir.englishapp.domain.model.PhraseCategory

@Composable
fun PhraseCategoriesScreen(
    state: PhraseCategoriesUiState,
    onBack: () -> Unit,
    onCategoryClick: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) {
            Text("رجوع")
        }

        Text("أقسام الجمل", style = MaterialTheme.typography.titleLarge)

        if (state.isLoading) {
            Text("تحميل...", style = MaterialTheme.typography.bodyMedium)
            return
        }

        state.errorMessage?.let {
            Text(it, style = MaterialTheme.typography.bodyMedium)
            return
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item(key = "mixed") {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    onClick = { onCategoryClick("__MIXED__") }
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text("✨  تدريب عشوائي", style = MaterialTheme.typography.titleMedium)
                        Text("Random Training", style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }

            items(state.categories, key = { it.key }) { category ->
                CategoryCard(
                    category = category,
                    onClick = { onCategoryClick(category.key) }
                )
            }
        }
    }
}

@Composable
private fun CategoryCard(
    category: PhraseCategory,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        onClick = onClick
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("${iconEmoji(category.icon)}  ${category.titleAr}", style = MaterialTheme.typography.titleMedium)
            Text(category.titleEn, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

private fun iconEmoji(icon: String): String {
    return when (icon.lowercase()) {
        "chat" -> "💬"
        "family" -> "👨‍👩‍👧‍👦"
        "school" -> "🏫"
        "food" -> "🍽️"
        "travel" -> "✈️"
        "weather" -> "🌦️"
        else -> "📌"
    }
}
