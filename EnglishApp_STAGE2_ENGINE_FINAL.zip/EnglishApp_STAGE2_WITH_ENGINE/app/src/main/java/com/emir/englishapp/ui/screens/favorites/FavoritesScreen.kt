package com.emir.englishapp.ui.screens.favorites

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.emir.englishapp.domain.model.PhraseItem
import com.emir.englishapp.domain.model.question.Question

private enum class FavTab { ALL, QUESTIONS, PHRASES, LESSONS }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FavoritesScreen(
    state: FavoritesUiState,
    onToggleQuestionFavorite: (String) -> Unit,
    onTogglePhraseFavorite: (String) -> Unit,
    onToggleLessonFavorite: (String) -> Unit
) {
    Surface(color = MaterialTheme.colorScheme.background) {
        when {
            state.isLoading -> CenterMessage("جاري التحميل...")
            state.error != null -> CenterMessage(state.error)
            state.favoriteQuestions.isEmpty() && state.favoritePhrases.isEmpty() && state.favoriteLessons.isEmpty() ->
                EmptyFavorites()
            else -> FavoritesContent(
                state = state,
                onToggleQuestionFavorite = onToggleQuestionFavorite,
                onTogglePhraseFavorite = onTogglePhraseFavorite,
                onToggleLessonFavorite = onToggleLessonFavorite
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FavoritesContent(
    state: FavoritesUiState,
    onToggleQuestionFavorite: (String) -> Unit,
    onTogglePhraseFavorite: (String) -> Unit,
    onToggleLessonFavorite: (String) -> Unit
) {
    var tab by remember { mutableIntStateOf(0) }
    var query by remember { mutableStateOf("") }

    val qCount = state.favoriteQuestions.size
    val pCount = state.favoritePhrases.size
    val lCount = state.favoriteLessons.size
    val allCount = qCount + pCount + lCount

    val currentTab = when (tab) {
        1 -> FavTab.QUESTIONS
        2 -> FavTab.PHRASES
        3 -> FavTab.LESSONS
        else -> FavTab.ALL
    }

    val filteredQuestions by remember(state.favoriteQuestions, query) {
        derivedStateOf {
            if (query.isBlank()) state.favoriteQuestions else state.favoriteQuestions.filter { q ->
                val hay = buildString {
                    append(q.id); append(' ')
                    append(q.promptEn); append(' ')
                    q.promptAr?.let { append(it); append(' ') }
                    append(q.cefr); append(' ')
                    if (q.tags.isNotEmpty()) append(q.tags.joinToString(" "))
                }
                hay.contains(query, ignoreCase = true)
            }
        }
    }

    val filteredPhrases by remember(state.favoritePhrases, query) {
        derivedStateOf {
            if (query.isBlank()) state.favoritePhrases else state.favoritePhrases.filter { p ->
                val hay = "${p.id} ${p.ar} ${p.en} ${p.categoryKey.orEmpty()}"
                hay.contains(query, ignoreCase = true)
            }
        }
    }

    val filteredLessons by remember(state.favoriteLessons, query) {
        derivedStateOf {
            if (query.isBlank()) state.favoriteLessons else state.favoriteLessons.filter { l ->
                val hay = "${l.key} ${l.titleAr} ${l.titleEn}"
                hay.contains(query, ignoreCase = true)
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp, vertical = 10.dp)
    ) {
        Text(
            text = "المفضلة",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.ExtraBold
        )
        Spacer(Modifier.height(10.dp))

        OutlinedTextField(
            modifier = Modifier.fillMaxWidth(),
            value = query,
            onValueChange = { query = it },
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            placeholder = { Text("ابحث في المفضلة...") },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
            trailingIcon = {
                if (query.isNotBlank()) {
                    IconButton(onClick = { query = "" }) {
                        Icon(Icons.Filled.Close, contentDescription = null)
                    }
                }
            },
            colors = OutlinedTextFieldDefaults.colors()
        )

        Spacer(Modifier.height(10.dp))

        ScrollableTabRow(
            selectedTabIndex = tab,
            edgePadding = 0.dp
        ) {
            Tab(
                selected = tab == 0,
                onClick = { tab = 0 },
                text = { Text("الكل ⭐ ($allCount)") }
            )
            Tab(
                selected = tab == 1,
                onClick = { tab = 1 },
                text = { Text("الأسئلة ❓ ($qCount)") }
            )
            Tab(
                selected = tab == 2,
                onClick = { tab = 2 },
                text = { Text("الجمل 💬 ($pCount)") }
            )
            Tab(
                selected = tab == 3,
                onClick = { tab = 3 },
                text = { Text("الدروس 📘 ($lCount)") }
            )
        }

        Spacer(Modifier.height(10.dp))

        when (currentTab) {
            FavTab.ALL -> FavoritesAll(
                questions = filteredQuestions,
                phrases = filteredPhrases,
                lessons = filteredLessons,
                onToggleQuestionFavorite = onToggleQuestionFavorite,
                onTogglePhraseFavorite = onTogglePhraseFavorite,
                onToggleLessonFavorite = onToggleLessonFavorite
            )
            FavTab.QUESTIONS -> FavoritesQuestions(
                questions = filteredQuestions,
                onToggleQuestionFavorite = onToggleQuestionFavorite
            )
            FavTab.PHRASES -> FavoritesPhrases(
                phrases = filteredPhrases,
                onTogglePhraseFavorite = onTogglePhraseFavorite
            )
            FavTab.LESSONS -> FavoritesLessons(
                lessons = filteredLessons,
                onToggleLessonFavorite = onToggleLessonFavorite
            )
        }
    }
}

@Composable
private fun FavoritesAll(
    questions: List<Question>,
    phrases: List<PhraseItem>,
    lessons: List<FavoriteLessonEntry>,
    onToggleQuestionFavorite: (String) -> Unit,
    onTogglePhraseFavorite: (String) -> Unit,
    onToggleLessonFavorite: (String) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (lessons.isNotEmpty()) {
            item { SectionHeader("الدروس") }
            items(lessons, key = { it.key }) { l ->
                FavoriteSimpleCard(
                    title = l.titleAr.ifBlank { l.titleEn },
                    subtitle = "Lesson • ${levelLabelFromKey(l.key)}",
                    onRemove = { onToggleLessonFavorite(l.key) }
                )
            }
        }

        if (phrases.isNotEmpty()) {
            item { SectionHeader("الجمل") }
            // group by category
            val grouped = phrases.groupBy { it.categoryKey.orEmpty().ifBlank { "other" } }
            grouped.forEach { (cat, list) ->
                item { SubHeader("قسم: $cat (${list.size})") }
                items(list, key = { it.id }) { p ->
                    FavoriteSimpleCard(
                        title = p.ar,
                        subtitle = p.en,
                        onRemove = { onTogglePhraseFavorite(p.id.toString()) }
                    )
                }
            }
        }

        if (questions.isNotEmpty()) {
            item { SectionHeader("الأسئلة") }
            // group by first tag
            val groupedQ = questions.groupBy { it.tags.firstOrNull().orEmpty().ifBlank { "general" } }
            groupedQ.forEach { (tag, list) ->
                item { SubHeader("#$tag (${list.size})") }
                items(list, key = { it.id }) { q ->
                    FavoriteQuestionCard(q = q, onToggleFavorite = onToggleQuestionFavorite)
                }
            }
        }

        if (lessons.isEmpty() && phrases.isEmpty() && questions.isEmpty()) {
            item { EmptyFavorites() }
        }
    }
}

@Composable
private fun FavoritesQuestions(
    questions: List<Question>,
    onToggleQuestionFavorite: (String) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (questions.isEmpty()) item { EmptyTab("لا توجد أسئلة مفضلة.") }
        else items(questions, key = { it.id }) { q ->
            FavoriteQuestionCard(q = q, onToggleFavorite = onToggleQuestionFavorite)
        }
    }
}

@Composable
private fun FavoritesPhrases(
    phrases: List<PhraseItem>,
    onTogglePhraseFavorite: (String) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (phrases.isEmpty()) {
            item { EmptyTab("لا توجد جمل مفضلة.") }
            return@LazyColumn
        }
        val grouped = phrases.groupBy { it.categoryKey.orEmpty().ifBlank { "other" } }
        grouped.forEach { (cat, list) ->
            item { SubHeader("قسم: $cat (${list.size})") }
            items(list, key = { it.id }) { p ->
                FavoriteSimpleCard(
                    title = p.ar,
                    subtitle = p.en,
                    onRemove = { onTogglePhraseFavorite(p.id.toString()) }
                )
            }
        }
    }
}

@Composable
private fun FavoritesLessons(
    lessons: List<FavoriteLessonEntry>,
    onToggleLessonFavorite: (String) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (lessons.isEmpty()) {
            item { EmptyTab("لا توجد دروس مفضلة.") }
            return@LazyColumn
        }
        val grouped = lessons.groupBy { levelLabelFromKey(it.key) }
        grouped.forEach { (lvl, list) ->
            item { SubHeader("$lvl (${list.size})") }
            items(list, key = { it.key }) { l ->
                FavoriteSimpleCard(
                    title = l.titleAr.ifBlank { l.titleEn },
                    subtitle = "Lesson",
                    onRemove = { onToggleLessonFavorite(l.key) }
                )
            }
        }
    }
}

@Composable
private fun FavoriteSimpleCard(
    title: String,
    subtitle: String,
    onRemove: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                if (subtitle.isNotBlank()) {
                    Spacer(Modifier.height(4.dp))
                    Text(subtitle, style = MaterialTheme.typography.bodyMedium)
                }
            }
            IconButton(onClick = onRemove) {
                Icon(Icons.Filled.Star, contentDescription = "Remove")
            }
        }
    }
}

@Composable
private fun FavoriteQuestionCard(
    q: Question,
    onToggleFavorite: (String) -> Unit
) {
    val prompt = q.promptEn.ifBlank { q.promptAr.orEmpty() }
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth().padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("CEFR ${q.cefr}", style = MaterialTheme.typography.labelMedium)
                    Text(prompt, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    if (q.tags.isNotEmpty()) {
                        Spacer(Modifier.height(4.dp))
                        Text("#${q.tags.first()}", style = MaterialTheme.typography.bodySmall)
                    }
                }
                IconButton(onClick = { onToggleFavorite(q.id) }) {
                    Icon(Icons.Filled.Star, contentDescription = "Remove")
                }
            }
        }
    }
}

@Composable
private fun SectionHeader(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(top = 6.dp, bottom = 2.dp)
    )
}

@Composable
private fun SubHeader(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.bodyMedium,
        fontWeight = FontWeight.Medium,
        modifier = Modifier.padding(top = 8.dp, bottom = 2.dp)
    )
}

@Composable
private fun CenterMessage(msg: String) {
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) { Text(msg) }
}

@Composable
private fun EmptyFavorites() {
    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("لا توجد عناصر في المفضلة حتى الآن ⭐", fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("اضغط ⭐ لإضافة الدروس/الجمل/الأسئلة للمفضلة")
    }
}

@Composable
private fun EmptyTab(text: String) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
            Text(text)
        }
    }
}

private fun levelLabelFromKey(key: String): String {
    val levelId = key.split("|").firstOrNull()?.toIntOrNull()
    return if (levelId != null) "Level $levelId" else "Level"
}
