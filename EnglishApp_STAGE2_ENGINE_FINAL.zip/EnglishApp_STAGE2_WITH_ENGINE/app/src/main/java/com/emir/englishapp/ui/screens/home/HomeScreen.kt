package com.emir.englishapp.ui.screens.home

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.emir.englishapp.ui.widgets.character.CharacterMood
import com.emir.englishapp.ui.widgets.character.CharacterSize
import com.emir.englishapp.ui.widgets.character.LearningCharacterBanner

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    state: HomeUiState,
    onOneMinuteSession: () -> Unit,
    onOpenAudioPro: () -> Unit,
    onOpenLessons: () -> Unit,
    onOpenPhrases: () -> Unit,
    onOpenProPath: () -> Unit,
    onRefresh: (() -> Unit)? = null
) {
    LaunchedEffect(Unit) {
        onRefresh?.invoke()
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("English Pro", fontWeight = FontWeight.Black) },
                actions = {
                    TextButton(onClick = {}) {
                        Text("🔥 ${state.streakDays}", fontWeight = FontWeight.Bold, color = Color(0xFFFF9600))
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(containerColor = Color.White)
            )
        },
        bottomBar = {
            NavigationBar(containerColor = Color.White, tonalElevation = 8.dp) {
                NavigationBarItem(
                    selected = true,
                    onClick = { /* Already Home */ },
                    icon = { Icon(Icons.Default.Home, "Home") },
                    label = { Text("الرئيسية") }
                )
                NavigationBarItem(
                    selected = false,
                    onClick = onOpenProPath,
                    icon = { Icon(Icons.Default.Map, "Path") },
                    label = { Text("المسار") }
                )
                NavigationBarItem(
                    selected = false,
                    onClick = { /* TODO Profile */ },
                    icon = { Icon(Icons.Default.Person, "Profile") },
                    label = { Text("حسابي") }
                )
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            val homeMood = when {
                state.dailyDone -> CharacterMood.HAPPY
                state.streakDays >= 5 && state.xpToday == 0 -> CharacterMood.WARNING
                else -> CharacterMood.IDLE
            }
            val homeBubble: String? = when {
                state.dailyDone -> "رائع 👏 كمل المسار"
                state.streakDays >= 5 && state.xpToday == 0 -> "لا تكسر الستريك 🔥"
                else -> null
            }
            LearningCharacterBanner(
                mood = homeMood,
                message = "ابدأ جلسة اليوم — 20 سؤال بسرعة",
                size = CharacterSize.SMALL,
                bubbleText = homeBubble
            )

            // 3D Primary CTA
            Button3D(
                text = state.primaryCtaTitle,
                onClick = onOneMinuteSession,
                modifier = Modifier.fillMaxWidth(),
                containerColor = Color(0xFF58CC02),
                shadowColor = Color(0xFF58A700)
            )

            // Path Entry as 3D Button
            Button3D(
                text = "🧭 افتح المسار",
                onClick = onOpenProPath,
                modifier = Modifier.fillMaxWidth(),
                containerColor = Color(0xFF1CB0F6),
                shadowColor = Color(0xFF1899D6)
            )

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button3D(
                    text = "📚 الدروس",
                    onClick = onOpenLessons,
                    modifier = Modifier.weight(1f),
                    containerColor = Color(0xFFFF9600),
                    shadowColor = Color(0xFFD67E00)
                )
                Button3D(
                    text = "💬 الجمل",
                    onClick = onOpenPhrases,
                    modifier = Modifier.weight(1f),
                    containerColor = Color(0xFFCE82FF),
                    shadowColor = Color(0xFFA559D6)
                )
            }
            
            // Audio Pro
            Button3D(
                text = "🎧 اختبار صوت PRO",
                onClick = onOpenAudioPro,
                modifier = Modifier.fillMaxWidth(),
                containerColor = Color(0xFF4B4B4B),
                shadowColor = Color(0xFF2E2E2E)
            )
        }
    }
}

@Composable
fun Button3D(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    containerColor: Color,
    shadowColor: Color
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val offsetY by animateDpAsState(if (isPressed) 6.dp else 0.dp, label = "offset")

    Box(
        modifier = modifier
            .height(70.dp)
            .clickable(interactionSource = interactionSource, indication = null, onClick = onClick),
        contentAlignment = Alignment.BottomCenter
    ) {
        // Shadow
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(60.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(shadowColor)
        )
        // Main
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 6.dp + offsetY)
                .height(60.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(containerColor),
            contentAlignment = Alignment.Center
        ) {
            Text(text, color = Color.White, fontWeight = FontWeight.Black)
        }
    }
}
