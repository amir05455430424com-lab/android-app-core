package com.emir.englishapp.domain.audio

import android.content.Context
import android.media.MediaPlayer

/**
 * Plays audio files stored in assets.
 *
 * v2 additions:
 *  - [isPlaying]          — polling-safe live state
 *  - [currentPositionMs]  — ms-precise playback position for word highlighting
 *  - [durationMs]         — total duration for progress bar
 *
 * SAFE: never crashes the app if the asset is missing or corrupted.
 */
class AssetAudioPlayer(
    private val appContext: Context
) {
    private var mediaPlayer: MediaPlayer? = null
    private var _isPlaying = false

    fun play(assetRelativePath: String) {
        try {
            val mp = (mediaPlayer ?: MediaPlayer().also { mediaPlayer = it }).apply {
                reset()
                _isPlaying = false

                setOnPreparedListener {
                    it.start()
                    _isPlaying = true
                }
                setOnCompletionListener {
                    _isPlaying = false
                    stop()
                }
                setOnErrorListener { _, _, _ ->
                    _isPlaying = false
                    stop()
                    true
                }
            }

            val afd = appContext.assets.openFd(assetRelativePath)
            mp.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
            afd.close()
            mp.prepareAsync()

        } catch (_: Throwable) {
            _isPlaying = false
            stop()
        }
    }

    fun stop() {
        _isPlaying = false
        mediaPlayer?.run {
            try { stop() } catch (_: Throwable) {}
            try { release() } catch (_: Throwable) {}
        }
        mediaPlayer = null
    }

    /** Returns true while audio is actively playing. Safe to call on any thread. */
    fun isPlaying(): Boolean =
        _isPlaying && (mediaPlayer?.isPlaying == true)

    /** Current playback position in milliseconds. Returns 0 if not playing. */
    fun currentPositionMs(): Long =
        try { mediaPlayer?.currentPosition?.toLong() ?: 0L } catch (_: Throwable) { 0L }

    /** Total audio duration in milliseconds. Returns 0 if not prepared yet. */
    fun durationMs(): Long =
        try { mediaPlayer?.duration?.toLong()?.coerceAtLeast(0L) ?: 0L } catch (_: Throwable) { 0L }

    fun release() = stop()
}
