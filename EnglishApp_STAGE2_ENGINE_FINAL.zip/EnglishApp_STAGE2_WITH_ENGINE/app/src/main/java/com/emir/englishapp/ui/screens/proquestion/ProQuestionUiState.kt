package com.emir.englishapp.ui.screens.proquestion

import com.emir.englishapp.domain.model.questionv2.QuestionV2

data class ProQuestionUiState(
    val globalIndex: Int = 1,
    val stepIndex: Int = 0,
    val stepsTotal: Int = 4,
    val unitTitleAr: String = "",
    val unitTitleEn: String = "",
    val xpReward: Int = 0,

    val questions: List<QuestionV2> = emptyList(),
    val index: Int = 0,

    // MCQ / FillBlank
    val selectedIndex: Int? = null,

    // Reorder
    val reorderAvailable: List<String> = emptyList(),
    val reorderSelected: List<String> = emptyList(),

    val isAnswered: Boolean = false,
    val isCorrect: Boolean? = null,
    val feedbackText: String? = null,

    // streak (motivation)
    val streakCorrect: Int = 0,

    val isLoading: Boolean = false,
    val error: String? = null,
    val favoriteIds: Set<String> = emptySet(),

    // stats
    val correctCount: Int = 0,
    val questionStartedAtMs: Long = 0L,
    val totalAnswerTimeMs: Long = 0L,
)
