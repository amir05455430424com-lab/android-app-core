package com.emir.englishapp.ui.screens.phrases.categories

import com.emir.englishapp.domain.model.PhraseCategory

data class PhraseCategoriesUiState(
    val isLoading: Boolean = true,
    val errorMessage: String? = null,
    val categories: List<PhraseCategory> = emptyList()
)
