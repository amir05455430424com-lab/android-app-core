package com.emir.englishapp.ui.screens.lessons.lesson

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.emir.englishapp.domain.model.lesson.CardItem

@Composable
fun LessonScreen(
    viewModel: LessonViewModel,
    onBack: () -> Unit,
    onStartPractice: (levelId: Int, lessonId: String) -> Unit = { _, _ -> }
) {
    val uiState by viewModel.uiState.collectAsState()

    LaunchedEffect(Unit) { viewModel.load() }

    LessonScreen(
        uiState = uiState,
        onPrev = { viewModel.prev() },
        onNext = { viewModel.next() },
        onStartPractice = { onStartPractice(viewModel.levelId, viewModel.lessonId) }
    )
}

@Composable
fun LessonScreen(
    uiState: LessonUiState,
    onPrev: () -> Unit,
    onNext: () -> Unit,
    onStartPractice: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {

        when {
            uiState.isLoading -> {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                    CircularProgressIndicator()
                }
                return
            }
            uiState.error != null -> {
                Text(uiState.error, color = MaterialTheme.colorScheme.error)
                return
            }
        }

        val total = uiState.cards.size.coerceAtLeast(1)
        val step = uiState.index.coerceIn(0, total - 1)
        val progress = (step + 1).toFloat() / total.toFloat()

        // Progress bar
        LinearProgressIndicator(progress = progress, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(10.dp))

        // Step indicator
        Text(
            text = "الخطوة ${step + 1} من $total",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.ExtraBold
        )
        Spacer(Modifier.height(6.dp))

        // Lesson title
        Text(
            text = uiState.title,
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
        )
        Spacer(Modifier.height(10.dp))
        Divider()
        Spacer(Modifier.height(12.dp))

        AnimatedContent(
            targetState = step,
            transitionSpec = {
                val dir = if (targetState > initialState) 1 else -1
                (slideInHorizontally(animationSpec = tween(220)) { it * dir } + fadeIn(animationSpec = tween(220))) togetherWith
                    (slideOutHorizontally(animationSpec = tween(220)) { -it * dir } + fadeOut(animationSpec = tween(220)))
            },
            label = "lesson_step_anim"
        ) { idx ->
            val card = uiState.cards.getOrNull(idx)
            if (card != null) LessonCard(card)
        }

        Spacer(Modifier.height(16.dp))

        // Bottom controls
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Button(onClick = onPrev, enabled = step > 0) { Text("السابق") }

            Text("‎${step + 1}/$total‎")

            Button(onClick = onNext) { Text("التالي") }
        }

        // Start practice button: ONLY on last step
        if (step == total - 1) {
            Spacer(Modifier.height(14.dp))
            Button(
                onClick = onStartPractice,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
            ) {
                Text("ابدأ الاختبار", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun LessonCard(card: CardItem) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {

            // Title / main text
            if (!card.text.isNullOrBlank()) {
                Text(
                    card.text!!,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
            if (!card.textEn.isNullOrBlank()) {
                Spacer(Modifier.height(6.dp))
                Text(card.textEn!!, style = MaterialTheme.typography.bodyMedium)
            }

            if (!card.formula.isNullOrBlank()) {
                Spacer(Modifier.height(12.dp))
                Text(card.formula!!, style = MaterialTheme.typography.bodyLarge)
            }

            if (card.bullets?.isNotEmpty() == true) {
                Spacer(Modifier.height(12.dp))
                card.bullets.forEach { b ->
                    Text("• $b", style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(6.dp))
                }
            }

            // Examples: EN bigger, AR smaller, more spacing
            if (card.items?.isNotEmpty() == true) {
                Spacer(Modifier.height(12.dp))
                card.items.forEach { ex ->
                    val en = ex.en?.trim().orEmpty()
                    val ar = ex.ar?.trim().orEmpty()
                    if (en.isBlank() && ar.isBlank()) return@forEach

                    Column(modifier = Modifier.padding(vertical = 10.dp)) {
                        if (en.isNotBlank()) {
                            Text(
                                text = en,
                                fontSize = 22.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                        if (ar.isNotBlank()) {
                            Spacer(Modifier.height(4.dp))
                            Text(
                                text = ar,
                                fontSize = 16.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                            )
                        }
                    }
                }
            }
        }
    }
}
