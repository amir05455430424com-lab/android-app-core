package com.emir.englishapp.ui.screens.favorites

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.emir.englishapp.data.repository.AppRepository
import com.emir.englishapp.domain.model.PhraseItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class FavoritesViewModel(
    private val repo: AppRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(FavoritesUiState())
    val uiState: StateFlow<FavoritesUiState> = _uiState

    init {
        viewModelScope.launch {
            // Observe all favorites live
            combine(
                repo.favoriteQuestionIds,
                repo.favoritePhraseIds,
                repo.favoriteLessonIds
            ) { q, p, l ->
                Triple(q, p, l)
            }.collect { (qIds, pIds, lKeys) ->
                load(qIds, pIds, lKeys)
            }
        }
    }

    private suspend fun load(
        qIds: Set<String>,
        pIds: Set<String>,
        lKeys: Set<String>
    ) {
        _uiState.update { it.copy(isLoading = true, error = null) }

        // Questions
        val qMap = runCatching { repo.getQuestionByIdMap() }.getOrDefault(emptyMap())
        val questions = qIds.mapNotNull { qMap[it] }

        // Phrases
        val phrasesAll: List<PhraseItem> = runCatching { repo.getAllPhrases() }.getOrDefault(emptyList())
        val phrases = phrasesAll.filter { pIds.contains(it.id.toString()) }

        // Lessons (keys are "levelId|lessonId")
        val lessons = buildList {
            // Group by levelId to avoid re-reading the same level many times
            val byLevel = lKeys.mapNotNull { key ->
                val parts = key.split("|")
                val level = parts.getOrNull(0)?.toIntOrNull() ?: return@mapNotNull null
                val lessonId = parts.getOrNull(1) ?: return@mapNotNull null
                Triple(level, lessonId, key)
            }.groupBy { it.first }

            for ((levelId, triples) in byLevel) {
                val level = runCatching { repo.getLessonLevel(levelId) }.getOrNull() ?: continue
                val allLessons = level.units.flatMap { it.lessons }
                for ((_, lessonId, key) in triples) {
                    val lesson = allLessons.firstOrNull { it.lessonId == lessonId } ?: continue
                    add(
                        FavoriteLessonEntry(
                            key = key,
                            titleAr = lesson.titleAr,
                            titleEn = lesson.titleEn
                        )
                    )
                }
            }
        }

        _uiState.update {
            it.copy(
                isLoading = false,
                favoriteQuestions = questions,
                favoritePhrases = phrases,
                favoriteLessons = lessons,
                error = null
            )
        }
    }

    fun toggleFavorite(id: String) {
        viewModelScope.launch {
            repo.toggleFavoriteQuestion(id)
        }
    }

    fun togglePhraseFavorite(id: String) {
        viewModelScope.launch {
            repo.toggleFavoritePhrase(id)
        }
    }

    fun toggleLessonFavorite(key: String) {
        viewModelScope.launch {
            repo.toggleFavoriteLesson(key)
        }
    }
}

class FavoritesViewModelFactory(
    private val repo: AppRepository
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return FavoritesViewModel(repo) as T
    }
}
