package com.emir.englishapp.domain.engine

import com.emir.englishapp.domain.model.exercise.ExerciseTemplate
import com.emir.englishapp.domain.model.exercise.LearningModality

/**
 * SessionOrchestrator — Manages the full lifecycle of a single assessment session.
 *
 * Responsibilities:
 *  1. Owns the ordered exercise queue; never mutates the original list.
 *  2. Tracks per-question timing (answer latency in ms).
 *  3. Computes running stats: XP, accuracy, streak, mastery percent.
 *  4. Provides adaptive difficulty feedback: after 3 consecutive errors, the
 *     orchestrator flags `shouldInsertReview` so the ViewModel can inject an
 *     easier review card without touching the original queue.
 *  5. Emits [SessionResult] at the end for persistence by the ViewModel.
 *
 * This class is pure Kotlin — no Android dependencies.
 * Thread-safety: single-threaded (ViewModel dispatches all calls on Main).
 */
class SessionOrchestrator(
    private val exercises: List<ExerciseTemplate>,
    private val xpPerCorrect: Int = 10,
    private val xpStreakBonus: Int = 5,
    private val masteryThresholdPercent: Int = 80,
) {
    // ─────────────────────────────────────────────────────────────
    // Public immutable snapshot — surfaced to UI via StateFlow
    // ─────────────────────────────────────────────────────────────

    data class SessionSnapshot(
        val currentIndex: Int = 0,
        val totalCount: Int = 0,
        val currentExercise: ExerciseTemplate? = null,

        // Progress bar (0f..1f)
        val progressFraction: Float = 0f,

        // Scoring
        val correctCount: Int = 0,
        val incorrectCount: Int = 0,
        val streakCorrect: Int = 0,
        val totalXpEarned: Int = 0,
        val accuracyPercent: Int = 0,

        // Feedback
        val isAnswered: Boolean = false,
        val isCorrect: Boolean? = null,
        val feedbackText: String? = null,

        // Answer state — MCQ / FillBlank
        val selectedIndex: Int? = null,

        // Answer state — Reorder / SentenceReorder / DictationReorder / MatchPairs
        val reorderAvailable: List<String> = emptyList(),
        val reorderSelected: List<String> = emptyList(),

        // MatchPairs state
        val matchState: MatchState = MatchState(),

        // WordSort state
        val sortState: WordSortState = WordSortState(),

        // SpotTheError state
        val tappedTokenIndex: Int? = null,

        // Adaptive engine flag
        val shouldInsertReview: Boolean = false,

        // Session complete
        val isComplete: Boolean = false,

        // Timing
        val questionStartedAtMs: Long = 0L,
        val totalAnswerTimeMs: Long = 0L,
    )

    data class MatchState(
        /** EN tokens in display order (left column). */
        val leftTokens: List<String> = emptyList(),
        /** AR tokens in shuffled order (right column). */
        val rightTokens: List<String> = emptyList(),
        /** Tapped left index (pending match). */
        val pendingLeftIndex: Int? = null,
        /** Tapped right index (pending match). */
        val pendingRightIndex: Int? = null,
        /** Completed pairs: left-index → right-index. */
        val matched: Map<Int, Int> = emptyMap(),
        /** Whether all pairs have been matched correctly. */
        val isAllCorrect: Boolean = false,
    )

    data class WordSortState(
        /** Words not yet placed. */
        val unsorted: List<String> = emptyList(),
        /** Words placed in category A. */
        val categoryA: List<String> = emptyList(),
        /** Words placed in category B. */
        val categoryB: List<String> = emptyList(),
    )

    // ─────────────────────────────────────────────────────────────
    // Session result — emitted on completion
    // ─────────────────────────────────────────────────────────────

    data class SessionResult(
        val totalExercises: Int,
        val correctCount: Int,
        val incorrectCount: Int,
        val scorePercent: Int,
        val masteryPercent: Int,
        val starsAwarded: Int,    // 0..3
        val totalXpEarned: Int,
        val totalTimeMs: Long,
        val answeredIds: List<String>,
        val incorrectIds: List<String>,
    )

    // ─────────────────────────────────────────────────────────────
    // Mutable internal state
    // ─────────────────────────────────────────────────────────────

    private var _index = 0
    private var _correctCount = 0
    private var _incorrectCount = 0
    private var _streak = 0
    private var _xp = 0
    private var _totalTimeMs = 0L
    private var _questionStartMs = System.currentTimeMillis()
    private var _isAnswered = false
    private var _isCorrect: Boolean? = null
    private var _selectedIndex: Int? = null
    private var _reorderAvailable = mutableListOf<String>()
    private var _reorderSelected = mutableListOf<String>()
    private var _matchState = MatchState()
    private var _sortState = WordSortState()
    private var _tappedTokenIndex: Int? = null
    private var _consecutiveErrors = 0
    private val _answeredIds = mutableListOf<String>()
    private val _incorrectIds = mutableListOf<String>()

    init {
        require(exercises.isNotEmpty()) { "Session must have at least one exercise" }
        resetQuestionState()
    }

    // ─────────────────────────────────────────────────────────────
    // Public API — called by ViewModel
    // ─────────────────────────────────────────────────────────────

    val snapshot: SessionSnapshot get() = buildSnapshot()

    val isComplete: Boolean get() = _index >= exercises.size

    /** User tapped an MCQ / FillBlank / TypeWhatYouHear / ListenAndPick option. */
    fun selectOption(index: Int) {
        if (_isAnswered) return
        _selectedIndex = index
        autoConfirmIfReady()
    }

    /** User tapped a word chip in Reorder / SentenceReorder / DictationReorder. */
    fun pickWord(word: String) {
        if (_isAnswered) return
        if (word !in _reorderAvailable) return
        _reorderAvailable.remove(word)
        _reorderSelected.add(word)
        autoConfirmIfReady()
    }

    /** User un-tapped a word chip (returns it to the available pool). */
    fun unpickWord(word: String) {
        if (_isAnswered) return
        val idx = _reorderSelected.indexOfLast { it == word }
        if (idx < 0) return
        _reorderSelected.removeAt(idx)
        _reorderAvailable.add(word)
    }

    /** User tapped a token in SpotTheError. Auto-confirms immediately. */
    fun tapToken(index: Int) {
        if (_isAnswered) return
        _tappedTokenIndex = index
        confirm()
    }

    /** User tapped a cell in MatchPairs. Returns true if the pair was just completed. */
    fun tapMatchCell(isLeft: Boolean, index: Int): Boolean {
        if (_isAnswered) return false
        val ms = _matchState
        if (isLeft) {
            _matchState = ms.copy(pendingLeftIndex = index, pendingRightIndex = null)
        } else {
            val leftIdx = ms.pendingLeftIndex ?: return false
            val newMatched = ms.matched.toMutableMap().also { it[leftIdx] = index }
            val ex = exercises[_index] as? ExerciseTemplate.MatchPairs ?: return false
            val isAllDone = newMatched.size == ex.pairs.size
            _matchState = ms.copy(
                pendingLeftIndex = null,
                pendingRightIndex = null,
                matched = newMatched,
                isAllCorrect = isAllDone && verifyMatchPairs(ex, newMatched, ms.rightTokens),
            )
            if (isAllDone) confirm()
            return isAllDone
        }
        return false
    }

    /** User dropped a word into a WordSort category bucket (0 = A, 1 = B). */
    fun sortWord(word: String, targetCategory: Int) {
        if (_isAnswered) return
        val st = _sortState
        val newUnsorted = st.unsorted.toMutableList().also { it.remove(word) }
        val newA = if (targetCategory == 0) st.categoryA + word else st.categoryA
        val newB = if (targetCategory == 1) st.categoryB + word else st.categoryB
        _sortState = st.copy(unsorted = newUnsorted, categoryA = newA, categoryB = newB)
        if (newUnsorted.isEmpty()) confirm()
    }

    /** Explicit confirm (for Reorder types after all words are placed). */
    fun confirm() {
        if (_isAnswered) return
        val ex = exercises.getOrNull(_index) ?: return
        if (!hasValidAnswer(ex)) return
        val correct = evaluate(ex)
        _isAnswered = true
        _isCorrect = correct
        _totalTimeMs += System.currentTimeMillis() - _questionStartMs
        _answeredIds += ex.id
        if (correct) {
            _correctCount++
            _streak++
            _consecutiveErrors = 0
            _xp += xpPerCorrect + if (_streak >= 3) xpStreakBonus else 0
        } else {
            _incorrectCount++
            _streak = 0
            _consecutiveErrors++
            _incorrectIds += ex.id
        }
    }

    /** Advance to next exercise. Returns true if session is now complete. */
    fun next(): Boolean {
        if (!_isAnswered) return false
        _index++
        if (_index < exercises.size) {
            resetQuestionState()
        }
        return _index >= exercises.size
    }

    fun buildResult(): SessionResult {
        val total = exercises.size
        val score = if (total == 0) 0 else (_correctCount * 100) / total
        val mastery = computeMastery(score, _totalTimeMs, total)
        return SessionResult(
            totalExercises = total,
            correctCount = _correctCount,
            incorrectCount = _incorrectCount,
            scorePercent = score,
            masteryPercent = mastery,
            starsAwarded = when {
                mastery >= 90 -> 3
                mastery >= 70 -> 2
                mastery >= 50 -> 1
                else -> 0
            },
            totalXpEarned = _xp,
            totalTimeMs = _totalTimeMs,
            answeredIds = _answeredIds.toList(),
            incorrectIds = _incorrectIds.toList(),
        )
    }

    // ─────────────────────────────────────────────────────────────
    // Internal helpers
    // ─────────────────────────────────────────────────────────────

    private fun resetQuestionState() {
        _isAnswered = false
        _isCorrect = null
        _selectedIndex = null
        _tappedTokenIndex = null
        _questionStartMs = System.currentTimeMillis()

        val ex = exercises.getOrNull(_index)
        _reorderAvailable = when (ex) {
            is ExerciseTemplate.SentenceReorder  -> ex.shuffledWords.toMutableList()
            is ExerciseTemplate.DictationReorder -> ex.shuffledWords.toMutableList()
            else -> mutableListOf()
        }
        _reorderSelected = mutableListOf()

        _matchState = when (ex) {
            is ExerciseTemplate.MatchPairs -> {
                val leftTokens = ex.pairs.map { it.en }
                val rightTokens = ex.pairs.map { it.ar }.shuffled()
                MatchState(leftTokens = leftTokens, rightTokens = rightTokens)
            }
            else -> MatchState()
        }

        _sortState = when (ex) {
            is ExerciseTemplate.WordSort -> WordSortState(unsorted = ex.wordPool.map { it.text })
            else -> WordSortState()
        }
    }

    private fun autoConfirmIfReady() {
        val ex = exercises.getOrNull(_index) ?: return
        val ready = when (ex) {
            is ExerciseTemplate.TranslateEnToAr,
            is ExerciseTemplate.TranslateArToEn,
            is ExerciseTemplate.FillBlank,
            is ExerciseTemplate.ListenAndPick,
            is ExerciseTemplate.TypeWhatYouHear,
            is ExerciseTemplate.SentenceComplete,
            is ExerciseTemplate.PronunciationBridge -> _selectedIndex != null

            is ExerciseTemplate.SentenceReorder ->
                _reorderSelected.size == ex.correctOrder.size

            is ExerciseTemplate.DictationReorder ->
                _reorderSelected.size == ex.correctOrder.size

            else -> false
        }
        if (ready) confirm()
    }

    private fun hasValidAnswer(ex: ExerciseTemplate): Boolean = when (ex) {
        is ExerciseTemplate.SpotTheError -> _tappedTokenIndex != null
        is ExerciseTemplate.SentenceReorder -> _reorderSelected.isNotEmpty()
        is ExerciseTemplate.DictationReorder -> _reorderSelected.isNotEmpty()
        is ExerciseTemplate.MatchPairs -> _matchState.matched.size == ex.pairs.size
        is ExerciseTemplate.WordSort -> _sortState.unsorted.isEmpty()
        else -> _selectedIndex != null
    }

    private fun evaluate(ex: ExerciseTemplate): Boolean = when (ex) {
        is ExerciseTemplate.TranslateEnToAr  -> _selectedIndex == ex.answerIndex
        is ExerciseTemplate.TranslateArToEn  -> _selectedIndex == ex.answerIndex
        is ExerciseTemplate.FillBlank        -> _selectedIndex == ex.answerIndex
        is ExerciseTemplate.ListenAndPick    -> _selectedIndex == ex.answerIndex
        is ExerciseTemplate.TypeWhatYouHear  -> _selectedIndex == ex.answerIndex
        is ExerciseTemplate.SentenceComplete -> _selectedIndex == ex.answerIndex
        is ExerciseTemplate.PronunciationBridge -> _selectedIndex == ex.answerIndex
        is ExerciseTemplate.SentenceReorder  -> _reorderSelected == ex.correctOrder
        is ExerciseTemplate.DictationReorder -> _reorderSelected == ex.correctOrder
        is ExerciseTemplate.SpotTheError     -> _tappedTokenIndex == ex.errorIndex
        is ExerciseTemplate.MatchPairs       ->
            verifyMatchPairs(ex, _matchState.matched, _matchState.rightTokens)
        is ExerciseTemplate.WordSort         -> {
            val pool = ex.wordPool
            val correctA = pool.filter { it.correctCategory == 0 }.map { it.text }.toSet()
            val correctB = pool.filter { it.correctCategory == 1 }.map { it.text }.toSet()
            _sortState.categoryA.toSet() == correctA && _sortState.categoryB.toSet() == correctB
        }
    }

    private fun verifyMatchPairs(
        ex: ExerciseTemplate.MatchPairs,
        matched: Map<Int, Int>,
        rightTokens: List<String>,
    ): Boolean {
        val pairs = ex.pairs
        if (matched.size != pairs.size) return false
        return matched.all { (leftIdx, rightIdx) ->
            rightTokens.getOrNull(rightIdx) == pairs.getOrNull(leftIdx)?.ar
        }
    }

    private fun computeMastery(scorePercent: Int, timeMs: Long, total: Int): Int {
        val speedBonus = when {
            total == 0 || timeMs == 0L -> 0
            (timeMs / total) < 6_000 -> 10   // avg < 6s = fast learner
            (timeMs / total) < 12_000 -> 5
            else -> 0
        }
        return (scorePercent + speedBonus).coerceIn(0, 100)
    }

    private fun buildSnapshot(): SessionSnapshot {
        val ex = exercises.getOrNull(_index)
        val total = exercises.size
        val answered = _correctCount + _incorrectCount
        val accuracy = if (answered == 0) 0 else (_correctCount * 100) / answered
        val feedbackText = when (_isCorrect) {
            true -> "إجابة صحيحة! ✅"
            false -> {
                val hint = ex?.explanationAr ?: "إجابة غير صحيحة ❌"
                hint
            }
            null -> null
        }
        return SessionSnapshot(
            currentIndex = _index,
            totalCount = total,
            currentExercise = ex,
            progressFraction = if (total == 0) 0f else _index.toFloat() / total,
            correctCount = _correctCount,
            incorrectCount = _incorrectCount,
            streakCorrect = _streak,
            totalXpEarned = _xp,
            accuracyPercent = accuracy,
            isAnswered = _isAnswered,
            isCorrect = _isCorrect,
            feedbackText = feedbackText,
            selectedIndex = _selectedIndex,
            reorderAvailable = _reorderAvailable.toList(),
            reorderSelected = _reorderSelected.toList(),
            matchState = _matchState,
            sortState = _sortState,
            tappedTokenIndex = _tappedTokenIndex,
            shouldInsertReview = _consecutiveErrors >= 3,
            isComplete = _index >= total,
            questionStartedAtMs = _questionStartMs,
            totalAnswerTimeMs = _totalTimeMs,
        )
    }
}
