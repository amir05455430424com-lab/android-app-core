package com.emir.englishapp.ui.screens.proquestion

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.emir.englishapp.domain.model.questionv2.FillBlankQuestionV2
import com.emir.englishapp.domain.model.questionv2.McqQuestionV2
import com.emir.englishapp.domain.model.questionv2.ReorderQuestionV2

@Composable
internal fun ProMcqBlock(
    q: McqQuestionV2,
    selectedIndex: Int?,
    isAnswered: Boolean,
    isCorrect: Boolean?,
    onSelect: (Int) -> Unit,
) {
    val opts = (q.optionsAr ?: emptyList()).ifEmpty { q.optionsEn ?: emptyList() }
    
    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        opts.forEachIndexed { idx, opt ->
            val isSelected = selectedIndex == idx
            val isRight = isAnswered && idx == q.answerIndex
            val isWrong = isAnswered && isSelected && idx != q.answerIndex

            val borderColor = when {
                isRight -> Color(0xFF58CC02)
                isWrong -> Color(0xFFEA2B2B)
                isSelected -> Color(0xFF1CB0F6)
                else -> Color(0xFFE5E5E5)
            }

            val shadowColor = when {
                isRight -> Color(0xFF46A302)
                isWrong -> Color(0xFFC42525)
                isSelected -> Color(0xFF1899D6)
                else -> Color(0xFFE5E5E5)
            }

            val backgroundColor = when {
                isRight -> Color(0xFFD7FFB8)
                isWrong -> Color(0xFFFFDFE0)
                isSelected -> Color(0xFFDDF4FF)
                else -> Color.White
            }

            // 3D Style Option
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(enabled = !isAnswered) { onSelect(idx) }
                    .background(shadowColor, RoundedCornerShape(16.dp))
                    .padding(bottom = if (isAnswered && isSelected) 0.dp else 4.dp) // Sink on answer
            ) {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    color = backgroundColor,
                    border = BorderStroke(2.dp, borderColor),
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        BoxWithNumber(idx + 1, isSelected, isRight, isWrong)
                        Spacer(Modifier.size(16.dp))
                        Text(
                            text = opt,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF4B4B4B)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun BoxWithNumber(num: Int, selected: Boolean, right: Boolean, wrong: Boolean) {
    val color = when {
        right -> Color(0xFF58CC02)
        wrong -> Color(0xFFEA2B2B)
        selected -> Color(0xFF1CB0F6)
        else -> Color.Transparent
    }
    Surface(
        modifier = Modifier.size(32.dp),
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(2.dp, if (color == Color.Transparent) Color(0xFFE5E5E5) else color),
        color = Color.Transparent
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(
                text = num.toString(),
                color = if (color == Color.Transparent) Color(0xFFAFAFAF) else color,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
internal fun ProFillBlankBlock(
    q: FillBlankQuestionV2,
    selectedIndex: Int?,
    isAnswered: Boolean,
    isCorrect: Boolean?,
    onSelect: (Int) -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(24.dp)) {
        // Sentence with Interactive Blank
        val sentence = q.sentenceEn
        val parts = sentence.split("____")
        
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            parts.forEachIndexed { index, part ->
                Text(
                    text = part,
                    style = MaterialTheme.typography.headlineSmall.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = 22.sp,
                        color = Color(0xFF4B4B4B)
                    )
                )
                if (index < parts.size - 1) {
                    val selectedText = if (selectedIndex != null) q.optionsEn.getOrNull(selectedIndex) else "       "
                    Surface(
                        modifier = Modifier.padding(horizontal = 6.dp),
                        border = BorderStroke(2.dp, if (selectedIndex != null) Color(0xFF1CB0F6) else Color(0xFFE5E5E5)),
                        shape = RoundedCornerShape(8.dp),
                        color = if (selectedIndex != null) Color(0xFFDDF4FF) else Color(0xFFF7F7F7)
                    ) {
                        Text(
                            text = selectedText ?: "",
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                            color = Color(0xFF1CB0F6),
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 20.sp
                        )
                    }
                }
            }
        }

        // Options Grid
        @OptIn(ExperimentalLayoutApi::class)
        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            q.optionsEn.forEachIndexed { idx, opt ->
                val isSelected = selectedIndex == idx
                
                Surface(
                    modifier = Modifier
                        .clickable(enabled = !isAnswered) { onSelect(idx) }
                        .padding(4.dp),
                    shape = RoundedCornerShape(12.dp),
                    color = if (isSelected) Color(0xFF1CB0F6) else Color.White,
                    border = BorderStroke(2.dp, if (isSelected) Color(0xFF1CB0F6) else Color(0xFFE5E5E5)),
                ) {
                    Text(
                        text = opt,
                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isSelected) Color.White else Color(0xFF4B4B4B)
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun ProReorderBlock(
    q: ReorderQuestionV2,
    available: List<String>,
    selected: List<String>,
    isAnswered: Boolean,
    isCorrect: Boolean?,
    onPick: (String) -> Unit,
    onUnpick: (String) -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(32.dp)) {
        // Drop Zone Area
        Column(modifier = Modifier.fillMaxWidth()) {
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp)
            ) {
                selected.forEach { word ->
                    WordChip(word = word, isSelected = true, onClick = { if (!isAnswered) onUnpick(word) })
                }
            }
            
            // Duolingo static lines for empty slots
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(2.dp)
                    .background(Color(0xFFE5E5E5))
            )
        }

        // Bank of words
        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            val usedMap = mutableMapOf<String, Int>()
            selected.forEach { usedMap[it] = (usedMap[it] ?: 0) + 1 }
            
            val tempUsedMap = mutableMapOf<String, Int>()

            q.words.forEach { word ->
                val totalUsed = usedMap[word] ?: 0
                val currentCount = tempUsedMap[word] ?: 0
                
                val isActuallyUsed = currentCount < totalUsed
                if (isActuallyUsed) {
                    tempUsedMap[word] = currentCount + 1
                }

                WordChip(
                    word = word,
                    isSelected = false,
                    isUsed = isActuallyUsed,
                    onClick = { if (!isAnswered && !isActuallyUsed) onPick(word) }
                )
            }
        }
    }
}

@Composable
private fun WordChip(word: String, isSelected: Boolean, isUsed: Boolean = false, onClick: () -> Unit) {
    val borderColor = if (isUsed) Color(0xFFE5E5E5) else Color(0xFFE5E5E5)
    val backgroundColor = if (isUsed) Color(0xFFE5E5E5) else Color.White
    val shadowColor = if (isUsed) Color(0xFFE5E5E5) else Color(0xFFE5E5E5)

    Box(
        modifier = Modifier
            .clickable(enabled = !isUsed) { onClick() }
            .background(shadowColor, RoundedCornerShape(12.dp))
            .padding(bottom = if (isUsed) 0.dp else 4.dp)
    ) {
        Surface(
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(2.dp, borderColor),
            color = backgroundColor,
        ) {
            Text(
                text = word,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                color = if (isUsed) Color.Transparent else Color(0xFF4B4B4B),
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
        }
    }
}
