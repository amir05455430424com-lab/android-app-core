package com.emir.englishapp.ui.screens.daily

import com.emir.englishapp.domain.model.question.Question

data class DailyChallengeUiState(
    val isLoading: Boolean = true,
    val error: String? = null,
    val globalIndex: Int = 1,
    val unitTitleAr: String = "",
    val unitTitleEn: String = "",
    val xpReward: Int = 0,
    val questions: List<Question> = emptyList(),
    val index: Int = 0,
    val selected: Int? = null,
    val isCorrect: Boolean? = null,
    val correctCount: Int = 0,
    val startedAtMs: Long = 0L,
    val questionStartedAtMs: Long = 0L,
    val totalAnswerTimeMs: Long = 0L,
    val isFinished: Boolean = false,
    val favoriteIds: Set<String> = emptySet()
)
