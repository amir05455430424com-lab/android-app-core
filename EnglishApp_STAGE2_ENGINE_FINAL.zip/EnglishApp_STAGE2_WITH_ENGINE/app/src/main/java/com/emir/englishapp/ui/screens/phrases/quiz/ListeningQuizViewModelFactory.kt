package com.emir.englishapp.ui.screens.phrases.quiz

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.emir.englishapp.data.repository.AppRepository
import com.emir.englishapp.domain.audio.AssetAudioPlayer

class ListeningQuizViewModelFactory(
    private val repo: AppRepository,
    private val audioPlayer: AssetAudioPlayer,
    private val categoryKey: String
) : ViewModelProvider.Factory {

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(ListeningQuizViewModel::class.java)) {
            return ListeningQuizViewModel(repo, audioPlayer, categoryKey) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
    }
}
