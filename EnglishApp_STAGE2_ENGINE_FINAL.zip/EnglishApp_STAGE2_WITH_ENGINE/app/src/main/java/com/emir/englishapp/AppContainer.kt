package com.emir.englishapp

import android.content.Context
import com.emir.englishapp.data.local.AssetsDataSource
import com.emir.englishapp.data.local.UserProgressStore
import com.emir.englishapp.data.repository.AppRepository
import com.emir.englishapp.data.repository.AppRepositoryImpl
import com.emir.englishapp.domain.audio.AssetAudioPlayer

class AppContainer(appContext: Context) {

    private val progressStore = UserProgressStore(appContext)
    private val assetsDataSource = AssetsDataSource(appContext)

    val repository: AppRepository = AppRepositoryImpl(
        progressStore = progressStore,
        assets = assetsDataSource
    )

    val audioPlayer: AssetAudioPlayer = AssetAudioPlayer(appContext)
}
