package com.emir.englishapp.ui.screens.phrases.categories

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.emir.englishapp.data.repository.AppRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class PhraseCategoriesViewModel(
    private val repo: AppRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(PhraseCategoriesUiState())
    val uiState: StateFlow<PhraseCategoriesUiState> = _uiState.asStateFlow()

    init {
        load()
    }

    private fun load() {
        viewModelScope.launch {
            _uiState.value = PhraseCategoriesUiState(isLoading = true)
            runCatching {
                repo.getPhraseCategories()
            }.onSuccess { list ->
                _uiState.value = PhraseCategoriesUiState(
                    isLoading = false,
                    categories = list
                )
            }.onFailure { e ->
                _uiState.value = PhraseCategoriesUiState(
                    isLoading = false,
                    errorMessage = e.message ?: "Error loading categories"
                )
            }
        }
    }
}
