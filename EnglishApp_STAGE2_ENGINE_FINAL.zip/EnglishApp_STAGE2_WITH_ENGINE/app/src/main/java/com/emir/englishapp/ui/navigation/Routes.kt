package com.emir.englishapp.ui.navigation

/**
 * Centralized navigation routes.
 * Keep this file clean — broken strings here will break the whole build.
 */
object Routes {
    const val HOME = "home"

    // Audio Pro Test
    const val AUDIO_PRO = "pro/audio"

    // Drawer destinations
    const val FAVORITES = "favorites"
    const val SETTINGS = "settings"

    // Stage 4: Main Path
    const val PATH = "path"

    // Stage 4: Pro Path (100 units)
    const val PRO_PATH = "pro/path"
    // Optional query: mode = pro | daily
    const val PRO_UNIT_LESSON_PATTERN = "pro/unit/lesson/{globalIndex}/{step}?mode={mode}"
    const val PRO_UNIT_REWARD_PATTERN = "pro/unit/reward/{globalIndex}/{step}/{stepsTotal}/{score}/{mastery}/{stars}/{correct}/{total}/{xp}/{unlocked}/{isFinal}?mode={mode}"

    // Stage 3: Lessons
    const val LESSONS = "lessons"
    const val LEVELS_PATTERN = "lessons/level/{levelId}"
    const val LESSON_PATTERN = "lessons/level/{levelId}/lesson/{lessonId}"
    const val LESSON_PRACTICE_PATTERN = "lessons/practice/{levelId}/{lessonId}"

    // Stage 2: Phrases
    const val PHRASES_CATEGORIES = "phrases/categories"
    const val PHRASES_LIST_PATTERN = "phrases/list/{categoryKey}"
    const val PHRASES_QUIZ_PATTERN = "phrases/quiz/{categoryKey}"

    // Stage 4.1: Daily Session (legacy screens; Home now starts a Pro-style daily run)
    const val DAILY_START = "daily/start"
    const val DAILY_STUDY_PATTERN = "daily/study/{globalIndex}"
    const val DAILY_CHALLENGE_PATTERN = "daily/challenge/{globalIndex}"
    const val DAILY_REWARD_PATTERN = "daily/reward/{globalIndex}/{score}/{mastery}/{stars}/{correct}/{total}/{xp}/{unlocked}"

    // Stage 4.3: Unit Lesson (Duolingo-like nodes/steps)
    const val UNIT_LESSON_PATTERN = "unit/lesson/{globalIndex}/{step}"
    const val UNIT_REWARD_PATTERN = "unit/reward/{globalIndex}/{step}/{stepsTotal}/{score}/{mastery}/{stars}/{correct}/{total}/{xp}/{unlocked}/{isFinal}"

    // ─────────────────────────────────────────────────────────
    // SMART ASSESSMENT ENGINE (Dynamic Offline Assessment)
    // ─────────────────────────────────────────────────────────

    /**
     * Entry point: Assessment session for a given topic + CEFR + mode.
     *
     * Args:
     *  topic       — data.json category key (e.g. "family", "food")
     *  cefr        — A1 | A2 | B1 | B2 | C1
     *  mode        — mixed | visual | auditory | kinetic | review
     *  size        — number of exercises in the session (default 10)
     *  titleEn     — module title in English (URL-encoded)
     *  titleAr     — module title in Arabic  (URL-encoded)
     *  globalIndex — pro-path unit index (0 = standalone, >0 = link to progress)
     */
    const val ASSESSMENT_PATTERN =
        "assessment/{topic}/{cefr}/{mode}/{size}/{globalIndex}"

    /**
     * Reward screen after assessment completion.
     * Args: score, mastery, stars, correct, total, xp, timeMs (all Int/Long)
     */
    const val ASSESSMENT_REWARD_PATTERN =
        "assessment/reward/{topic}/{cefr}/{mode}/{score}/{mastery}/{stars}/{correct}/{total}/{xp}/{timeMs}"

    // Convenience builder functions
    fun assessmentRoute(
        topic: String,
        cefr: String = "A1",
        mode: String = "mixed",
        size: Int = 10,
        globalIndex: Int = 0,
    ): String = "assessment/$topic/$cefr/$mode/$size/$globalIndex"

    fun assessmentRewardRoute(
        topic: String,
        cefr: String,
        mode: String,
        score: Int,
        mastery: Int,
        stars: Int,
        correct: Int,
        total: Int,
        xp: Int,
        timeMs: Long,
    ): String = "assessment/reward/$topic/$cefr/$mode/$score/$mastery/$stars/$correct/$total/$xp/$timeMs"
}
