package com.emir.englishapp.ui.screens.lessons.levels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.emir.englishapp.data.repository.AppRepository
import com.emir.englishapp.domain.model.lesson.LevelMeta
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class LevelRow(
    val meta: LevelMeta,
    val unitsCount: Int,
    val lessonsCount: Int,
    val completedCount: Int
)

data class LevelPickerUiState(
    val isLoading: Boolean = true,
    val levels: List<LevelRow> = emptyList(),
    val error: String? = null
)

class LevelPickerViewModel(
    private val repo: AppRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(LevelPickerUiState())
    val uiState: StateFlow<LevelPickerUiState> = _uiState.asStateFlow()

    fun load() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, error = null)
            runCatching {
                val levels = repo.getLevelsIndex()
                levels.map { meta ->
                    val level = repo.getLessonLevel(meta.id)
                    val unitsCount = level?.units?.size ?: 0
                    val lessonsCount = level?.units?.sumOf { it.lessons.size } ?: 0
                    val completed = repo.getCompletedLessonIds(meta.id).size
                    LevelRow(meta, unitsCount, lessonsCount, completed)
                }
            }.onSuccess { rows ->
                _uiState.value = LevelPickerUiState(isLoading = false, levels = rows)
            }.onFailure { e ->
                _uiState.value = LevelPickerUiState(isLoading = false, error = e.message ?: "خطأ غير معروف")
            }
        }
    }

    init {
        load()
    }
}
