package com.emir.englishapp.ui.screens.unitlesson

import com.emir.englishapp.domain.model.question.Question

data class UnitLessonUiState(
    val isLoading: Boolean = true,
    val error: String? = null,
    val globalIndex: Int = 1,
    val stepIndex: Int = 0,
    val stepsTotal: Int = 5,
    val unitTitleAr: String = "",
    val unitTitleEn: String = "",
    val xpReward: Int = 0,
    val questions: List<Question> = emptyList(),
    val index: Int = 0,
    val selected: Int? = null,
    val correctCount: Int = 0,
    val questionStartedAtMs: Long = 0L,
    val totalAnswerTimeMs: Long = 0L,
    val favoriteIds: Set<String> = emptySet()
)
