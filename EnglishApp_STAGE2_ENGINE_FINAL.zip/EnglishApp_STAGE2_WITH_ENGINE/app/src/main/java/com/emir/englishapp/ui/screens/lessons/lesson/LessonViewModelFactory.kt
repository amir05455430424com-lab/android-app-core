package com.emir.englishapp.ui.screens.lessons.lesson

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.emir.englishapp.data.repository.AppRepository

class LessonViewModelFactory(
    private val repo: AppRepository,
    private val levelId: Int,
    private val lessonId: String
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return LessonViewModel(repo, levelId, lessonId) as T
    }
}
