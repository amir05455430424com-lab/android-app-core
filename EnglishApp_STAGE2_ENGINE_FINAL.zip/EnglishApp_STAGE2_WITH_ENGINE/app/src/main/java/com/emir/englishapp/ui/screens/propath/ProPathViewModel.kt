package com.emir.englishapp.ui.screens.propath

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.emir.englishapp.data.repository.AppRepository
import com.emir.englishapp.ui.screens.path.CourseUnitUi
import com.emir.englishapp.ui.screens.path.UnitStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class ProPathViewModel(
    private val repo: AppRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(ProPathUiState())
    val uiState: StateFlow<ProPathUiState> = _uiState

    private val stepsTotal = 4

    init {
        viewModelScope.launch {
            val units = try {
                repo.getAllProUnitsFlat().sortedBy { it.globalIndex }
            } catch (t: Throwable) {
                _uiState.update { it.copy(isLoading = false, error = t.message ?: "خطأ في تحميل Pro Path") }
                return@launch
            }

            repo.proCurrentUnitGlobalIndex
                .distinctUntilChanged()
                .collect { currentIdx ->
                    val stepMap = runCatching { repo.getProUnitStepIndexMap() }.getOrElse { emptyMap() }

                    val uiUnits = units.map { unit ->
                        val stepIdx = (stepMap[unit.globalIndex] ?: 0).coerceIn(0, stepsTotal)
                        val status = when {
                            unit.globalIndex < currentIdx -> UnitStatus.Completed
                            unit.globalIndex == currentIdx -> UnitStatus.Current
                            else -> UnitStatus.Locked
                        }
                        CourseUnitUi(unit = unit, status = status, stepIndex = stepIdx, stepsTotal = stepsTotal)
                    }

                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            error = null,
                            currentUnitGlobalIndex = currentIdx,
                            units = uiUnits
                        )
                    }
                }
        }
    }
}

class ProPathViewModelFactory(
    private val repo: AppRepository
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        @Suppress("UNCHECKED_CAST")
        return ProPathViewModel(repo) as T
    }
}
