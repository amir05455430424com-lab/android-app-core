package com.emir.englishapp.domain.model.questionv2

/**
 * V2 Question engine models (MCQ + FillBlank + Reorder).
 *
 * - Backward compatible: if type is missing, treat as MCQ.
 * - Designed to co-exist with the legacy [com.emir.englishapp.domain.model.question.Question].
 */

sealed class QuestionV2 {
    abstract val id: String
    abstract val type: String
    abstract val cefr: String
    abstract val direction: String
    abstract val skill: String?
    abstract val difficultyScore: Int?
    abstract val explanationAr: String?
}

data class McqQuestionV2(
    override val id: String,
    override val type: String = "mcq",
    override val cefr: String,
    override val direction: String,
    override val skill: String? = null,
    override val difficultyScore: Int? = null,
    val promptAr: String? = null,
    val promptEn: String? = null,
    val termEn: String? = null,
    val termAr: String? = null,
    val sentenceEn: String? = null,
    val optionsAr: List<String>? = null,
    val optionsEn: List<String>? = null,
    val answerIndex: Int,
    override val explanationAr: String? = null,
) : QuestionV2()

data class FillBlankQuestionV2(
    override val id: String,
    override val type: String = "fill_blank",
    override val cefr: String,
    override val direction: String,
    override val skill: String? = null,
    override val difficultyScore: Int? = null,
    val promptEn: String,
    val sentenceEn: String,
    val optionsEn: List<String>,
    val answerIndex: Int,
    override val explanationAr: String? = null,
) : QuestionV2()

data class ReorderQuestionV2(
    override val id: String,
    override val type: String = "reorder",
    override val cefr: String,
    override val direction: String,
    override val skill: String? = null,
    override val difficultyScore: Int? = null,
    val promptEn: String,
    val words: List<String>,
    val correctOrder: List<String>,
    override val explanationAr: String? = null,
) : QuestionV2()
