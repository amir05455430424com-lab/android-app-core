package com.emir.englishapp.ui.screens.lessons.level

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.emir.englishapp.data.repository.AppRepository

class LevelViewModelFactory(
    private val repo: AppRepository,
    private val levelId: Int
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return LevelViewModel(repo, levelId) as T
    }
}
