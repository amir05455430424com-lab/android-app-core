package com.emir.englishapp.domain.engine

import com.emir.englishapp.domain.model.exercise.ExerciseTemplate
import kotlin.math.roundToInt

/**
 * SpacedRepetitionScheduler
 * ==========================
 * Distributes 200+ exercises across intelligent learning passes
 * using a simplified SM-2 / Leitner hybrid algorithm.
 *
 * Core concepts:
 *  - Each exercise has a [CardRecord] tracking ease factor, repetitions, interval.
 *  - 5 Leitner boxes: NEW → LEARNING → REVIEW → MATURE → MASTERED
 *  - After each answer, the card moves forward (correct) or resets to LEARNING (wrong).
 *  - [nextSession()] returns the optimal exercise sequence for the current pass:
 *    new cards + due review cards + struggling cards first.
 *
 * Serialization:
 *  - [exportState()] / [importState()] for DataStore persistence (JSON-encoded string).
 *  - Zero Android dependency — pure Kotlin data transformations.
 */
class SpacedRepetitionScheduler(
    private val newCardsPerSession: Int = 10,
    private val reviewCardsPerSession: Int = 20,
) {

    // ─────────────────────────────────────────────────────────────
    // Data model
    // ─────────────────────────────────────────────────────────────

    enum class LeitnerBox(val label: String, val intervalMultiplier: Float) {
        NEW("جديد", 0f),
        LEARNING("تعلّم", 1f),       // revisit in same session
        REVIEW("مراجعة", 3f),        // revisit after ~3 sessions
        MATURE("ناضج", 10f),         // revisit after ~10 sessions
        MASTERED("مُتقَن", 30f),     // revisit after ~30 sessions
    }

    data class CardRecord(
        val exerciseId: String,
        val box: LeitnerBox = LeitnerBox.NEW,
        val easeFactor: Float = 2.5f,          // SM-2 ease factor (1.3 .. 5.0)
        val intervalDays: Float = 0f,
        val repetitions: Int = 0,
        val totalAttempts: Int = 0,
        val correctAttempts: Int = 0,
        val lastSessionIndex: Int = -1,        // session number when last reviewed
        val avgAnswerTimeMs: Long = 0L,
    ) {
        val accuracyPercent: Int
            get() = if (totalAttempts == 0) 0 else (correctAttempts * 100) / totalAttempts

        val isDue: Boolean
            get() = box != LeitnerBox.MASTERED

        val priority: Float
            get() = when (box) {
                LeitnerBox.NEW      -> 100f - (exerciseId.hashCode() % 10).toFloat() // stable shuffle
                LeitnerBox.LEARNING -> 90f
                LeitnerBox.REVIEW   -> 70f + (1f / (intervalDays + 1f)) * 20f
                LeitnerBox.MATURE   -> 40f
                LeitnerBox.MASTERED -> 0f
            }
    }

    // ─────────────────────────────────────────────────────────────
    // Public state
    // ─────────────────────────────────────────────────────────────

    private val records = LinkedHashMap<String, CardRecord>()
    private var sessionIndex = 0

    /** Initialise the scheduler with the full exercise pool. */
    fun loadExercises(exercises: List<ExerciseTemplate>) {
        exercises.forEach { ex ->
            if (!records.containsKey(ex.id)) {
                records[ex.id] = CardRecord(exerciseId = ex.id)
            }
        }
    }

    /** Statistics snapshot for UI display. */
    data class ProgressStats(
        val total: Int,
        val newCount: Int,
        val learningCount: Int,
        val reviewCount: Int,
        val matureCount: Int,
        val masteredCount: Int,
        val overallAccuracyPercent: Int,
        val sessionIndex: Int,
    )

    val stats: ProgressStats
        get() {
            val boxes = records.values.groupBy { it.box }
            val totalAttempts = records.values.sumOf { it.totalAttempts }
            val totalCorrect  = records.values.sumOf { it.correctAttempts }
            return ProgressStats(
                total = records.size,
                newCount = boxes[LeitnerBox.NEW]?.size ?: 0,
                learningCount = boxes[LeitnerBox.LEARNING]?.size ?: 0,
                reviewCount = boxes[LeitnerBox.REVIEW]?.size ?: 0,
                matureCount = boxes[LeitnerBox.MATURE]?.size ?: 0,
                masteredCount = boxes[LeitnerBox.MASTERED]?.size ?: 0,
                overallAccuracyPercent = if (totalAttempts == 0) 0 else (totalCorrect * 100) / totalAttempts,
                sessionIndex = sessionIndex,
            )
        }

    // ─────────────────────────────────────────────────────────────
    // Core scheduling API
    // ─────────────────────────────────────────────────────────────

    /**
     * Build the next optimal session queue.
     *
     * Order: LEARNING (re-practice errors) → NEW → REVIEW → MATURE
     *
     * @param exercises     the full exercise pool (to retrieve objects by ID)
     * @param targetSize    desired session length (default = newCardsPerSession + reviewCardsPerSession)
     */
    fun nextSession(
        exercises: List<ExerciseTemplate>,
        targetSize: Int = newCardsPerSession + reviewCardsPerSession,
    ): List<ExerciseTemplate> {
        val exerciseById = exercises.associateBy { it.id }
        sessionIndex++

        // Partition by box
        fun boxList(box: LeitnerBox) = records.values
            .filter { it.box == box }
            .sortedByDescending { it.priority }
            .mapNotNull { exerciseById[it.exerciseId] }

        val learning = boxList(LeitnerBox.LEARNING)
        val new      = boxList(LeitnerBox.NEW).take(newCardsPerSession)
        val review   = boxList(LeitnerBox.REVIEW).take(reviewCardsPerSession / 2)
        val mature   = boxList(LeitnerBox.MATURE).take(reviewCardsPerSession / 4)

        val combined = (learning + new + review + mature)
            .distinct()
            .take(targetSize)

        // If session is short, fill with remaining review
        val extra = if (combined.size < targetSize) {
            boxList(LeitnerBox.REVIEW)
                .filter { it !in combined }
                .take(targetSize - combined.size)
        } else emptyList()

        return combined + extra
    }

    /**
     * Record the result of answering an exercise.
     * Updates the card's box, ease factor, and interval using SM-2 logic.
     *
     * @param exerciseId     the answered exercise
     * @param correct        whether the answer was correct
     * @param answerTimeMs   time taken to answer in ms
     */
    fun recordAnswer(exerciseId: String, correct: Boolean, answerTimeMs: Long = 0L) {
        val old = records[exerciseId] ?: CardRecord(exerciseId)
        val newRec = computeNextRecord(old, correct, answerTimeMs)
        records[exerciseId] = newRec
    }

    /**
     * Returns exercises the learner struggled with most (for focused review).
     * Sorted by error rate descending.
     */
    fun strugglingExercises(
        exercises: List<ExerciseTemplate>,
        limit: Int = 10,
    ): List<ExerciseTemplate> {
        val byId = exercises.associateBy { it.id }
        return records.values
            .filter { it.totalAttempts >= 2 && it.accuracyPercent < 60 }
            .sortedBy { it.accuracyPercent }
            .take(limit)
            .mapNotNull { byId[it.exerciseId] }
    }

    // ─────────────────────────────────────────────────────────────
    // State serialization (for DataStore persistence)
    // ─────────────────────────────────────────────────────────────

    /** Exports state as a flat CSV string for lightweight DataStore storage. */
    fun exportState(): String = buildString {
        appendLine("session=$sessionIndex")
        records.values.forEach { r ->
            appendLine("${r.exerciseId}|${r.box.name}|${r.easeFactor}|${r.intervalDays}|${r.repetitions}|${r.totalAttempts}|${r.correctAttempts}|${r.lastSessionIndex}|${r.avgAnswerTimeMs}")
        }
    }

    /** Restores state from a previously exported string. */
    fun importState(raw: String) {
        records.clear()
        raw.lines().forEach { line ->
            when {
                line.startsWith("session=") -> sessionIndex = line.substringAfter("=").toIntOrNull() ?: 0
                line.contains("|") -> {
                    val parts = line.split("|")
                    if (parts.size >= 9) {
                        records[parts[0]] = CardRecord(
                            exerciseId = parts[0],
                            box = LeitnerBox.values().firstOrNull { it.name == parts[1] } ?: LeitnerBox.NEW,
                            easeFactor = parts[2].toFloatOrNull() ?: 2.5f,
                            intervalDays = parts[3].toFloatOrNull() ?: 0f,
                            repetitions = parts[4].toIntOrNull() ?: 0,
                            totalAttempts = parts[5].toIntOrNull() ?: 0,
                            correctAttempts = parts[6].toIntOrNull() ?: 0,
                            lastSessionIndex = parts[7].toIntOrNull() ?: -1,
                            avgAnswerTimeMs = parts[8].toLongOrNull() ?: 0L,
                        )
                    }
                }
            }
        }
    }

    // ─────────────────────────────────────────────────────────────
    // SM-2 core
    // ─────────────────────────────────────────────────────────────

    private fun computeNextRecord(
        old: CardRecord,
        correct: Boolean,
        answerTimeMs: Long,
    ): CardRecord {
        val newTotal = old.totalAttempts + 1
        val newCorrect = old.correctAttempts + if (correct) 1 else 0

        // Update running average answer time
        val newAvgTime = if (old.totalAttempts == 0) answerTimeMs
        else (old.avgAnswerTimeMs * old.totalAttempts + answerTimeMs) / newTotal

        if (!correct) {
            // Wrong → reset to LEARNING, reduce ease factor
            val newEase = (old.easeFactor - 0.20f).coerceAtLeast(1.3f)
            return old.copy(
                box = LeitnerBox.LEARNING,
                easeFactor = newEase,
                intervalDays = 0f,
                repetitions = 0,
                totalAttempts = newTotal,
                correctAttempts = newCorrect,
                lastSessionIndex = sessionIndex,
                avgAnswerTimeMs = newAvgTime,
            )
        }

        // Correct → advance box and apply SM-2 interval
        val newRepetitions = old.repetitions + 1

        // Quality score: fast+correct = 5, slow+correct = 3
        val quality = when {
            answerTimeMs in 1..4000 -> 5
            answerTimeMs in 4001..10000 -> 4
            else -> 3
        }

        val newEase = (old.easeFactor + 0.1f - (5 - quality) * (0.08f + (5 - quality) * 0.02f))
            .coerceIn(1.3f, 5.0f)

        val newInterval = when (newRepetitions) {
            1 -> 1f
            2 -> 6f
            else -> (old.intervalDays * newEase).roundToInt().toFloat()
        }

        val newBox = when {
            old.box == LeitnerBox.NEW      -> LeitnerBox.LEARNING
            old.box == LeitnerBox.LEARNING && newRepetitions >= 2 -> LeitnerBox.REVIEW
            old.box == LeitnerBox.REVIEW   && newInterval >= 10f  -> LeitnerBox.MATURE
            old.box == LeitnerBox.MATURE   && newInterval >= 30f  -> LeitnerBox.MASTERED
            else -> old.box
        }

        return old.copy(
            box = newBox,
            easeFactor = newEase,
            intervalDays = newInterval,
            repetitions = newRepetitions,
            totalAttempts = newTotal,
            correctAttempts = newCorrect,
            lastSessionIndex = sessionIndex,
            avgAnswerTimeMs = newAvgTime,
        )
    }
}
