package com.emir.englishapp.ui.theme

import androidx.compose.runtime.Immutable
import androidx.compose.ui.unit.dp

@Immutable
object Spacing {
    val xs = 6.dp
    val sm = 10.dp
    val md = 14.dp
    val lg = 18.dp
    val xl = 24.dp
    val xxl = 32.dp
}

@Immutable
object Elevation {
    val none = 0.dp
    val sm = 2.dp
    val md = 6.dp
    val lg = 10.dp
}
