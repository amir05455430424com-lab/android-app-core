package com.emir.englishapp.ui.screens.unitlesson

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.emir.englishapp.data.repository.AppRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

class UnitLessonViewModel(
    private val repo: AppRepository,
    private val globalIndex: Int,
    private val stepIndex: Int,
    private val stepsTotal: Int = 5,
    private val stepSize: Int = 8
) : ViewModel() {

    private val _uiState = MutableStateFlow(UnitLessonUiState(globalIndex = globalIndex, stepIndex = stepIndex, stepsTotal = stepsTotal))
    val uiState: StateFlow<UnitLessonUiState> = _uiState

    init {
        viewModelScope.launch { load() }

        viewModelScope.launch {
            repo.favoriteQuestionIds.collect { ids ->
                _uiState.update { it.copy(favoriteIds = ids) }
            }
        }
    }

    fun toggleFavoriteCurrent() {
        val q = _uiState.value.questions.getOrNull(_uiState.value.index) ?: return
        viewModelScope.launch {
            repo.toggleFavoriteQuestion(q.id)
        }
    }

    private suspend fun load() {
        _uiState.update { it.copy(isLoading = true, error = null) }

        val unit = runCatching { repo.getAllUnitsFlat().firstOrNull { u -> u.globalIndex == globalIndex } }.getOrNull()
        if (unit == null) {
            _uiState.update { it.copy(isLoading = false, error = "لم يتم العثور على الوحدة.") }
            return
        }

        // If first step, reset the in-progress run accumulator.
        if (stepIndex == 0) {
            runCatching { repo.resetUnitRun(globalIndex) }
            runCatching { repo.setUnitStepIndex(globalIndex, 0) }
        }

        val questions = runCatching {
            repo.getUnitLessonStepQuestions(globalIndex = globalIndex, stepIndex = stepIndex, stepsTotal = stepsTotal, stepSize = stepSize)
        }.getOrElse { emptyList() }

        if (questions.isEmpty()) {
            _uiState.update { it.copy(isLoading = false, error = "لا توجد أسئلة لهذه الخطوة.") }
            return
        }

        val now = System.currentTimeMillis()
        _uiState.update {
            it.copy(
                isLoading = false,
                error = null,
                unitTitleAr = unit.titleAr,
                unitTitleEn = unit.titleEn,
                xpReward = unit.xpReward,
                questions = questions,
                index = 0,
                selected = null,
                correctCount = 0,
                questionStartedAtMs = now,
                totalAnswerTimeMs = 0L
            )
        }
    }

    fun select(optionIndex: Int) {
        _uiState.update { st ->
            if (st.selected != null) return@update st
            val q = st.questions.getOrNull(st.index) ?: return@update st
            val ok = optionIndex == q.answerIndex
            val spent = (System.currentTimeMillis() - st.questionStartedAtMs).coerceAtLeast(0L)

            viewModelScope.launch {
                runCatching { repo.recordQuestionAttempt(question = q, correct = ok) }
            }

            st.copy(
                selected = optionIndex,
                correctCount = st.correctCount + if (ok) 1 else 0,
                totalAnswerTimeMs = st.totalAnswerTimeMs + spent
            )
        }
    }

    fun next(onFinished: (UnitStepResult) -> Unit) {
        val st = _uiState.value
        if (st.selected == null) return

        if (st.index + 1 >= st.questions.size) {
            viewModelScope.launch {
                val result = finalizeStep(st)
                onFinished(result)
            }
        } else {
            val now = System.currentTimeMillis()
            _uiState.update {
                it.copy(
                    index = it.index + 1,
                    selected = null,
                    questionStartedAtMs = now
                )
            }
        }
    }

    private suspend fun finalizeStep(st: UnitLessonUiState): UnitStepResult {
        val total = st.questions.size.coerceAtLeast(1)
        val accuracy = st.correctCount.toFloat() / total.toFloat()
        val scorePercent = (accuracy * 100f).roundToInt().coerceIn(0, 100)

        val avgSec = (st.totalAnswerTimeMs.toFloat() / total.toFloat()) / 1000f
        val speedBonus = ((10f - avgSec) / 10f).coerceIn(0f, 1f)
        val mastery = (0.7f * accuracy + 0.3f * speedBonus).coerceIn(0f, 1f)
        val masteryPercent = (mastery * 100f).roundToInt().coerceIn(0, 100)

        val stars = when {
            masteryPercent >= 90 -> 3
            masteryPercent >= 80 -> 2
            masteryPercent >= 65 -> 1
            else -> 0
        }

        // Update unit-run accumulator
        repo.addToUnitRun(globalIndex, correctDelta = st.correctCount, totalDelta = total, timeDeltaMs = st.totalAnswerTimeMs)

        val isFinal = (stepIndex >= stepsTotal - 1)
        var unlockedNext = false

        // XP for the STEP (small), and for FINAL completion we add unit.xpReward
        val wrong = (total - st.correctCount).coerceAtLeast(0)
        val xpFromAnswers = st.correctCount * 2 + wrong * 1
        val perfectBonus = if (st.correctCount == total) 10 else 0
        var xpEarned = xpFromAnswers + perfectBonus

        if (!isFinal) {
            // Persist step progress (completed stepIndex+1)
            repo.setUnitStepIndex(globalIndex, (stepIndex + 1).coerceAtMost(stepsTotal))
        } else {
            // Compute mastery from whole unit-run
            val (cAll, tAll, msAll) = repo.getUnitRun(globalIndex)
            val tSafe = tAll.coerceAtLeast(1)
            val accAll = cAll.toFloat() / tSafe.toFloat()
            val avgAllSec = (msAll.toFloat() / tSafe.toFloat()) / 1000f
            val speedAll = ((10f - avgAllSec) / 10f).coerceIn(0f, 1f)
            val masteryAll = (0.7f * accAll + 0.3f * speedAll).coerceIn(0f, 1f)
            val masteryAllPercent = (masteryAll * 100f).roundToInt().coerceIn(0, 100)

            val starsAll = when {
                masteryAllPercent >= 90 -> 3
                masteryAllPercent >= 80 -> 2
                masteryAllPercent >= 65 -> 1
                else -> 0
            }

            // Add base XP reward once on completion
            xpEarned += st.xpReward
            repo.addTotalXp(xpEarned)
            repo.saveUnitResult(globalIndex = globalIndex, scorePercent = (accAll * 100f).roundToInt(), masteryPercent = masteryAllPercent, stars = starsAll)

            // Unlock rule
            if (masteryAllPercent >= 80) {
                val current = repo.currentUnitGlobalIndex.first()
                if (current <= globalIndex) {
                    repo.setCurrentUnitGlobalIndex(globalIndex + 1)
                    unlockedNext = true
                }
            }

            // Mark steps as fully completed
            repo.setUnitStepIndex(globalIndex, stepsTotal)
            // Clear run accumulator
            repo.resetUnitRun(globalIndex)

            return UnitStepResult(
                globalIndex = globalIndex,
                stepIndex = stepIndex,
                stepsTotal = stepsTotal,
                scorePercent = (accAll * 100f).roundToInt().coerceIn(0, 100),
                masteryPercent = masteryAllPercent,
                stars = starsAll,
                correct = cAll,
                total = tSafe,
                xpEarned = xpEarned,
                unlockedNext = unlockedNext,
                isFinal = true
            )
        }

        return UnitStepResult(
            globalIndex = globalIndex,
            stepIndex = stepIndex,
            stepsTotal = stepsTotal,
            scorePercent = scorePercent,
            masteryPercent = masteryPercent,
            stars = stars,
            correct = st.correctCount,
            total = total,
            xpEarned = xpEarned,
            unlockedNext = unlockedNext,
            isFinal = false
        )
    }
}

data class UnitStepResult(
    val globalIndex: Int,
    val stepIndex: Int,
    val stepsTotal: Int,
    val scorePercent: Int,
    val masteryPercent: Int,
    val stars: Int,
    val correct: Int,
    val total: Int,
    val xpEarned: Int,
    val unlockedNext: Boolean,
    val isFinal: Boolean
)

class UnitLessonViewModelFactory(
    private val repo: AppRepository,
    private val globalIndex: Int,
    private val stepIndex: Int
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return UnitLessonViewModel(repo, globalIndex, stepIndex) as T
    }
}
