package com.emir.englishapp.ui.screens.assessment

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.emir.englishapp.domain.model.exercise.ExerciseTemplate

// ─────────────────────────────────────────────────────────────
// Shared design tokens
// ─────────────────────────────────────────────────────────────
private val Green = Color(0xFF58CC02)
private val GreenLight = Color(0xFFD7FFB8)
private val GreenShadow = Color(0xFF46A302)
private val Red = Color(0xFFEA2B2B)
private val RedLight = Color(0xFFFFDFE0)
private val RedShadow = Color(0xFFC42525)
private val Blue = Color(0xFF1CB0F6)
private val BlueLight = Color(0xFFDDF4FF)
private val BorderIdle = Color(0xFFE5E5E5)
private val TextDark = Color(0xFF4B4B4B)
private val TextMuted = Color(0xFFAFAFAF)
private val AudioOrange = Color(0xFFFF9600)

// ─────────────────────────────────────────────────────────────
// 1. Translate EN → AR  (MCQ)
// ─────────────────────────────────────────────────────────────
@Composable
internal fun TranslateEnToArBlock(
    exercise: ExerciseTemplate.TranslateEnToAr,
    selectedIndex: Int?,
    isAnswered: Boolean,
    isCorrect: Boolean?,
    onSelect: (Int) -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        PromptCard(text = exercise.promptEn, isEnglish = true)
        Spacer(Modifier.height(4.dp))
        exercise.optionsAr.forEachIndexed { idx, opt ->
            McqOption(
                text = opt,
                index = idx,
                selectedIndex = selectedIndex,
                correctIndex = exercise.answerIndex,
                isAnswered = isAnswered,
                onClick = { onSelect(idx) },
            )
        }
    }
}

// ─────────────────────────────────────────────────────────────
// 2. Translate AR → EN  (MCQ)
// ─────────────────────────────────────────────────────────────
@Composable
internal fun TranslateArToEnBlock(
    exercise: ExerciseTemplate.TranslateArToEn,
    selectedIndex: Int?,
    isAnswered: Boolean,
    isCorrect: Boolean?,
    onSelect: (Int) -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        PromptCard(text = exercise.promptAr, isEnglish = false)
        Spacer(Modifier.height(4.dp))
        exercise.optionsEn.forEachIndexed { idx, opt ->
            McqOption(
                text = opt,
                index = idx,
                selectedIndex = selectedIndex,
                correctIndex = exercise.answerIndex,
                isAnswered = isAnswered,
                onClick = { onSelect(idx) },
            )
        }
    }
}

// ─────────────────────────────────────────────────────────────
// 3. Fill in the Blank
// ─────────────────────────────────────────────────────────────
@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun FillBlankBlock(
    exercise: ExerciseTemplate.FillBlank,
    selectedIndex: Int?,
    isAnswered: Boolean,
    isCorrect: Boolean?,
    onSelect: (Int) -> Unit,
) {
    val selectedWord = selectedIndex?.let { exercise.optionsEn.getOrNull(it) }
    val parts = exercise.sentenceWithPlaceholder.split("___")

    Column(verticalArrangement = Arrangement.spacedBy(20.dp)) {
        // Sentence with inline blank
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            parts.forEachIndexed { i, part ->
                Text(
                    text = part,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextDark,
                )
                if (i < parts.size - 1) {
                    Spacer(Modifier.width(4.dp))
                    val blankBorderColor by animateColorAsState(
                        if (selectedWord != null) Blue else BorderIdle,
                        animationSpec = tween(200),
                        label = "blank_border",
                    )
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(2.dp, blankBorderColor),
                        color = if (selectedWord != null) BlueLight else Color(0xFFF7F7F7),
                    ) {
                        Text(
                            text = selectedWord ?: "        ",
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                            color = Blue,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 20.sp,
                        )
                    }
                    Spacer(Modifier.width(4.dp))
                }
            }
        }

        exercise.arHint?.let {
            Text(
                text = it,
                color = TextMuted,
                fontSize = 14.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth(),
            )
        }

        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            exercise.optionsEn.forEachIndexed { idx, opt ->
                val isSel = selectedIndex == idx
                val isRight = isAnswered && idx == exercise.answerIndex
                val isWrong = isAnswered && isSel && !isRight
                WordChipOption(
                    word = opt,
                    isSelected = isSel,
                    isRight = isRight,
                    isWrong = isWrong,
                    isAnswered = isAnswered,
                    onClick = { onSelect(idx) },
                )
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────
// 4. Spot the Error
// ─────────────────────────────────────────────────────────────
@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun SpotTheErrorBlock(
    exercise: ExerciseTemplate.SpotTheError,
    tappedIndex: Int?,
    isAnswered: Boolean,
    isCorrect: Boolean?,
    onTapToken: (Int) -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(20.dp)) {
        Text(
            text = "حدد الكلمة الخاطئة في الجملة:",
            fontSize = 17.sp,
            fontWeight = FontWeight.Bold,
            color = TextDark,
            modifier = Modifier.fillMaxWidth(),
            textAlign = TextAlign.Center,
        )
        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            exercise.sentenceTokens.forEachIndexed { idx, token ->
                val isTapped = tappedIndex == idx
                val isError = idx == exercise.errorIndex
                val bg by animateColorAsState(
                    when {
                        isAnswered && isError -> GreenLight
                        isAnswered && isTapped && !isError -> RedLight
                        isTapped -> BlueLight
                        else -> Color.White
                    },
                    label = "token_bg",
                )
                val border by animateColorAsState(
                    when {
                        isAnswered && isError -> Green
                        isAnswered && isTapped && !isError -> Red
                        isTapped -> Blue
                        else -> BorderIdle
                    },
                    label = "token_border",
                )
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(2.dp, border),
                    color = bg,
                    modifier = Modifier
                        .clickable(enabled = !isAnswered) { onTapToken(idx) }
                        .padding(horizontal = 4.dp, vertical = 4.dp),
                ) {
                    Text(
                        text = token,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextDark,
                    )
                }
            }
        }
        exercise.arHint?.let {
            Text(
                text = "المعنى: $it",
                color = TextMuted,
                fontSize = 14.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }
}

// ─────────────────────────────────────────────────────────────
// 5. Sentence Complete
// ─────────────────────────────────────────────────────────────
@Composable
internal fun SentenceCompleteBlock(
    exercise: ExerciseTemplate.SentenceComplete,
    selectedIndex: Int?,
    isAnswered: Boolean,
    isCorrect: Boolean?,
    onSelect: (Int) -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            color = Color(0xFFF7F9FC),
            border = BorderStroke(2.dp, BorderIdle),
        ) {
            Text(
                text = exercise.sentencePrefix,
                modifier = Modifier.padding(18.dp),
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = TextDark,
            )
        }
        exercise.arHint?.let {
            Text(
                text = it,
                color = TextMuted,
                fontSize = 14.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth(),
            )
        }
        exercise.optionsEn.forEachIndexed { idx, opt ->
            McqOption(
                text = opt,
                index = idx,
                selectedIndex = selectedIndex,
                correctIndex = exercise.answerIndex,
                isAnswered = isAnswered,
                onClick = { onSelect(idx) },
            )
        }
    }
}

// ─────────────────────────────────────────────────────────────
// 6. Pronunciation Bridge
// ─────────────────────────────────────────────────────────────
@Composable
internal fun PronunciationBridgeBlock(
    exercise: ExerciseTemplate.PronunciationBridge,
    selectedIndex: Int?,
    isAnswered: Boolean,
    isCorrect: Boolean?,
    audioState: AudioPlaybackState,
    onSelect: (Int) -> Unit,
    onPlayAudio: () -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        AudioPulseButton(
            label = exercise.wordEn,
            isPlaying = audioState.isPlaying,
            hasAudio = exercise.audioAssetPath != null,
            onClick = onPlayAudio,
        )
        Text(
            text = "اختر النطق الصحيح:",
            fontSize = 15.sp,
            color = TextMuted,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth(),
        )
        exercise.options.forEachIndexed { idx, opt ->
            McqOption(
                text = opt,
                index = idx,
                selectedIndex = selectedIndex,
                correctIndex = exercise.answerIndex,
                isAnswered = isAnswered,
                onClick = { onSelect(idx) },
            )
        }
    }
}

// ─────────────────────────────────────────────────────────────
// 7. Sentence Reorder (Kinetic)
// ─────────────────────────────────────────────────────────────
@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun SentenceReorderBlock(
    exercise: ExerciseTemplate.SentenceReorder,
    available: List<String>,
    selected: List<String>,
    isAnswered: Boolean,
    isCorrect: Boolean?,
    onPick: (String) -> Unit,
    onUnpick: (String) -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(24.dp)) {
        Text(
            text = exercise.promptAr,
            fontSize = 17.sp,
            fontWeight = FontWeight.Bold,
            color = TextDark,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth(),
        )

        // Drop zone
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFFF7F9FC), RoundedCornerShape(16.dp))
                .padding(12.dp),
        ) {
            if (selected.isEmpty()) {
                Text(
                    text = "اسحب الكلمات هنا ...",
                    color = TextMuted,
                    fontSize = 15.sp,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Center,
                )
            } else {
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    selected.forEach { word ->
                        ReorderChip(
                            word = word,
                            isInDropZone = true,
                            isAnswered = isAnswered,
                            isCorrect = isCorrect,
                            onClick = { onUnpick(word) },
                        )
                    }
                }
            }
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(2.dp)
                .background(BorderIdle),
        )

        // Word bank
        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            val usedCounts = selected.groupingBy { it }.eachCount().toMutableMap()
            val displayCounts = mutableMapOf<String, Int>()

            exercise.shuffledWords.forEach { word ->
                val totalUsed = usedCounts[word] ?: 0
                val shown = displayCounts[word] ?: 0
                val isConsumed = shown < totalUsed
                displayCounts[word] = shown + 1
                ReorderChip(
                    word = word,
                    isInDropZone = false,
                    isConsumed = isConsumed,
                    isAnswered = isAnswered,
                    isCorrect = null,
                    onClick = { if (!isConsumed) onPick(word) },
                )
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────
// 8. Match Pairs (Kinetic)
// ─────────────────────────────────────────────────────────────
@Composable
internal fun MatchPairsBlock(
    exercise: ExerciseTemplate.MatchPairs,
    matchState: SessionOrchestrator.MatchState,
    isAnswered: Boolean,
    isCorrect: Boolean?,
    onTapLeft: (Int) -> Unit,
    onTapRight: (Int) -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(
            text = "طابق الكلمات مع معانيها:",
            fontSize = 17.sp,
            fontWeight = FontWeight.Bold,
            color = TextDark,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth(),
        )
        matchState.leftTokens.indices.forEach { i ->
            val leftToken = matchState.leftTokens.getOrElse(i) { "" }
            val rightToken = matchState.rightTokens.getOrElse(i) { "" }
            val isMatched = matchState.matched.containsKey(i)
            val isPendingLeft = matchState.pendingLeftIndex == i

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                // Left column (EN)
                val lBg by animateColorAsState(
                    when { isMatched -> GreenLight; isPendingLeft -> BlueLight; else -> Color.White },
                    label = "lbg$i",
                )
                val lBorder by animateColorAsState(
                    when { isMatched -> Green; isPendingLeft -> Blue; else -> BorderIdle },
                    label = "lborder$i",
                )
                Surface(
                    modifier = Modifier
                        .weight(1f)
                        .clickable(enabled = !isAnswered && !isMatched) { onTapLeft(i) },
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(2.dp, lBorder),
                    color = lBg,
                ) {
                    Text(
                        text = leftToken,
                        modifier = Modifier.padding(14.dp),
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextDark,
                        textAlign = TextAlign.Center,
                    )
                }

                if (isMatched) {
                    Icon(Icons.Default.Check, contentDescription = null, tint = Green, modifier = Modifier.size(20.dp))
                } else {
                    Box(modifier = Modifier.size(20.dp))
                }

                // Right column (AR)
                val rightMatchedByLeft = matchState.matched[i]
                val isRightMatched = rightMatchedByLeft != null
                val isPendingRight = matchState.pendingRightIndex == i

                val rBg by animateColorAsState(
                    when { isRightMatched -> GreenLight; isPendingRight -> BlueLight; else -> Color.White },
                    label = "rbg$i",
                )
                val rBorder by animateColorAsState(
                    when { isRightMatched -> Green; isPendingRight -> Blue; else -> BorderIdle },
                    label = "rborder$i",
                )
                Surface(
                    modifier = Modifier
                        .weight(1f)
                        .clickable(enabled = !isAnswered && !isRightMatched && matchState.pendingLeftIndex != null) {
                            onTapRight(i)
                        },
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(2.dp, rBorder),
                    color = rBg,
                ) {
                    Text(
                        text = rightToken,
                        modifier = Modifier.padding(14.dp),
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextDark,
                        textAlign = TextAlign.Center,
                    )
                }
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────
// 9. Word Sort (Kinetic)
// ─────────────────────────────────────────────────────────────
@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun WordSortBlock(
    exercise: ExerciseTemplate.WordSort,
    sortState: SessionOrchestrator.WordSortState,
    isAnswered: Boolean,
    isCorrect: Boolean?,
    onSort: (String, Int) -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text(
            text = "صنّف الكلمات:",
            fontSize = 17.sp,
            fontWeight = FontWeight.Bold,
            color = TextDark,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth(),
        )

        // Category buckets
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            listOf(
                Triple(0, exercise.categoryA, sortState.categoryA),
                Triple(1, exercise.categoryB, sortState.categoryB),
            ).forEach { (catIdx, category, placed) ->
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (catIdx == 0) Color(0xFFEEF9E6) else Color(0xFFEDF6FF),
                        border = BorderStroke(2.dp, if (catIdx == 0) Green else Blue),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Column(
                            modifier = Modifier.padding(10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                        ) {
                            Text(
                                text = if (catIdx == 0) category.labelEn else category.labelEn,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (catIdx == 0) Green else Blue,
                                textAlign = TextAlign.Center,
                            )
                            Text(
                                text = if (catIdx == 0) category.labelAr else category.labelAr,
                                fontSize = 13.sp,
                                color = TextMuted,
                                textAlign = TextAlign.Center,
                            )
                        }
                    }
                    // Placed words
                    placed.forEach { word ->
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp),
                            color = if (catIdx == 0) GreenLight else BlueLight,
                            border = BorderStroke(1.dp, if (catIdx == 0) Green else Blue),
                        ) {
                            Text(
                                text = word,
                                modifier = Modifier.padding(10.dp),
                                fontSize = 15.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = TextDark,
                                textAlign = TextAlign.Center,
                            )
                        }
                    }
                }
            }
        }

        // Unsorted pool
        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            sortState.unsorted.forEach { word ->
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    // Sort A button
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(2.dp, Green),
                        color = Color.White,
                        modifier = Modifier.clickable(enabled = !isAnswered) { onSort(word, 0) },
                    ) {
                        Text(
                            text = "← ${exercise.categoryA.labelEn.take(6)}",
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                            fontSize = 11.sp,
                            color = Green,
                            fontWeight = FontWeight.Bold,
                        )
                    }
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(2.dp, BorderIdle),
                        color = Color.White,
                    ) {
                        Text(
                            text = word,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextDark,
                        )
                    }
                    // Sort B button
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(2.dp, Blue),
                        color = Color.White,
                        modifier = Modifier.clickable(enabled = !isAnswered) { onSort(word, 1) },
                    ) {
                        Text(
                            text = "${exercise.categoryB.labelEn.take(6)} →",
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                            fontSize = 11.sp,
                            color = Blue,
                            fontWeight = FontWeight.Bold,
                        )
                    }
                }
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────
// 10. Listen and Pick (Auditory)
// ─────────────────────────────────────────────────────────────
@Composable
internal fun ListenAndPickBlock(
    exercise: ExerciseTemplate.ListenAndPick,
    selectedIndex: Int?,
    isAnswered: Boolean,
    isCorrect: Boolean?,
    audioState: AudioPlaybackState,
    onSelect: (Int) -> Unit,
    onPlayAudio: () -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        AudioPulseButton(
            label = "استمع واختر المعنى",
            isPlaying = audioState.isPlaying,
            hasAudio = true,
            onClick = onPlayAudio,
        )

        // Word-by-word highlight if timestamps available
        if (exercise.wordTimestamps.isNotEmpty()) {
            val words = exercise.correctText.split(Regex("\\s+"))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
            ) {
                words.forEachIndexed { idx, w ->
                    val isActive = idx == audioState.activeWordIndex
                    val isDone = idx < audioState.completedWordCount
                    Text(
                        text = "$w ",
                        fontSize = 17.sp,
                        fontWeight = if (isActive) FontWeight.ExtraBold else FontWeight.Normal,
                        color = when {
                            isActive -> AudioOrange
                            isDone -> TextDark
                            else -> TextMuted
                        },
                    )
                }
            }
        }

        exercise.options.forEachIndexed { idx, opt ->
            McqOption(
                text = opt,
                index = idx,
                selectedIndex = selectedIndex,
                correctIndex = exercise.answerIndex,
                isAnswered = isAnswered,
                onClick = { onSelect(idx) },
            )
        }
    }
}

// ─────────────────────────────────────────────────────────────
// 11. Dictation Reorder (Auditory + Kinetic)
// ─────────────────────────────────────────────────────────────
@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun DictationReorderBlock(
    exercise: ExerciseTemplate.DictationReorder,
    available: List<String>,
    selected: List<String>,
    isAnswered: Boolean,
    isCorrect: Boolean?,
    audioState: AudioPlaybackState,
    onPick: (String) -> Unit,
    onUnpick: (String) -> Unit,
    onPlayAudio: () -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(20.dp)) {
        AudioPulseButton(
            label = "استمع ورتّب الكلمات",
            isPlaying = audioState.isPlaying,
            hasAudio = true,
            onClick = onPlayAudio,
        )

        // Playback progress bar with word count
        if (exercise.wordTimestamps.isNotEmpty() && audioState.isPlaying) {
            LinearProgressIndicator(
                progress = {
                    val dur = audioState.durationMs.coerceAtLeast(1L)
                    (audioState.positionMs.toFloat() / dur).coerceIn(0f, 1f)
                },
                modifier = Modifier.fillMaxWidth().height(6.dp),
                color = AudioOrange,
                trackColor = BorderIdle,
                strokeCap = StrokeCap.Round,
            )
        }

        // Drop zone
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFFF7F9FC), RoundedCornerShape(16.dp))
                .padding(14.dp),
        ) {
            if (selected.isEmpty()) {
                Text(
                    text = "اسحب الكلمات هنا ...",
                    color = TextMuted,
                    fontSize = 15.sp,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Center,
                )
            } else {
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    selected.forEach { word ->
                        ReorderChip(
                            word = word,
                            isInDropZone = true,
                            isAnswered = isAnswered,
                            isCorrect = isCorrect,
                            onClick = { onUnpick(word) },
                        )
                    }
                }
            }
        }

        Box(modifier = Modifier.fillMaxWidth().height(2.dp).background(BorderIdle))

        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            val usedCounts = selected.groupingBy { it }.eachCount().toMutableMap()
            val displayCounts = mutableMapOf<String, Int>()
            exercise.shuffledWords.forEach { word ->
                val totalUsed = usedCounts[word] ?: 0
                val shown = displayCounts[word] ?: 0
                val isConsumed = shown < totalUsed
                displayCounts[word] = shown + 1
                ReorderChip(
                    word = word,
                    isInDropZone = false,
                    isConsumed = isConsumed,
                    isAnswered = isAnswered,
                    isCorrect = null,
                    onClick = { if (!isConsumed) onPick(word) },
                )
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────
// 12. Type What You Hear (Auditory)
// ─────────────────────────────────────────────────────────────
@Composable
internal fun TypeWhatYouHearBlock(
    exercise: ExerciseTemplate.TypeWhatYouHear,
    selectedIndex: Int?,
    isAnswered: Boolean,
    isCorrect: Boolean?,
    audioState: AudioPlaybackState,
    onSelect: (Int) -> Unit,
    onPlayAudio: () -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        AudioPulseButton(
            label = "استمع واختر الكلمة الصحيحة",
            isPlaying = audioState.isPlaying,
            hasAudio = true,
            onClick = onPlayAudio,
        )
        exercise.options.forEachIndexed { idx, opt ->
            McqOption(
                text = opt,
                index = idx,
                selectedIndex = selectedIndex,
                correctIndex = exercise.answerIndex,
                isAnswered = isAnswered,
                onClick = { onSelect(idx) },
            )
        }
    }
}

// ─────────────────────────────────────────────────────────────
// Shared private composables
// ─────────────────────────────────────────────────────────────

@Composable
private fun PromptCard(text: String, isEnglish: Boolean) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        color = Color(0xFFF7F9FC),
        border = BorderStroke(2.dp, BorderIdle),
    ) {
        Text(
            text = text,
            modifier = Modifier.padding(20.dp),
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = TextDark,
            textAlign = if (isEnglish) TextAlign.Start else TextAlign.End,
        )
    }
}

@Composable
internal fun McqOption(
    text: String,
    index: Int,
    selectedIndex: Int?,
    correctIndex: Int,
    isAnswered: Boolean,
    onClick: () -> Unit,
) {
    val isSelected = selectedIndex == index
    val isRight = isAnswered && index == correctIndex
    val isWrong = isAnswered && isSelected && index != correctIndex

    val borderColor by animateColorAsState(
        when { isRight -> Green; isWrong -> Red; isSelected -> Blue; else -> BorderIdle },
        label = "opt_border_$index",
    )
    val shadowColor by animateColorAsState(
        when { isRight -> GreenShadow; isWrong -> RedShadow; isSelected -> Color(0xFF1899D6); else -> BorderIdle },
        label = "opt_shadow_$index",
    )
    val bgColor by animateColorAsState(
        when { isRight -> GreenLight; isWrong -> RedLight; isSelected -> BlueLight; else -> Color.White },
        label = "opt_bg_$index",
    )
    val sinkOffset by animateDpAsState(
        if (isAnswered && isSelected) 0.dp else 4.dp,
        animationSpec = tween(100),
        label = "opt_sink_$index",
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(enabled = !isAnswered) { onClick() }
            .background(shadowColor, RoundedCornerShape(16.dp))
            .padding(bottom = sinkOffset),
    ) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            color = bgColor,
            border = BorderStroke(2.dp, borderColor),
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                // Index badge
                Surface(
                    modifier = Modifier.size(32.dp),
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(2.dp, if (borderColor == BorderIdle) BorderIdle else borderColor),
                    color = Color.Transparent,
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(
                            text = (index + 1).toString(),
                            color = if (borderColor == BorderIdle) TextMuted else borderColor,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                        )
                    }
                }
                Spacer(Modifier.width(14.dp))
                Text(
                    text = text,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextDark,
                    modifier = Modifier.weight(1f),
                )
                if (isRight) {
                    Icon(Icons.Default.Check, contentDescription = null, tint = Green, modifier = Modifier.size(22.dp))
                }
            }
        }
    }
}

@Composable
private fun ReorderChip(
    word: String,
    isInDropZone: Boolean,
    isConsumed: Boolean = false,
    isAnswered: Boolean,
    isCorrect: Boolean?,
    onClick: () -> Unit,
) {
    val bg = when {
        isConsumed -> Color(0xFFE5E5E5)
        isInDropZone && isAnswered && isCorrect == true -> GreenLight
        isInDropZone && isAnswered && isCorrect == false -> RedLight
        isInDropZone -> BlueLight
        else -> Color.White
    }
    val border = when {
        isConsumed -> Color.Transparent
        isInDropZone && isAnswered && isCorrect == true -> Green
        isInDropZone && isAnswered && isCorrect == false -> Red
        isInDropZone -> Blue
        else -> BorderIdle
    }
    val shadow = if (isConsumed || isInDropZone) Color.Transparent else BorderIdle

    Box(
        modifier = Modifier
            .clickable(enabled = !isConsumed && !isAnswered) { onClick() }
            .background(shadow, RoundedCornerShape(12.dp))
            .padding(bottom = if (isConsumed) 0.dp else 3.dp),
    ) {
        Surface(
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(2.dp, border),
            color = bg,
        ) {
            Text(
                text = word,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold,
                color = if (isConsumed) Color.Transparent else TextDark,
            )
        }
    }
}

@Composable
private fun WordChipOption(
    word: String,
    isSelected: Boolean,
    isRight: Boolean,
    isWrong: Boolean,
    isAnswered: Boolean,
    onClick: () -> Unit,
) {
    val bg by animateColorAsState(
        when { isRight -> GreenLight; isWrong -> RedLight; isSelected -> BlueLight; else -> Color.White },
        label = "wc_bg",
    )
    val border by animateColorAsState(
        when { isRight -> Green; isWrong -> Red; isSelected -> Blue; else -> BorderIdle },
        label = "wc_border",
    )
    Surface(
        modifier = Modifier
            .clickable(enabled = !isAnswered) { onClick() }
            .padding(4.dp),
        shape = RoundedCornerShape(12.dp),
        color = bg,
        border = BorderStroke(2.dp, border),
    ) {
        Text(
            text = word,
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp),
            fontSize = 17.sp,
            fontWeight = FontWeight.Bold,
            color = TextDark,
        )
    }
}

@Composable
internal fun AudioPulseButton(
    label: String,
    isPlaying: Boolean,
    hasAudio: Boolean,
    onClick: () -> Unit,
) {
    val bgColor by animateColorAsState(
        if (isPlaying) AudioOrange else Color(0xFFFFF3E0),
        animationSpec = tween(300),
        label = "audio_bg",
    )
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(enabled = hasAudio) { onClick() },
        shape = RoundedCornerShape(20.dp),
        color = bgColor,
        border = BorderStroke(2.dp, AudioOrange),
    ) {
        Row(
            modifier = Modifier.padding(20.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .background(AudioOrange, CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    Icons.Default.VolumeUp,
                    contentDescription = "Play",
                    tint = Color.White,
                    modifier = Modifier.size(26.dp),
                )
            }
            Spacer(Modifier.width(14.dp))
            Text(
                text = label,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = if (isPlaying) Color.White else TextDark,
            )
        }
    }
}
