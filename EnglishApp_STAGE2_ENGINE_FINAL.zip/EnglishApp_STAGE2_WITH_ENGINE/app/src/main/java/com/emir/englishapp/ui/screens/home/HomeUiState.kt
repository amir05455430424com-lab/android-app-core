package com.emir.englishapp.ui.screens.home

data class HomeUiState(
    val momentum: Int = 0,
    val momentumHint: String? = null,
    val currentUnitIndex: Int = 0,

    // Smart Home stats
    val totalXp: Int = 0,
    val xpToday: Int = 0,
    val streakDays: Int = 0,
    val dailyDone: Boolean = false,

    // Smart messaging
    val headerTitle: String = "",
    val headerSubtitle: String = "",
    val primaryCtaTitle: String = "▶ استمر بالتعلم",
    val primaryCtaSubtitle: String = "تابع وحدتك الحالية",
    val guideMessage: String = "",

    // Last Daily summary (optional)
    val lastDailyTitle: String? = null,
    val lastDailySubtitle: String? = null
)
