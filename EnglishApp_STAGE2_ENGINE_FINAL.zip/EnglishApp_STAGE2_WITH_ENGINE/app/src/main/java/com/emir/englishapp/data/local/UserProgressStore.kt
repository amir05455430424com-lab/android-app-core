package com.emir.englishapp.data.local

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate

private val Context.dataStore by preferencesDataStore(name = "user_progress")

class UserProgressStore(
    private val context: Context
) {
    companion object {
        private val KEY_MOMENTUM = intPreferencesKey("momentum")
        private val KEY_CURRENT_UNIT_GLOBAL_INDEX = intPreferencesKey("current_unit_global_index")

        // Pro Path progress (100 units)
        private val KEY_PRO_CURRENT_UNIT_GLOBAL_INDEX = intPreferencesKey("pro_current_unit_global_index")
        private val KEY_PRO_UNIT_STEP_INDEX_JSON = stringPreferencesKey("pro_unit_step_index_json")
        private val KEY_PRO_UNIT_RUN_CORRECT_JSON = stringPreferencesKey("pro_unit_run_correct_json")
        private val KEY_PRO_UNIT_RUN_TOTAL_JSON = stringPreferencesKey("pro_unit_run_total_json")
        private val KEY_PRO_UNIT_RUN_TIME_JSON = stringPreferencesKey("pro_unit_run_time_json")
        // Pro Path V3: persist generated run questions (dynamic) per unit.
        // Format: { "<globalIndex>": "[ ...questionJsonObjects... ]" }
        private val KEY_PRO_UNIT_RUN_PLAN_JSON = stringPreferencesKey("pro_unit_run_plan_json")
        private val KEY_PRO_UNIT_ATTEMPTS_JSON = stringPreferencesKey("pro_unit_attempts_json")
        private val KEY_PRO_UNIT_BESTSCORE_JSON = stringPreferencesKey("pro_unit_bestscore_json")
        private val KEY_PRO_UNIT_MASTERY_JSON = stringPreferencesKey("pro_unit_mastery_json")
        private val KEY_PRO_UNIT_STARS_JSON = stringPreferencesKey("pro_unit_stars_json")
        private val KEY_PRO_UNIT_LASTPLAYED_JSON = stringPreferencesKey("pro_unit_lastplayed_json")

// Stage 4 progress (course units)
private val KEY_TOTAL_XP = intPreferencesKey("total_xp")
private val KEY_DAILY_XP_TODAY = intPreferencesKey("daily_xp_today")
private val KEY_STREAK_DAYS = intPreferencesKey("streak_days")
private val KEY_DAILY_SESSION_DATE = stringPreferencesKey("daily_session_date") // yyyy-MM-dd
private val KEY_DAILY_SESSION_DONE = intPreferencesKey("daily_session_done") // 0/1

// Track last COMPLETED day for streak logic (separate from reset day key above)
private val KEY_STREAK_LAST_COMPLETED_DATE = stringPreferencesKey("streak_last_completed_date") // yyyy-MM-dd

// Smart Home: persist last daily summary in one blob
private val KEY_LAST_DAILY_SUMMARY_JSON = stringPreferencesKey("last_daily_summary_json")

private val KEY_UNIT_ATTEMPTS_JSON = stringPreferencesKey("unit_attempts_json")
private val KEY_UNIT_BESTSCORE_JSON = stringPreferencesKey("unit_bestscore_json")
private val KEY_UNIT_MASTERY_JSON = stringPreferencesKey("unit_mastery_json") // percent 0..100
private val KEY_UNIT_STARS_JSON = stringPreferencesKey("unit_stars_json") // 0..3
private val KEY_UNIT_LASTPLAYED_JSON = stringPreferencesKey("unit_lastplayed_json") // epoch millis

// Stage 4.3: Unit lesson steps (nodes)
private val KEY_UNIT_STEP_INDEX_JSON = stringPreferencesKey("unit_step_index_json") // {"1":0, "2":3}
private val KEY_UNIT_RUN_CORRECT_JSON = stringPreferencesKey("unit_run_correct_json") // {"1": 12}
private val KEY_UNIT_RUN_TOTAL_JSON = stringPreferencesKey("unit_run_total_json") // {"1": 24}
private val KEY_UNIT_RUN_TIME_JSON = stringPreferencesKey("unit_run_time_json") // {"1": 12345}

// Stage 4.2: Smart selection + adaptive learning
private val KEY_USED_QUESTION_IDS_JSON = stringPreferencesKey("used_question_ids_json") // JSON array of IDs (ring buffer)
private val KEY_TAG_STATS_JSON = stringPreferencesKey("tag_stats_json") // {"tag": {"c": int, "t": int}}

// Daily session question set (stable within the day until finished)
private val KEY_DAILY_SESSION_QIDS_DATE = stringPreferencesKey("daily_session_qids_date")
private val KEY_DAILY_SESSION_QIDS_JSON = stringPreferencesKey("daily_session_qids_json")

// Favorites
private val KEY_FAVORITE_QUESTION_IDS_JSON = stringPreferencesKey("favorite_question_ids_json") // JSON array of IDs
private val KEY_FAVORITE_PHRASE_IDS_JSON = stringPreferencesKey("favorite_phrase_ids_json") // JSON array of IDs
private val KEY_FAVORITE_LESSON_IDS_JSON = stringPreferencesKey("favorite_lesson_ids_json") // JSON array of IDs


        // Stage 2 quiz (correct counts by question id)
        private val KEY_QUIZ_CORRECT_COUNTS_JSON = stringPreferencesKey("quiz_correct_counts_json")

        // Stage 3 lessons progress
        private val KEY_UNLOCKED_INDEX_BY_LEVEL_JSON = stringPreferencesKey("unlocked_index_by_level_json")
        private val KEY_COMPLETED_LESSONS_BY_LEVEL_JSON = stringPreferencesKey("completed_lessons_by_level_json")
        // Lesson Player: persist last viewed step per lesson key (levelId|lessonId)
        private val KEY_LESSON_STEP_INDEX_JSON = stringPreferencesKey("lesson_step_index_json")
    }

    // ===== Existing fields =====
    val momentum: Flow<Int> = context.dataStore.data.map { it[KEY_MOMENTUM] ?: 0 }

    // IMPORTANT: Units are 1-based in the course JSON (globalIndex starts from 1).
    // If the key is missing OR has an invalid value (0/negative), bootstrap to 1.
    val currentUnitGlobalIndex: Flow<Int> =
        context.dataStore.data.map { (it[KEY_CURRENT_UNIT_GLOBAL_INDEX] ?: 1).coerceAtLeast(1) }

    suspend fun setMomentum(value: Int) {
        context.dataStore.edit { it[KEY_MOMENTUM] = value }
    }

    suspend fun setCurrentUnitGlobalIndex(value: Int) {
        context.dataStore.edit { it[KEY_CURRENT_UNIT_GLOBAL_INDEX] = value }
    }


    // ===== Pro Path (separate index) =====
    // IMPORTANT: Units are 1-based.
    val proCurrentUnitGlobalIndex: Flow<Int> =
        context.dataStore.data.map { (it[KEY_PRO_CURRENT_UNIT_GLOBAL_INDEX] ?: 1).coerceAtLeast(1) }

    suspend fun setProCurrentUnitGlobalIndex(value: Int) {
        context.dataStore.edit { it[KEY_PRO_CURRENT_UNIT_GLOBAL_INDEX] = value.coerceAtLeast(1) }
    }

    // ===== Stage 2 quiz stats =====
    suspend fun getQuizCorrectCounts(): Map<Int, Int> {
        val json = context.dataStore.data.map { it[KEY_QUIZ_CORRECT_COUNTS_JSON] ?: "{}" }.first()
        val obj = runCatching { JSONObject(json) }.getOrElse { JSONObject() }
        val out = mutableMapOf<Int, Int>()
        val keys = obj.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            out[k.toIntOrNull() ?: continue] = obj.optInt(k, 0)
        }
        return out
    }

    suspend fun incrementQuizCorrect(id: Int) {
        context.dataStore.edit { prefs ->
            val raw = prefs[KEY_QUIZ_CORRECT_COUNTS_JSON] ?: "{}"
            val obj = runCatching { JSONObject(raw) }.getOrElse { JSONObject() }
            val key = id.toString()
            val cur = obj.optInt(key, 0)
            obj.put(key, cur + 1)
            prefs[KEY_QUIZ_CORRECT_COUNTS_JSON] = obj.toString()
        }
    }

    // ===== Stage 3 lessons progress =====
    suspend fun getUnlockedLessonIndex(levelId: Int): Int {
        val json = context.dataStore.data.map { it[KEY_UNLOCKED_INDEX_BY_LEVEL_JSON] ?: "{}" }.first()
        val obj = runCatching { JSONObject(json) }.getOrElse { JSONObject() }
        return obj.optInt(levelId.toString(), 0)
    }

    suspend fun setUnlockedLessonIndex(levelId: Int, index: Int) {
        context.dataStore.edit { prefs ->
            val raw = prefs[KEY_UNLOCKED_INDEX_BY_LEVEL_JSON] ?: "{}"
            val obj = runCatching { JSONObject(raw) }.getOrElse { JSONObject() }
            obj.put(levelId.toString(), index)
            prefs[KEY_UNLOCKED_INDEX_BY_LEVEL_JSON] = obj.toString()
        }
    }

    suspend fun getCompletedLessons(levelId: Int): Set<String> {
        val json = context.dataStore.data.map { it[KEY_COMPLETED_LESSONS_BY_LEVEL_JSON] ?: "{}" }.first()
        val obj = runCatching { JSONObject(json) }.getOrElse { JSONObject() }
        val arr = obj.optJSONArray(levelId.toString()) ?: JSONArray()
        val out = mutableSetOf<String>()
        for (i in 0 until arr.length()) {
            val v = arr.optString(i, "")
            if (v.isNotBlank()) out.add(v)
        }
        return out
    }

    suspend fun addCompletedLesson(levelId: Int, lessonId: String) {
        context.dataStore.edit { prefs ->
            val raw = prefs[KEY_COMPLETED_LESSONS_BY_LEVEL_JSON] ?: "{}"
            val obj = runCatching { JSONObject(raw) }.getOrElse { JSONObject() }
            val key = levelId.toString()
            val arr = obj.optJSONArray(key) ?: JSONArray()
            // Deduplicate
            var exists = false
            for (i in 0 until arr.length()) {
                if (arr.optString(i) == lessonId) {
                    exists = true
                    break
                }
            }
            if (!exists) arr.put(lessonId)
            obj.put(key, arr)
            prefs[KEY_COMPLETED_LESSONS_BY_LEVEL_JSON] = obj.toString()
        }
    }

// ===== Lesson Player step restore =====
suspend fun getLessonStepIndex(key: String): Int {
    val raw = context.dataStore.data.map { it[KEY_LESSON_STEP_INDEX_JSON] ?: "{}" }.first()
    val obj = runCatching { JSONObject(raw) }.getOrElse { JSONObject() }
    return obj.optInt(key, 0).coerceAtLeast(0)
}

suspend fun setLessonStepIndex(key: String, index: Int) {
    context.dataStore.edit { prefs ->
        val raw = prefs[KEY_LESSON_STEP_INDEX_JSON] ?: "{}"
        val obj = runCatching { JSONObject(raw) }.getOrElse { JSONObject() }
        obj.put(key, index.coerceAtLeast(0))
        prefs[KEY_LESSON_STEP_INDEX_JSON] = obj.toString()
    }
}


// ===== Stage 4 (Course units) progress =====

val totalXp: Flow<Int> = context.dataStore.data.map { it[KEY_TOTAL_XP] ?: 0 }
val dailyXpToday: Flow<Int> = context.dataStore.data.map { it[KEY_DAILY_XP_TODAY] ?: 0 }
val streakDays: Flow<Int> = context.dataStore.data.map { it[KEY_STREAK_DAYS] ?: 0 }

// ===== Favorites =====
private fun parseJsonArraySet(raw: String): Set<String> {
    val arr = runCatching { JSONArray(raw) }.getOrElse { JSONArray() }
    return buildSet {
        for (i in 0 until arr.length()) {
            val v = arr.optString(i, "")
            if (v.isNotBlank()) add(v)
        }
    }
}

private fun toJsonArrayString(set: Set<String>): String {
    val out = JSONArray()
    set.forEach { out.put(it) }
    return out.toString()
}

val favoriteQuestionIds: Flow<Set<String>> =
    context.dataStore.data.map { prefs ->
        parseJsonArraySet(prefs[KEY_FAVORITE_QUESTION_IDS_JSON].orEmpty())
    }

val favoritePhraseIds: Flow<Set<String>> =
    context.dataStore.data.map { prefs ->
        parseJsonArraySet(prefs[KEY_FAVORITE_PHRASE_IDS_JSON].orEmpty())
    }

val favoriteLessonIds: Flow<Set<String>> =
    context.dataStore.data.map { prefs ->
        parseJsonArraySet(prefs[KEY_FAVORITE_LESSON_IDS_JSON].orEmpty())
    }

suspend fun toggleFavoriteQuestionId(id: String) {
    if (id.isBlank()) return
    context.dataStore.edit { prefs ->
        val set = parseJsonArraySet(prefs[KEY_FAVORITE_QUESTION_IDS_JSON].orEmpty()).toMutableSet()
        if (set.contains(id)) set.remove(id) else set.add(id)
        prefs[KEY_FAVORITE_QUESTION_IDS_JSON] = toJsonArrayString(set)
    }
}

suspend fun toggleFavoritePhraseId(id: String) {
    if (id.isBlank()) return
    context.dataStore.edit { prefs ->
        val set = parseJsonArraySet(prefs[KEY_FAVORITE_PHRASE_IDS_JSON].orEmpty()).toMutableSet()
        if (set.contains(id)) set.remove(id) else set.add(id)
        prefs[KEY_FAVORITE_PHRASE_IDS_JSON] = toJsonArrayString(set)
    }
}

suspend fun toggleFavoriteLessonId(id: String) {
    if (id.isBlank()) return
    context.dataStore.edit { prefs ->
        val set = parseJsonArraySet(prefs[KEY_FAVORITE_LESSON_IDS_JSON].orEmpty()).toMutableSet()
        if (set.contains(id)) set.remove(id) else set.add(id)
        prefs[KEY_FAVORITE_LESSON_IDS_JSON] = toJsonArrayString(set)
    }
}

suspend fun addTotalXp(delta: Int) {
    if (delta <= 0) return
    context.dataStore.edit { prefs ->
        val cur = prefs[KEY_TOTAL_XP] ?: 0
        prefs[KEY_TOTAL_XP] = cur + delta
        val today = prefs[KEY_DAILY_XP_TODAY] ?: 0
        prefs[KEY_DAILY_XP_TODAY] = today + delta
    }
}

suspend fun markDailySessionDone(today: String) {
    context.dataStore.edit { prefs ->
        // If already done today, don't mutate streak again.
        val alreadyDone = (prefs[KEY_DAILY_SESSION_DONE] ?: 0) == 1 && prefs[KEY_DAILY_SESSION_DATE].orEmpty() == today

        prefs[KEY_DAILY_SESSION_DATE] = today
        prefs[KEY_DAILY_SESSION_DONE] = 1

        if (!alreadyDone) {
            val lastCompleted = prefs[KEY_STREAK_LAST_COMPLETED_DATE].orEmpty()
            val newStreak = computeNextStreak(lastCompletedDate = lastCompleted, today = today, currentStreak = (prefs[KEY_STREAK_DAYS] ?: 0))
            prefs[KEY_STREAK_DAYS] = newStreak
            prefs[KEY_STREAK_LAST_COMPLETED_DATE] = today
        }
    }
}

suspend fun saveLastDailySummaryJson(json: String) {
    context.dataStore.edit { prefs ->
        prefs[KEY_LAST_DAILY_SUMMARY_JSON] = json
    }
}

suspend fun getLastDailySummaryJson(): String? {
    val prefs = context.dataStore.data.first()
    return prefs[KEY_LAST_DAILY_SUMMARY_JSON]
}

suspend fun isDailySessionDone(today: String): Boolean {
    val prefs = context.dataStore.data.first()
    val date = prefs[KEY_DAILY_SESSION_DATE].orEmpty()
    val done = prefs[KEY_DAILY_SESSION_DONE] ?: 0
    return date == today && done == 1
}

suspend fun resetDailyIfNewDay(today: String) {
    context.dataStore.edit { prefs ->
        // Bootstrap: first unit must be unlocked on first run (Duolingo-like).
        // If the user has no progress yet, current unit index can be 0 (older builds) or missing.
        val curIdx = prefs[KEY_CURRENT_UNIT_GLOBAL_INDEX] ?: 0
        if (curIdx <= 0) {
            prefs[KEY_CURRENT_UNIT_GLOBAL_INDEX] = 1
        }

        val date = prefs[KEY_DAILY_SESSION_DATE].orEmpty()
        if (date != today) {
            prefs[KEY_DAILY_SESSION_DATE] = today
            prefs[KEY_DAILY_SESSION_DONE] = 0
            prefs[KEY_DAILY_XP_TODAY] = 0

            // Reset cached daily question set
            prefs[KEY_DAILY_SESSION_QIDS_DATE] = ""
            prefs[KEY_DAILY_SESSION_QIDS_JSON] = "[]"
        }
    }
}

suspend fun getUnitAttempts(globalIndex: Int): Int {
    val prefs = context.dataStore.data.first()
    val map = decodeIntMap(prefs[KEY_UNIT_ATTEMPTS_JSON].orEmpty())
    return map[globalIndex] ?: 0
}

suspend fun getUnitBestScore(globalIndex: Int): Int {
    val prefs = context.dataStore.data.first()
    val map = decodeIntMap(prefs[KEY_UNIT_BESTSCORE_JSON].orEmpty())
    return map[globalIndex] ?: 0
}

suspend fun getUnitMasteryPercent(globalIndex: Int): Int {
    val prefs = context.dataStore.data.first()
    val map = decodeIntMap(prefs[KEY_UNIT_MASTERY_JSON].orEmpty())
    return (map[globalIndex] ?: 0).coerceIn(0, 100)
}

suspend fun getUnitStars(globalIndex: Int): Int {
    val prefs = context.dataStore.data.first()
    val map = decodeIntMap(prefs[KEY_UNIT_STARS_JSON].orEmpty())
    return (map[globalIndex] ?: 0).coerceIn(0, 3)
}

suspend fun saveUnitResult(
    globalIndex: Int,
    scorePercent: Int,
    masteryPercent: Int,
    stars: Int,
    addAttempt: Boolean = true
) {
    val now = System.currentTimeMillis()
    context.dataStore.edit { prefs ->
        // attempts
        if (addAttempt) {
            val attempts = decodeIntMap(prefs[KEY_UNIT_ATTEMPTS_JSON].orEmpty()).toMutableMap()
            attempts[globalIndex] = (attempts[globalIndex] ?: 0) + 1
            prefs[KEY_UNIT_ATTEMPTS_JSON] = encodeIntMap(attempts)
        }

        // best score
        val best = decodeIntMap(prefs[KEY_UNIT_BESTSCORE_JSON].orEmpty()).toMutableMap()
        val prevBest = best[globalIndex] ?: 0
        if (scorePercent > prevBest) best[globalIndex] = scorePercent
        prefs[KEY_UNIT_BESTSCORE_JSON] = encodeIntMap(best)

        // mastery
        val mastery = decodeIntMap(prefs[KEY_UNIT_MASTERY_JSON].orEmpty()).toMutableMap()
        mastery[globalIndex] = masteryPercent.coerceIn(0, 100)
        prefs[KEY_UNIT_MASTERY_JSON] = encodeIntMap(mastery)

        // stars
        val starsMap = decodeIntMap(prefs[KEY_UNIT_STARS_JSON].orEmpty()).toMutableMap()
        starsMap[globalIndex] = stars.coerceIn(0, 3)
        prefs[KEY_UNIT_STARS_JSON] = encodeIntMap(starsMap)

        // last played
        val last = decodeLongMap(prefs[KEY_UNIT_LASTPLAYED_JSON].orEmpty()).toMutableMap()
        last[globalIndex] = now
        prefs[KEY_UNIT_LASTPLAYED_JSON] = encodeLongMap(last)
    }
}

    // ===== Stage 4.2: Smart selection (Anti-repeat) =====

    suspend fun getUsedQuestionIds(limit: Int = 1000): List<String> {
        val prefs = context.dataStore.data.first()
        val raw = prefs[KEY_USED_QUESTION_IDS_JSON].orEmpty()
        val arr = runCatching { JSONArray(raw) }.getOrElse { JSONArray() }
        val out = ArrayList<String>(arr.length())
        for (i in 0 until arr.length()) {
            val v = arr.optString(i, "")
            if (v.isNotBlank()) out.add(v)
        }
        return if (out.size <= limit) out else out.takeLast(limit)
    }

    suspend fun appendUsedQuestionIds(ids: List<String>, maxSize: Int = 1000) {
        if (ids.isEmpty()) return
        context.dataStore.edit { prefs ->
            val raw = prefs[KEY_USED_QUESTION_IDS_JSON].orEmpty()
            val arr = runCatching { JSONArray(raw) }.getOrElse { JSONArray() }

            // Build a linked set preserving order (avoid duplicates)
            val existing = LinkedHashSet<String>()
            for (i in 0 until arr.length()) {
                val v = arr.optString(i, "")
                if (v.isNotBlank()) existing.add(v)
            }
            ids.forEach { if (it.isNotBlank()) existing.add(it) }

            // Trim to last maxSize
            val trimmed = if (existing.size <= maxSize) existing.toList() else existing.toList().takeLast(maxSize)
            val outArr = JSONArray()
            trimmed.forEach { outArr.put(it) }
            prefs[KEY_USED_QUESTION_IDS_JSON] = outArr.toString()
        }
    }

    // ===== Stage 4.2: Adaptive Learning (tag stats) =====

    data class TagStat(val correct: Int, val total: Int) {
        val accuracy: Float get() = if (total <= 0) 0f else correct.toFloat() / total.toFloat()
    }

    suspend fun getTagStats(): Map<String, TagStat> {
        val prefs = context.dataStore.data.first()
        val raw = prefs[KEY_TAG_STATS_JSON].orEmpty()
        val obj = runCatching { JSONObject(raw) }.getOrElse { JSONObject() }
        val out = mutableMapOf<String, TagStat>()
        val keys = obj.keys()
        while (keys.hasNext()) {
            val tag = keys.next()
            val o = obj.optJSONObject(tag) ?: continue
            out[tag] = TagStat(correct = o.optInt("c", 0), total = o.optInt("t", 0))
        }
        return out
    }

    suspend fun recordTagAttempt(tags: List<String>, correct: Boolean) {
        if (tags.isEmpty()) return
        context.dataStore.edit { prefs ->
            val raw = prefs[KEY_TAG_STATS_JSON].orEmpty()
            val obj = runCatching { JSONObject(raw) }.getOrElse { JSONObject() }
            for (tag in tags) {
                if (tag.isBlank()) continue
                val cur = obj.optJSONObject(tag) ?: JSONObject()
                val c = cur.optInt("c", 0) + if (correct) 1 else 0
                val t = cur.optInt("t", 0) + 1
                cur.put("c", c)
                cur.put("t", t)
                obj.put(tag, cur)
            }
            prefs[KEY_TAG_STATS_JSON] = obj.toString()
        }
    }

    suspend fun getWeakTags(threshold: Float = 0.60f, minTotal: Int = 5): Set<String> {
        val stats = getTagStats()
        return stats.filter { (_, v) -> v.total >= minTotal && v.accuracy < threshold }.keys
    }

    // ===== Daily session question set persistence =====

    suspend fun getDailySessionQuestionIds(today: String): List<String>? {
        val prefs = context.dataStore.data.first()
        val date = prefs[KEY_DAILY_SESSION_QIDS_DATE].orEmpty()
        if (date != today) return null
        val raw = prefs[KEY_DAILY_SESSION_QIDS_JSON].orEmpty()
        val arr = runCatching { JSONArray(raw) }.getOrElse { JSONArray() }
        val out = ArrayList<String>(arr.length())
        for (i in 0 until arr.length()) {
            val v = arr.optString(i, "")
            if (v.isNotBlank()) out.add(v)
        }
        return out
    }

    suspend fun setDailySessionQuestionIds(today: String, ids: List<String>) {
        context.dataStore.edit { prefs ->
            prefs[KEY_DAILY_SESSION_QIDS_DATE] = today
            val arr = JSONArray()
            ids.forEach { if (it.isNotBlank()) arr.put(it) }
            prefs[KEY_DAILY_SESSION_QIDS_JSON] = arr.toString()
        }
    }


// ===== Stage 4.3: Unit lesson step progress + in-progress run accumulators =====

suspend fun getUnitStepIndex(globalIndex: Int): Int {
    val prefs = context.dataStore.data.first()
    val map = decodeIntMap(prefs[KEY_UNIT_STEP_INDEX_JSON].orEmpty())
    return (map[globalIndex] ?: 0).coerceAtLeast(0)
}

suspend fun getUnitStepIndexMap(): Map<Int, Int> {
    val prefs = context.dataStore.data.first()
    return decodeIntMap(prefs[KEY_UNIT_STEP_INDEX_JSON].orEmpty())
}

suspend fun setUnitStepIndex(globalIndex: Int, stepIndex: Int) {
    context.dataStore.edit { prefs ->
        val map = decodeIntMap(prefs[KEY_UNIT_STEP_INDEX_JSON].orEmpty()).toMutableMap()
        map[globalIndex] = stepIndex.coerceAtLeast(0)
        prefs[KEY_UNIT_STEP_INDEX_JSON] = encodeIntMap(map)
    }
}

suspend fun resetUnitRun(globalIndex: Int) {
    context.dataStore.edit { prefs ->
        val c = decodeIntMap(prefs[KEY_UNIT_RUN_CORRECT_JSON].orEmpty()).toMutableMap()
        val t = decodeIntMap(prefs[KEY_UNIT_RUN_TOTAL_JSON].orEmpty()).toMutableMap()
        val ms = decodeLongMap(prefs[KEY_UNIT_RUN_TIME_JSON].orEmpty()).toMutableMap()
        c.remove(globalIndex)
        t.remove(globalIndex)
        ms.remove(globalIndex)
        prefs[KEY_UNIT_RUN_CORRECT_JSON] = encodeIntMap(c)
        prefs[KEY_UNIT_RUN_TOTAL_JSON] = encodeIntMap(t)
        prefs[KEY_UNIT_RUN_TIME_JSON] = encodeLongMap(ms)
    }
}

suspend fun addToUnitRun(globalIndex: Int, correctDelta: Int, totalDelta: Int, timeDeltaMs: Long) {
    context.dataStore.edit { prefs ->
        val c = decodeIntMap(prefs[KEY_UNIT_RUN_CORRECT_JSON].orEmpty()).toMutableMap()
        val t = decodeIntMap(prefs[KEY_UNIT_RUN_TOTAL_JSON].orEmpty()).toMutableMap()
        val ms = decodeLongMap(prefs[KEY_UNIT_RUN_TIME_JSON].orEmpty()).toMutableMap()
        c[globalIndex] = (c[globalIndex] ?: 0) + correctDelta
        t[globalIndex] = (t[globalIndex] ?: 0) + totalDelta
        ms[globalIndex] = (ms[globalIndex] ?: 0L) + timeDeltaMs
        prefs[KEY_UNIT_RUN_CORRECT_JSON] = encodeIntMap(c)
        prefs[KEY_UNIT_RUN_TOTAL_JSON] = encodeIntMap(t)
        prefs[KEY_UNIT_RUN_TIME_JSON] = encodeLongMap(ms)
    }
}

suspend fun getUnitRun(globalIndex: Int): Triple<Int, Int, Long> {
    val prefs = context.dataStore.data.first()
    val c = decodeIntMap(prefs[KEY_UNIT_RUN_CORRECT_JSON].orEmpty())[globalIndex] ?: 0
    val t = decodeIntMap(prefs[KEY_UNIT_RUN_TOTAL_JSON].orEmpty())[globalIndex] ?: 0
    val ms = decodeLongMap(prefs[KEY_UNIT_RUN_TIME_JSON].orEmpty())[globalIndex] ?: 0L
    return Triple(c, t, ms)
}

private fun decodeIntMap(raw: String): Map<Int, Int> {
    if (raw.isBlank()) return emptyMap()
    return try {
        val obj = JSONObject(raw)
        val out = HashMap<Int, Int>(obj.length())
        val it = obj.keys()
        while (it.hasNext()) {
            val k = it.next()
            val id = k.toIntOrNull() ?: continue
            out[id] = obj.optInt(k, 0)
        }
        out
    } catch (_: Throwable) { emptyMap() }
}

private fun encodeIntMap(map: Map<Int, Int>): String {
    return try {
        val obj = JSONObject()
        map.forEach { (k, v) -> obj.put(k.toString(), v) }
        obj.toString()
    } catch (_: Throwable) { "" }
}

private fun decodeLongMap(raw: String): Map<Int, Long> {
    if (raw.isBlank()) return emptyMap()
    return try {
        val obj = JSONObject(raw)
        val out = HashMap<Int, Long>(obj.length())
        val it = obj.keys()
        while (it.hasNext()) {
            val k = it.next()
            val id = k.toIntOrNull() ?: continue
            out[id] = obj.optLong(k, 0L)
        }
        out
    } catch (_: Throwable) { emptyMap() }
}

private fun encodeLongMap(map: Map<Int, Long>): String {
    return try {
        val obj = JSONObject()
        map.forEach { (k, v) -> obj.put(k.toString(), v) }
        obj.toString()
    } catch (_: Throwable) { "" }
}

private fun computeNextStreak(lastCompletedDate: String, today: String, currentStreak: Int): Int {
    return try {
        val t = LocalDate.parse(today)
        val last = if (lastCompletedDate.isBlank()) null else LocalDate.parse(lastCompletedDate)
        when {
            last == null -> 1
            last == t -> currentStreak.coerceAtLeast(1)
            last.plusDays(1) == t -> (currentStreak.coerceAtLeast(0) + 1).coerceAtLeast(1)
            else -> 1
        }
    } catch (_: Throwable) {
        // Conservative fallback
        1
    }
}


// ===== Pro Path: Unit steps + run stats + per-unit metrics =====
private fun parseJsonObjectIntMap(raw: String): Map<Int, Int> {
    val obj = runCatching { JSONObject(raw) }.getOrElse { JSONObject() }
    val out = mutableMapOf<Int, Int>()
    val keys = obj.keys()
    while (keys.hasNext()) {
        val k = keys.next()
        out[k.toIntOrNull() ?: continue] = obj.optInt(k, 0)
    }
    return out
}

private fun toJsonObjectIntMapString(map: Map<Int, Int>): String {
    val obj = JSONObject()
    map.forEach { (k, v) -> obj.put(k.toString(), v) }
    return obj.toString()
}

private fun parseJsonObjectLongMap(raw: String): Map<Int, Long> {
    val obj = runCatching { JSONObject(raw) }.getOrElse { JSONObject() }
    val out = mutableMapOf<Int, Long>()
    val keys = obj.keys()
    while (keys.hasNext()) {
        val k = keys.next()
        out[k.toIntOrNull() ?: continue] = obj.optLong(k, 0L)
    }
    return out
}

private fun toJsonObjectLongMapString(map: Map<Int, Long>): String {
    val obj = JSONObject()
    map.forEach { (k, v) -> obj.put(k.toString(), v) }
    return obj.toString()
}

suspend fun getProUnitStepIndex(globalIndex: Int): Int {
    val json = context.dataStore.data.map { it[KEY_PRO_UNIT_STEP_INDEX_JSON] ?: "{}" }.first()
    val map = parseJsonObjectIntMap(json)
    return map[globalIndex] ?: 0
}

suspend fun getProUnitStepIndexMap(): Map<Int, Int> {
    val json = context.dataStore.data.map { it[KEY_PRO_UNIT_STEP_INDEX_JSON] ?: "{}" }.first()
    return parseJsonObjectIntMap(json)
}

suspend fun setProUnitStepIndex(globalIndex: Int, stepIndex: Int) {
    context.dataStore.edit { prefs ->
        val raw = prefs[KEY_PRO_UNIT_STEP_INDEX_JSON] ?: "{}"
        val map = parseJsonObjectIntMap(raw).toMutableMap()
        map[globalIndex] = stepIndex
        prefs[KEY_PRO_UNIT_STEP_INDEX_JSON] = toJsonObjectIntMapString(map)
    }
}

suspend fun resetProUnitRun(globalIndex: Int) {
    context.dataStore.edit { prefs ->
        fun resetInt(key: androidx.datastore.preferences.core.Preferences.Key<String>) {
            val raw = prefs[key] ?: "{}"
            val map = parseJsonObjectIntMap(raw).toMutableMap()
            map.remove(globalIndex)
            prefs[key] = toJsonObjectIntMapString(map)
        }
        fun resetLong(key: androidx.datastore.preferences.core.Preferences.Key<String>) {
            val raw = prefs[key] ?: "{}"
            val map = parseJsonObjectLongMap(raw).toMutableMap()
            map.remove(globalIndex)
            prefs[key] = toJsonObjectLongMapString(map)
        }
        resetInt(KEY_PRO_UNIT_RUN_CORRECT_JSON)
        resetInt(KEY_PRO_UNIT_RUN_TOTAL_JSON)
        resetLong(KEY_PRO_UNIT_RUN_TIME_JSON)

        // remove run plan
        val rawPlan = prefs[KEY_PRO_UNIT_RUN_PLAN_JSON] ?: "{}"
        val planMap = parseJsonObjectStringMap(rawPlan).toMutableMap()
        planMap.remove(globalIndex)
        prefs[KEY_PRO_UNIT_RUN_PLAN_JSON] = toJsonObjectStringMapString(planMap)
    }
}

private fun parseJsonObjectStringMap(raw: String): Map<Int, String> {
    val obj = runCatching { JSONObject(raw) }.getOrElse { JSONObject() }
    val out = mutableMapOf<Int, String>()
    val keys = obj.keys()
    while (keys.hasNext()) {
        val k = keys.next()
        val gi = k.toIntOrNull() ?: continue
        out[gi] = obj.optString(k, "")
    }
    return out
}

private fun toJsonObjectStringMapString(map: Map<Int, String>): String {
    val obj = JSONObject()
    map.forEach { (k, v) -> obj.put(k.toString(), v) }
    return obj.toString()
}

suspend fun getProUnitRunPlanJson(globalIndex: Int): String? {
    val prefs = context.dataStore.data.first()
    val raw = prefs[KEY_PRO_UNIT_RUN_PLAN_JSON] ?: "{}"
    val map = parseJsonObjectStringMap(raw)
    return map[globalIndex]?.takeIf { it.isNotBlank() }
}

suspend fun setProUnitRunPlanJson(globalIndex: Int, planJsonArrayString: String) {
    context.dataStore.edit { prefs ->
        val raw = prefs[KEY_PRO_UNIT_RUN_PLAN_JSON] ?: "{}"
        val map = parseJsonObjectStringMap(raw).toMutableMap()
        map[globalIndex] = planJsonArrayString
        prefs[KEY_PRO_UNIT_RUN_PLAN_JSON] = toJsonObjectStringMapString(map)
    }
}

suspend fun addToProUnitRun(globalIndex: Int, correctDelta: Int, totalDelta: Int, timeDeltaMs: Long) {
    context.dataStore.edit { prefs ->
        fun bumpInt(key: androidx.datastore.preferences.core.Preferences.Key<String>, delta: Int) {
            val raw = prefs[key] ?: "{}"
            val map = parseJsonObjectIntMap(raw).toMutableMap()
            map[globalIndex] = (map[globalIndex] ?: 0) + delta
            prefs[key] = toJsonObjectIntMapString(map)
        }
        fun bumpLong(key: androidx.datastore.preferences.core.Preferences.Key<String>, delta: Long) {
            val raw = prefs[key] ?: "{}"
            val map = parseJsonObjectLongMap(raw).toMutableMap()
            map[globalIndex] = (map[globalIndex] ?: 0L) + delta
            prefs[key] = toJsonObjectLongMapString(map)
        }
        bumpInt(KEY_PRO_UNIT_RUN_CORRECT_JSON, correctDelta)
        bumpInt(KEY_PRO_UNIT_RUN_TOTAL_JSON, totalDelta)
        bumpLong(KEY_PRO_UNIT_RUN_TIME_JSON, timeDeltaMs)
    }
}

suspend fun getProUnitRun(globalIndex: Int): Triple<Int, Int, Long> {
    val prefs = context.dataStore.data.first()
    val correct = parseJsonObjectIntMap(prefs[KEY_PRO_UNIT_RUN_CORRECT_JSON] ?: "{}")[globalIndex] ?: 0
    val total = parseJsonObjectIntMap(prefs[KEY_PRO_UNIT_RUN_TOTAL_JSON] ?: "{}")[globalIndex] ?: 0
    val time = parseJsonObjectLongMap(prefs[KEY_PRO_UNIT_RUN_TIME_JSON] ?: "{}")[globalIndex] ?: 0L
    return Triple(correct, total, time)
}

private suspend fun updateProMetric(key: androidx.datastore.preferences.core.Preferences.Key<String>, globalIndex: Int, value: Int) {
    context.dataStore.edit { prefs ->
        val raw = prefs[key] ?: "{}"
        val map = parseJsonObjectIntMap(raw).toMutableMap()
        map[globalIndex] = value
        prefs[key] = toJsonObjectIntMapString(map)
    }
}

suspend fun saveProUnitResult(globalIndex: Int, scorePercent: Int, masteryPercent: Int, stars: Int, lastPlayedAtMs: Long) {
    // attempts++
    context.dataStore.edit { prefs ->
        val attemptsRaw = prefs[KEY_PRO_UNIT_ATTEMPTS_JSON] ?: "{}"
        val attempts = parseJsonObjectIntMap(attemptsRaw).toMutableMap()
        attempts[globalIndex] = (attempts[globalIndex] ?: 0) + 1
        prefs[KEY_PRO_UNIT_ATTEMPTS_JSON] = toJsonObjectIntMapString(attempts)
    }
    updateProMetric(KEY_PRO_UNIT_BESTSCORE_JSON, globalIndex, scorePercent.coerceIn(0, 100))
    updateProMetric(KEY_PRO_UNIT_MASTERY_JSON, globalIndex, masteryPercent.coerceIn(0, 100))
    updateProMetric(KEY_PRO_UNIT_STARS_JSON, globalIndex, stars.coerceIn(0, 3))
    context.dataStore.edit { prefs ->
        val raw = prefs[KEY_PRO_UNIT_LASTPLAYED_JSON] ?: "{}"
        val map = parseJsonObjectLongMap(raw).toMutableMap()
        map[globalIndex] = lastPlayedAtMs
        prefs[KEY_PRO_UNIT_LASTPLAYED_JSON] = toJsonObjectLongMapString(map)
    }
}

}