package com.emir.englishapp.ui.screens.lessons.level

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.emir.englishapp.data.repository.AppRepository
import com.emir.englishapp.domain.model.lesson.UnitBlock
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

data class LevelUiState(
    val isLoading: Boolean = true,
    val titleAr: String = "",
    val units: List<UnitBlock> = emptyList(),
    val completed: Set<String> = emptySet(),
    val unlockedIndex: Int = 0,
    val favoriteLessonKeys: Set<String> = emptySet(),
    val lessonStepIndex: Map<String, Int> = emptyMap(),
    val error: String? = null
)

class LevelViewModel(
    private val repo: AppRepository,
    val levelId: Int
) : ViewModel() {

    private val _uiState = MutableStateFlow(LevelUiState())
    val uiState: StateFlow<LevelUiState> = _uiState.asStateFlow()

    fun load() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, error = null)
            runCatching {
                val level = repo.getLessonLevel(levelId)
                val completed = repo.getCompletedLessonIds(levelId)
                val unlocked = repo.getUnlockedLessonIndex(levelId)
                val fav = repo.favoriteLessonIds.first()
                run {
                val stepMap = mutableMapOf<String, Int>()
                if (level != null) {
                    for (unit in level.units) {
                        for (lesson in unit.lessons) {
                            val key = "$levelId|${lesson.lessonId}"
                            stepMap[key] = repo.getLessonStepIndex(key)
                        }
                    }
                }
                Quint(level, completed, unlocked, fav, stepMap)
            }
            }.onSuccess { (level, completed, unlocked, fav, stepMap) ->
                if (level == null) {
                    _uiState.value = LevelUiState(isLoading = false, error = "لم يتم العثور على المستوى")
                    return@onSuccess
                }
                _uiState.value = LevelUiState(
                    isLoading = false,
                    titleAr = level.titleAr,
                    units = level.units,
                    completed = completed,
                    unlockedIndex = unlocked,
                    favoriteLessonKeys = fav,
                    lessonStepIndex = stepMap
                )
            }.onFailure { e ->
                _uiState.value = LevelUiState(isLoading = false, error = e.message ?: "خطأ غير معروف")
            }
        }
    }

    init {
        load()
    }

    fun toggleFavoriteLesson(lessonId: String) {
        val key = "$levelId|$lessonId"
        viewModelScope.launch {
            repo.toggleFavoriteLesson(key)
            // refresh favorites in state
            val fav = repo.favoriteLessonIds.first()
            _uiState.value = _uiState.value.copy(favoriteLessonKeys = fav)}
    }
}

private data class Quint<A, B, C, D, E>(
    val first: A,
    val second: B,
    val third: C,
    val fourth: D,
    val fifth: E
)
