package com.emir.englishapp.ui.screens.phrases.quiz

import android.media.AudioManager
import android.media.ToneGenerator
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.dp
import com.emir.englishapp.ui.widgets.character.CharacterMood
import com.emir.englishapp.ui.widgets.character.LearningCharacterBanner
import kotlinx.coroutines.delay
import kotlin.random.Random

@Composable
fun ListeningQuizScreen(
    state: ListeningQuizUiState,
    onBack: () -> Unit,
    onPlay: () -> Unit,
    onSelectAnswer: (Int) -> Unit,
    onNext: () -> Unit,
    onRestart: () -> Unit
) {
    Box(modifier = Modifier.fillMaxSize()) {

        // ===== Confetti at finish =====
        var showConfetti by remember(state.isFinished) { mutableStateOf(state.isFinished) }
        LaunchedEffect(state.isFinished) {
            if (state.isFinished) {
                showConfetti = true
                delay(1500)
                showConfetti = false
            }
        }

        if (showConfetti) {
            ConfettiBurst(modifier = Modifier.fillMaxSize())
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(onClick = onBack, modifier = Modifier.weight(1f)) { Text("رجوع") }
                Text(
                    "🎧 Listening Quiz",
                    style = MaterialTheme.typography.titleLarge,
                    modifier = Modifier.weight(2f)
                )
            }

            LearningCharacterBanner(
                mood = when {
                    state.isLoading -> CharacterMood.THINKING
                    state.errorMessage != null -> CharacterMood.WARNING
                    state.isFinished -> CharacterMood.LEVEL_UP
                    state.selectedOptionId == null -> CharacterMood.IDLE
                    state.isCorrect == true -> CharacterMood.HAPPY
                    else -> CharacterMood.ENCOURAGE
                },
                message = when {
                    state.isLoading -> "أجهّز الصوت..."
                    state.errorMessage != null -> "في مشكلة بالتحميل. جرّب مرة ثانية"
                    state.isFinished -> "ممتاز! خلصنا اختبار الاستماع ✅"
                    state.selectedOptionId == null -> "اضغط تشغيل ثم اختر الإجابة"
                    state.isCorrect == true -> "إجابة صحيحة 👏"
                    else -> "قريب جدًا—اسمع مرة ثانية"
                }
            )

            if (state.isLoading) {
                Text("تحميل...", style = MaterialTheme.typography.bodyMedium)
                return
            }

            state.errorMessage?.let {
                Text(it, style = MaterialTheme.typography.bodyMedium)
                return
            }// ===== Progress =====
            val total = state.totalQuestions.coerceAtLeast(1)
            val idx = state.currentIndex.coerceIn(1, total)
            Text("السؤال $idx / $total", style = MaterialTheme.typography.titleMedium)
            LinearProgressIndicator(
                progress = idx / total.toFloat(),
                modifier = Modifier.fillMaxWidth()
            )

            // ===== Finished =====
            if (state.isFinished) {
                Spacer(Modifier.height(8.dp))
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text("🎉 أحسنت!", style = MaterialTheme.typography.titleLarge)
                        Text(
                            "نتيجتك: ${state.correctCount} / $total",
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            "XP المكتسبة: ${state.xpEarned}",
                            style = MaterialTheme.typography.titleMedium
                        )
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Button(
                                onClick = onRestart,
                                modifier = Modifier.weight(1f)
                            ) { Text("إعادة الاختبار") }
                            OutlinedButton(onClick = onBack, modifier = Modifier.weight(1f)) {
                                Text(
                                    "رجوع"
                                )
                            }
                        }
                    }
                }
                return
            }

            // ===== Play audio =====
            Button(onClick = onPlay, modifier = Modifier.fillMaxWidth()) {
                Text("▶ تشغيل الصوت (EN)")
            }

            // ===== One-time haptics + system tones per question =====
            val haptic = LocalHapticFeedback.current
            var lastHandledSelection by remember(state.questionId) { mutableStateOf<Int?>(null) }

            LaunchedEffect(state.selectedOptionId) {
                val sel = state.selectedOptionId ?: return@LaunchedEffect
                if (lastHandledSelection == sel) return@LaunchedEffect
                lastHandledSelection = sel

                val ok = state.isCorrect == true

                haptic.performHapticFeedback(
                    if (ok) HapticFeedbackType.LongPress else HapticFeedbackType.TextHandleMove
                )

                try {
                    val tg = ToneGenerator(AudioManager.STREAM_MUSIC, 80)
                    tg.startTone(
                        if (ok) ToneGenerator.TONE_PROP_ACK else ToneGenerator.TONE_PROP_NACK,
                        160
                    )
                    tg.release()
                } catch (_: Throwable) {
                }
            }

            // ===== Answered state =====
            // Auto-next is disabled (user moves manually via "التالي").
            val answered = state.selectedOptionId != null

            // ===== Animated feedback banner =====
            AnimatedVisibility(
                visible = !state.feedbackMessage.isNullOrBlank(),
                enter = fadeIn() + slideInVertically(initialOffsetY = { it / 2 }),
                exit = fadeOut() + slideOutVertically(targetOffsetY = { it / 2 })
            ) {
                val ok = state.isCorrect == true
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (ok) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.errorContainer
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = state.feedbackMessage.orEmpty(),
                        modifier = Modifier.padding(14.dp),
                        style = MaterialTheme.typography.titleMedium,
                        color = if (ok) MaterialTheme.colorScheme.onPrimaryContainer
                        else MaterialTheme.colorScheme.onErrorContainer
                    )
                }
            }

            Spacer(Modifier.height(4.dp))

            // ===== Answer buttons coloring =====
            val correctId = state.correctOptionId
            val success = Color(0xFF2E7D32) // أخضر
            val error = Color(0xFFC62828)   // أحمر

            state.options.forEach { option ->
                val selectedId = state.selectedOptionId
                val isSelected = selectedId == option.id
                val isCorrectOption = (correctId != null && option.id == correctId)

                val showResult = answered && correctId != null
                val showCorrect = showResult && isCorrectOption
                val showWrongSelected = showResult && isSelected && !isCorrectOption

                // لون الخلفية والنص
                val containerColor = when {
                    !showResult -> MaterialTheme.colorScheme.surface
                    showCorrect -> success
                    showWrongSelected -> error
                    else -> MaterialTheme.colorScheme.surface
                }

                val contentColor = when {
                    !showResult -> MaterialTheme.colorScheme.onSurface
                    showCorrect -> Color.White
                    showWrongSelected -> Color.White
                    else -> MaterialTheme.colorScheme.onSurface
                }

                // لون الحدود
                val borderColor = when {
                    !showResult -> MaterialTheme.colorScheme.outline
                    showCorrect -> success
                    showWrongSelected -> error
                    else -> MaterialTheme.colorScheme.outlineVariant
                }

                val shouldBounce = showCorrect
                val bounceScale by animateFloatAsState(
                    targetValue = if (shouldBounce) 1.035f else 1f,
                    animationSpec = spring(
                        dampingRatio = Spring.DampingRatioMediumBouncy,
                        stiffness = Spring.StiffnessLow
                    ),
                    label = "bounce"
                )

                Button(
                    onClick = { onSelectAnswer(option.id) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .scale(bounceScale),
                    enabled = !answered,
                    shape = RoundedCornerShape(24.dp),
                    border = BorderStroke(1.dp, borderColor),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = containerColor,
                        contentColor = contentColor
                    )
                ) {
                    Text(option.arText)
                }
            }

            // زر التالي (اختياري — سيبقى موجود لكن غالبًا لن تحتاجه لأن الانتقال تلقائي)
            Button(
                onClick = onNext,
                modifier = Modifier.fillMaxWidth(),
                enabled = state.canGoNext
            ) {
                Text("التالي")
            }
        }
    }
}

@Composable
private fun ConfettiBurst(modifier: Modifier = Modifier) {
    val scheme = MaterialTheme.colorScheme

    val palette = remember(scheme) {
        listOf(
            scheme.primary,
            scheme.secondary,
            scheme.tertiary,
            scheme.error,
            scheme.primaryContainer
        )
    }
    val particles = remember {
        List(90) {
            Particle(
                x = Random.nextFloat(),
                yStart = Random.nextFloat() * 0.25f,
                size = 3f + Random.nextFloat() * 6f,
                speed = 0.9f + Random.nextFloat() * 0.9f,
                drift = (-0.25f + Random.nextFloat() * 0.5f)
            )
        }
    }

    val progress = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        progress.snapTo(0f)
        progress.animateTo(1f, animationSpec = tween(900))
    }

    Canvas(modifier = modifier) {
        val p = progress.value

        particles.forEachIndexed { i, pt ->
            val x = (pt.x + pt.drift * p) * size.width
            val y = (pt.yStart + pt.speed * p) * size.height
            val alpha = (1f - p).coerceIn(0f, 1f)

            val c = palette[i % palette.size].copy(alpha = 0.85f * alpha)

            drawCircle(
                color = c,
                radius = pt.size,
                center = Offset(x, y)
            )
        }
    }
}

private data class Particle(
    val x: Float,
    val yStart: Float,
    val size: Float,
    val speed: Float,
    val drift: Float
)