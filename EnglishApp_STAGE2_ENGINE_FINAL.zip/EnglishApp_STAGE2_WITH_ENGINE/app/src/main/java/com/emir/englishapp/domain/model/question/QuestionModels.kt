package com.emir.englishapp.domain.model.question

/** Mirrors `questions_3100_smart.json` root: { meta, questions: [...] } */

data class QuestionsMeta(
    val version: String,
    val notes: String
)

data class QuestionsFile(
    val meta: QuestionsMeta,
    val questions: List<Question>
)

data class Question(
    val id: String,
    val type: String,
    val difficultyScore: Int,
    val tags: List<String>,
    val cefr: String,

    // Some questions are EN -> AR, others are AR -> EN.
    // We keep both and let the UI pick the available one.
    val promptEn: String,
    val promptAr: String? = null,

    val optionsAr: List<String>,
    val optionsEn: List<String>? = null,

    val answerIndex: Int,
    val answerAr: String,
    val answerEn: String? = null,

    val explanationAr: String,

    // Optional fields present in dataset
    val skill: String? = null,
    val difficulty: String? = null
)
