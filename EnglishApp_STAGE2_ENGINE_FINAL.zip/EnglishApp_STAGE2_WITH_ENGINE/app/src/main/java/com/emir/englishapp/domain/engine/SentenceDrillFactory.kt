package com.emir.englishapp.domain.engine

import com.emir.englishapp.domain.model.exercise.AnswerLanguage
import com.emir.englishapp.domain.model.exercise.ExerciseTemplate
import com.emir.englishapp.domain.model.exercise.LearningModality
import com.emir.englishapp.domain.model.exercise.SortCategory
import com.emir.englishapp.domain.model.exercise.SortWord
import com.emir.englishapp.domain.model.exercise.WordPair
import com.emir.englishapp.domain.model.exercise.WordTimestamp

/**
 * SentenceDrillFactory
 * =====================
 * Generates ALL exercise variants from a single [AnnotatedSentence].
 *
 * Input:  1 sentence (EN + AR + per-word audio timestamps)
 * Output: up to 42 unique exercises from 10 exercise types
 *
 * Types generated per sentence:
 *   1.  TranslateEnToAr           — sentence MCQ             (1)
 *   2.  TranslateArToEn           — sentence MCQ             (1)
 *   3.  SentenceReorder           — arrange all words        (1)
 *   4.  FillBlank × content words — blank at each key word   (N ≈ 4)
 *   5.  FillBlank (hard)          — same but no AR hint      (N ≈ 4)
 *   6.  SpotTheError × 2 targets  — swap two different words (2)
 *   7.  SentenceComplete × 2 cuts — split at 30% and 60%     (2)
 *   8.  ListenAndPick             — full sentence audio→AR   (1)
 *   9.  DictationReorder          — hear→arrange words       (1)
 *   10. TypeWhatYouHear × words   — isolate each word        (W ≈ 6)
 *   11. TypeWhatYouHear (ctx)     — with sentence context    (W ≈ 6)
 *   12. LetterReorder × words     — hear word→arrange letters(W ≈ 6)
 *
 * Total per sentence: 1+1+1+4+4+2+2+1+1+6+6+6 = ~35–42 exercises
 * For 5 sentences: 175–210 → exceeds 200 ✅
 */
class SentenceDrillFactory(private val rng: SeededRng) {

    // ─────────────────────────────────────────────────────────────
    // Input model
    // ─────────────────────────────────────────────────────────────

    data class AnnotatedSentence(
        val id: String,
        val en: String,
        val ar: String,
        val cefr: String = "A1",
        val topic: String = "general",
        val complexityScore: Float = 0f,
        /** Per-word audio timestamps from TTS word-boundary events. */
        val wordTimestamps: List<WordTimestamp> = emptyList(),
        /** Full-sentence audio asset path. */
        val audioAssetPath: String? = null,
    ) {
        val words: List<String> get() = en.trim().split(Regex("\\s+"))
        val wordCount: Int get() = words.size

        /** Words with their individual audio clips derived from [wordTimestamps]. */
        val wordAudioClips: List<WordAudioClip>
            get() = wordTimestamps.map { ts ->
                WordAudioClip(
                    word = ts.word,
                    startMs = ts.startMs,
                    endMs = ts.endMs,
                    fullSentenceAssetPath = audioAssetPath,
                )
            }
    }

    /**
     * A single word's audio window within the full-sentence audio file.
     * The player seeks to [startMs] and stops at [endMs].
     */
    data class WordAudioClip(
        val word: String,
        val startMs: Long,
        val endMs: Long,
        /** The parent audio file; player trims to startMs..endMs. */
        val fullSentenceAssetPath: String?,
    ) {
        /** Encoded as "path|startMs|endMs" for asset routing. */
        val encodedPath: String?
            get() = fullSentenceAssetPath?.let { "$it|$startMs|$endMs" }
    }

    // ─────────────────────────────────────────────────────────────
    // Primary API
    // ─────────────────────────────────────────────────────────────

    /**
     * Generate every possible exercise from [sentence].
     * Pass a [distractorPool] of other sentences for MCQ option generation.
     */
    fun generateAll(
        sentence: AnnotatedSentence,
        distractorPool: List<AnnotatedSentence>,
    ): List<ExerciseTemplate> {
        val result = mutableListOf<ExerciseTemplate>()
        var n = 0
        fun id(type: String) = "drill_${sentence.id}_${type}_${++n}"

        val words = sentence.words
        val hasAudio = sentence.audioAssetPath != null
        val difficulty = cefrScore(sentence.cefr) + (sentence.complexityScore * 20).toInt()

        // ── 1. TranslateEnToAr ──────────────────────────────────
        result += makeTranslateEnToAr(id("t_en_ar"), sentence, distractorPool, difficulty)

        // ── 2. TranslateArToEn ──────────────────────────────────
        result += makeTranslateArToEn(id("t_ar_en"), sentence, distractorPool, difficulty)

        // ── 3. SentenceReorder ──────────────────────────────────
        if (words.size in 3..10) {
            result += makeSentenceReorder(id("reorder"), sentence, difficulty)
        }

        // ── 4+5. FillBlank (easy with hint + hard without) ──────
        val contentIndices = contentWordIndices(words)
        contentIndices.forEach { blankIdx ->
            result += makeFillBlank(id("fb_easy_$blankIdx"), sentence, blankIdx, distractorPool, difficulty, showArHint = true)
            result += makeFillBlank(id("fb_hard_$blankIdx"), sentence, blankIdx, distractorPool, difficulty, showArHint = false)
        }

        // ── 6. SpotTheError (2 different error positions) ────────
        if (words.size >= 4) {
            contentIndices.take(2).forEach { errIdx ->
                makeSpotTheError(id("ste_$errIdx"), sentence, errIdx, distractorPool, difficulty)
                    ?.let { result += it }
            }
        }

        // ── 7. SentenceComplete (30% and 60% split) ──────────────
        if (words.size >= 5) {
            listOf(0.30f, 0.60f).forEach { ratio ->
                makeSentenceComplete(id("sc_${ratio.toInt()}"), sentence, ratio, distractorPool, difficulty)
                    ?.let { result += it }
            }
        }

        // ── 8. ListenAndPick ─────────────────────────────────────
        if (hasAudio) {
            result += makeListenAndPick(id("lap"), sentence, distractorPool, difficulty)
        }

        // ── 9. DictationReorder ──────────────────────────────────
        if (hasAudio && words.size in 3..9) {
            result += makeDictationReorder(id("dictr"), sentence, difficulty)
        }

        // ── 10+11. TypeWhatYouHear (isolated + in-context) ───────
        sentence.wordTimestamps.forEach { ts ->
            if (ts.word.length >= 3 && ts.word.lowercase() !in FUNCTION_WORDS) {
                // 10. Isolated word (just the word audio clip)
                result += makeTypeWhatYouHear(
                    id("twh_iso_${ts.word}"),
                    word = ts.word,
                    clip = WordAudioClip(ts.word, ts.startMs, ts.endMs, sentence.audioAssetPath),
                    contextSentence = null,
                    distractorPool = distractorPool,
                    cefr = sentence.cefr,
                    topic = sentence.topic,
                    difficulty = difficulty,
                )
                // 11. In-context (word in sentence, sentence shown dimmed)
                result += makeTypeWhatYouHear(
                    id("twh_ctx_${ts.word}"),
                    word = ts.word,
                    clip = WordAudioClip(ts.word, ts.startMs, ts.endMs, sentence.audioAssetPath),
                    contextSentence = sentence.en,
                    distractorPool = distractorPool,
                    cefr = sentence.cefr,
                    topic = sentence.topic,
                    difficulty = difficulty + 5,
                )
            }
        }

        // ── 12. LetterReorder (hear word → arrange its letters) ──
        sentence.wordTimestamps.forEach { ts ->
            val w = ts.word.lowercase().filter { it.isLetter() }
            if (w.length in 3..10 && ts.word.lowercase() !in FUNCTION_WORDS) {
                result += makeLetterReorder(
                    id("lr_${ts.word}"),
                    word = ts.word,
                    clip = WordAudioClip(ts.word, ts.startMs, ts.endMs, sentence.audioAssetPath),
                    cefr = sentence.cefr,
                    topic = sentence.topic,
                    difficulty = difficulty + 8,
                )
            }
        }

        return result
    }

    // ─────────────────────────────────────────────────────────────
    // Cross-sentence exercises (MatchPairs, WordSort)
    // ─────────────────────────────────────────────────────────────

    /**
     * Build MatchPairs exercises from a group of sentences.
     * Groups [sentences] into chunks of [pairCount] and creates one exercise per chunk.
     */
    fun generateMatchPairsGroups(
        sentences: List<AnnotatedSentence>,
        pairCount: Int = 4,
    ): List<ExerciseTemplate.MatchPairs> {
        return sentences.chunked(pairCount).mapIndexed { idx, chunk ->
            ExerciseTemplate.MatchPairs(
                id = "mp_group_$idx",
                cefr = chunk.first().cefr,
                difficultyScore = cefrScore(chunk.first().cefr) + idx * 3,
                topic = chunk.first().topic,
                pairs = chunk.map { WordPair(en = it.en, ar = it.ar) },
                explanationAr = "طابق الجمل الإنجليزية بمعانيها العربية",
            )
        }
    }

    /**
     * Generate WordSort exercises using all words from [sentences].
     * Produces [configCount] different category configurations.
     */
    fun generateWordSortConfigs(
        sentences: List<AnnotatedSentence>,
        configCount: Int = 3,
    ): List<ExerciseTemplate.WordSort> {
        val allWords = sentences.flatMap { s ->
            s.words
                .filter { it.lowercase() !in FUNCTION_WORDS && it.length >= 3 }
                .map { it.lowercase().trimEnd('.', ',', '?', '!') }
        }.distinct()

        val configs = listOf(
            Triple("Verbs / أفعال", "Nouns / أسماء",
                setOf("go","eat","work","play","learn","like","study","run","walk","see","come","take","make")),
            Triple("People / أشخاص", "Places / أماكن",
                setOf("i","he","she","we","they","you","girl","boy","man","woman","teacher","student")),
            Triple("Actions / أفعال", "Descriptions / صفات",
                setOf("go","run","eat","drink","play","work","study","walk","talk","read","write")),
        )

        return configs.take(configCount).mapIndexed { idx, (labelAEn, labelBEn, verbSet) ->
            val pool = rng.pickN(allWords, minOf(8, allWords.size))
            ExerciseTemplate.WordSort(
                id = "ws_config_$idx",
                cefr = sentences.first().cefr,
                difficultyScore = cefrScore(sentences.first().cefr) + 10 + idx * 3,
                topic = sentences.first().topic,
                categoryA = SortCategory(labelEn = labelAEn.substringBefore(" /"), labelAr = labelAEn.substringAfter("/ ")),
                categoryB = SortCategory(labelEn = labelBEn.substringBefore(" /"), labelAr = labelBEn.substringAfter("/ ")),
                wordPool = pool.map { w ->
                    SortWord(text = w, correctCategory = if (w.lowercase() in verbSet) 0 else 1)
                },
            )
        }
    }

    // ─────────────────────────────────────────────────────────────
    // Private exercise builders
    // ─────────────────────────────────────────────────────────────

    private fun makeTranslateEnToAr(
        id: String, s: AnnotatedSentence, pool: List<AnnotatedSentence>, diff: Int,
    ) = ExerciseTemplate.TranslateEnToAr(
        id = id, cefr = s.cefr, difficultyScore = diff, topic = s.topic,
        promptAr = "ما معنى هذه الجملة بالإنجليزية؟",
        optionsEn = buildOptions(s.en, pool.map { it.en }, rng),
        answerIndex = 0, // buildOptions puts correct first then shuffles
        explanationAr = "الإجابة: ${s.en}",
    ).let { ex ->
        // Re-derive answerIndex after shuffle
        val opts = buildShuffled(s.en, pool.map { it.en }, rng, 4)
        ex.copy(optionsEn = opts.list, answerIndex = opts.correctIndex)
    }

    private fun makeTranslateArToEn(
        id: String, s: AnnotatedSentence, pool: List<AnnotatedSentence>, diff: Int,
    ): ExerciseTemplate.TranslateEnToAr {
        val opts = buildShuffled(s.en, pool.map { it.en }, rng, 4)
        return ExerciseTemplate.TranslateEnToAr(
            id = id, cefr = s.cefr, difficultyScore = diff + 3, topic = s.topic,
            promptAr = s.ar,
            optionsEn = opts.list,
            answerIndex = opts.correctIndex,
            explanationAr = "الترجمة الصحيحة: ${s.en}",
        )
    }

    private fun makeSentenceReorder(id: String, s: AnnotatedSentence, diff: Int) =
        ExerciseTemplate.SentenceReorder(
            id = id, cefr = s.cefr, difficultyScore = diff + s.wordCount * 2, topic = s.topic,
            promptAr = s.ar,
            shuffledWords = rng.shuffle(s.words.toMutableList()),
            correctOrder = s.words,
            audioAssetPath = s.audioAssetPath,
            explanationAr = "الترتيب الصحيح: ${s.en}",
        )

    private fun makeFillBlank(
        id: String, s: AnnotatedSentence, blankIdx: Int,
        pool: List<AnnotatedSentence>, diff: Int, showArHint: Boolean,
    ): ExerciseTemplate.FillBlank {
        val words = s.words
        val correctWord = words[blankIdx]
        val sentence = words.mapIndexed { i, w -> if (i == blankIdx) "___" else w }.joinToString(" ")
        val distractors = pool
            .flatMap { it.words }
            .filter { it.lowercase() !in FUNCTION_WORDS && it.lowercase() != correctWord.lowercase() && it.length >= 3 }
            .distinct()
            .shuffled()
            .take(3)
            .ifEmpty { listOf("apple", "school", "happy") }
        val opts = buildShuffled(correctWord, distractors, rng, 4)
        return ExerciseTemplate.FillBlank(
            id = id, cefr = s.cefr, difficultyScore = diff + if (showArHint) 0 else 8, topic = s.topic,
            sentenceWithPlaceholder = sentence,
            optionsEn = opts.list,
            answerIndex = opts.correctIndex,
            arHint = if (showArHint) s.ar else null,
            explanationAr = "الكلمة الصحيحة: $correctWord",
        )
    }

    private fun makeSpotTheError(
        id: String, s: AnnotatedSentence, errorIdx: Int,
        pool: List<AnnotatedSentence>, diff: Int,
    ): ExerciseTemplate.SpotTheError? {
        val words = s.words
        val originalWord = words[errorIdx]
        val wrongWord = pool
            .flatMap { it.words }
            .firstOrNull { it.lowercase() !in FUNCTION_WORDS && it.lowercase() != originalWord.lowercase() && it.length >= 3 }
            ?: return null
        val tokensWithError = words.toMutableList().also { it[errorIdx] = wrongWord }
        return ExerciseTemplate.SpotTheError(
            id = id, cefr = s.cefr, difficultyScore = diff + 15, topic = s.topic,
            sentenceTokens = tokensWithError,
            errorIndex = errorIdx,
            correctedWord = originalWord,
            arHint = s.ar,
            explanationAr = "الكلمة الخاطئة '${wrongWord}' → الصحيحة: '$originalWord'",
        )
    }

    private fun makeSentenceComplete(
        id: String, s: AnnotatedSentence, splitRatio: Float,
        pool: List<AnnotatedSentence>, diff: Int,
    ): ExerciseTemplate.SentenceComplete? {
        val words = s.words
        if (words.size < 4) return null
        val splitAt = (words.size * splitRatio).toInt().coerceIn(2, words.size - 1)
        val prefix = words.take(splitAt).joinToString(" ") + " ___"
        val correct = words.drop(splitAt).joinToString(" ")
        val distractors = pool
            .filter { it.id != s.id && it.wordCount >= 3 }
            .map { p -> p.words.drop((p.wordCount * splitRatio).toInt().coerceIn(1, p.wordCount - 1)).joinToString(" ") }
            .filter { it.isNotBlank() && it != correct }
            .distinct()
            .take(3)
            .ifEmpty { listOf("in the park", "to school today", "very quickly now") }
        val opts = buildShuffled(correct, distractors, rng, 4)
        return ExerciseTemplate.SentenceComplete(
            id = id, cefr = s.cefr, difficultyScore = diff + 10, topic = s.topic,
            sentencePrefix = prefix,
            optionsEn = opts.list,
            answerIndex = opts.correctIndex,
            arHint = s.ar,
            explanationAr = "إكمال الجملة: $correct",
        )
    }

    private fun makeListenAndPick(
        id: String, s: AnnotatedSentence, pool: List<AnnotatedSentence>, diff: Int,
    ): ExerciseTemplate.ListenAndPick {
        val opts = buildShuffled(s.ar, pool.filter { it.id != s.id }.map { it.ar }, rng, 4)
        return ExerciseTemplate.ListenAndPick(
            id = id, cefr = s.cefr, difficultyScore = diff + 8, topic = s.topic,
            audioAssetPath = s.audioAssetPath,
            correctText = s.en,
            targetLanguage = AnswerLanguage.ARABIC,
            options = opts.list,
            answerIndex = opts.correctIndex,
            wordTimestamps = s.wordTimestamps,
            explanationAr = "المعنى: ${s.ar}",
        )
    }

    private fun makeDictationReorder(id: String, s: AnnotatedSentence, diff: Int) =
        ExerciseTemplate.DictationReorder(
            id = id, cefr = s.cefr, difficultyScore = diff + s.wordCount * 3, topic = s.topic,
            audioAssetPath = s.audioAssetPath,
            shuffledWords = rng.shuffle(s.words.toMutableList()),
            correctOrder = s.words,
            wordTimestamps = s.wordTimestamps,
            explanationAr = "الجملة الصحيحة: ${s.en}",
        )

    private fun makeTypeWhatYouHear(
        id: String,
        word: String,
        clip: WordAudioClip,
        contextSentence: String?,
        distractorPool: List<AnnotatedSentence>,
        cefr: String,
        topic: String,
        difficulty: Int,
    ): ExerciseTemplate.TypeWhatYouHear {
        val distractors = distractorPool
            .flatMap { it.words }
            .filter { it.lowercase() !in FUNCTION_WORDS && it.lowercase() != word.lowercase() && it.length >= 3 }
            .distinct()
            .shuffled()
            .take(3)
            .ifEmpty { listOf("apple", "school", "happy") }
        val opts = buildShuffled(word, distractors, rng, 4)
        val prompt = if (contextSentence != null)
            contextSentence.replace(word, "_____", ignoreCase = true)
        else
            "استمع واختر الكلمة الصحيحة"
        return ExerciseTemplate.TypeWhatYouHear(
            id = id, cefr = cefr, difficultyScore = difficulty, topic = topic,
            audioAssetPath = clip.encodedPath,
            correctSpelling = word,
            options = opts.list,
            answerIndex = opts.correctIndex,
            explanationAr = "الكلمة الصحيحة: $word",
        )
    }

    private fun makeLetterReorder(
        id: String,
        word: String,
        clip: WordAudioClip,
        cefr: String,
        topic: String,
        difficulty: Int,
    ): ExerciseTemplate.SentenceReorder {
        // Reuse SentenceReorder at letter level — word chips = individual letters
        val letters = word.filter { it.isLetter() }.map { it.toString() }
        val shuffled = rng.shuffle(letters.toMutableList())
        return ExerciseTemplate.SentenceReorder(
            id = id, cefr = cefr, difficultyScore = difficulty, topic = topic,
            promptAr = "استمع ورتّب حروف الكلمة",
            shuffledWords = shuffled,
            correctOrder = letters,
            audioAssetPath = clip.encodedPath,
            modality = LearningModality.KINETIC,
            explanationAr = "الكلمة الصحيحة: $word",
        )
    }

    // ─────────────────────────────────────────────────────────────
    // Helpers
    // ─────────────────────────────────────────────────────────────

    private data class ShuffledResult(val list: List<String>, val correctIndex: Int)

    private fun buildOptions(correct: String, pool: List<String>, r: SeededRng): List<String> =
        buildShuffled(correct, pool, r, 4).list

    private fun buildShuffled(correct: String, pool: List<String>, r: SeededRng, count: Int): ShuffledResult {
        val distractors = pool
            .filter { it.trim().lowercase() != correct.trim().lowercase() && it.isNotBlank() }
            .distinct()
            .shuffled()
            .take(count - 1)
        val opts = (listOf(correct) + distractors).toMutableList()
        while (opts.size < count) opts += "—"
        r.shuffle(opts)
        return ShuffledResult(opts.toList(), opts.indexOf(correct).coerceAtLeast(0))
    }

    private fun contentWordIndices(words: List<String>): List<Int> =
        words.indices.filter { i ->
            val w = words[i].lowercase().trimEnd('.', ',', '?', '!')
            w.length >= 3 && w !in FUNCTION_WORDS
        }.take(4)

    private fun cefrScore(cefr: String) = when (cefr.uppercase().take(2)) {
        "A1" -> 10; "A2" -> 25; "B1" -> 45; "B2" -> 65; "C1" -> 80; else -> 30
    }

    companion object {
        private val FUNCTION_WORDS = setOf(
            "the","a","an","is","are","was","were","be","been","being","have","has","had",
            "do","does","did","will","would","shall","should","may","might","must","can",
            "could","to","of","in","on","at","by","for","with","and","or","but","not",
            "i","he","she","it","we","they","you","me","him","her","us","them","my",
            "his","its","our","their","this","that","these","those","as","so","if",
            "than","then","when","where","who","go","goes","went",
        )
    }
}

/**
 * Minimal seeded deterministic RNG used by the factory.
 * Exposes the same API as SmartLocalEngine's internal Rng.
 */
class SeededRng(seed: Long) {
    private var state = seed xor 6364136223846793005L

    fun nextLong(): Long {
        state = state * 6364136223846793005L + 1442695040888963407L
        return state
    }

    fun nextInt(bound: Int): Int {
        if (bound <= 0) return 0
        return ((nextLong() ushr 1) % bound).toInt().let { if (it < 0) -it else it }
    }

    fun <T> shuffle(list: MutableList<T>): MutableList<T> {
        for (i in list.size - 1 downTo 1) {
            val j = nextInt(i + 1)
            val tmp = list[i]; list[i] = list[j]; list[j] = tmp
        }
        return list
    }

    fun <T> pickN(list: List<T>, n: Int): List<T> =
        list.toMutableList().also { shuffle(it) }.take(n)
}
