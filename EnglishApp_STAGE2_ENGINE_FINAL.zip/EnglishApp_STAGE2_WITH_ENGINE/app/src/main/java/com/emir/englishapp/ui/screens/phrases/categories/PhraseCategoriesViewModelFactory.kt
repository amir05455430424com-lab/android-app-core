package com.emir.englishapp.ui.screens.phrases.categories

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.emir.englishapp.data.repository.AppRepository

class PhraseCategoriesViewModelFactory(
    private val repo: AppRepository
) : ViewModelProvider.Factory {

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(PhraseCategoriesViewModel::class.java)) {
            return PhraseCategoriesViewModel(repo) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
    }
}
