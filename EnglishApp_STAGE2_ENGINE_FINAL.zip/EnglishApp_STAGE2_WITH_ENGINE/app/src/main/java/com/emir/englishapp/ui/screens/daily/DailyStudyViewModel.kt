package com.emir.englishapp.ui.screens.daily

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.emir.englishapp.data.repository.AppRepository
import com.emir.englishapp.domain.model.question.Question
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

class DailyStudyViewModel(
    private val repo: AppRepository,
    private val globalIndex: Int
) : ViewModel() {

    private val _uiState = MutableStateFlow(DailyStudyUiState(globalIndex = globalIndex))
    val uiState: StateFlow<DailyStudyUiState> = _uiState

    init {
        viewModelScope.launch { load() }
    }

    private suspend fun load() {
        _uiState.update { it.copy(isLoading = true, error = null) }

        val unit = try {
            repo.getAllUnitsFlat().firstOrNull { it.globalIndex == globalIndex }
        } catch (_: Throwable) { null }

        if (unit == null) {
            _uiState.update { it.copy(isLoading = false, error = "لم يتم العثور على الوحدة.", questions = emptyList()) }
            return
        }

        val all = try {
            repo.getQuestionsForUnit(globalIndex)
        } catch (_: Throwable) { emptyList() }

        if (all.isEmpty()) {
            _uiState.update {
                it.copy(
                    isLoading = false,
                    error = "لا توجد أسئلة لهذه الوحدة.",
                    unitTitleAr = unit.titleAr,
                    unitTitleEn = unit.titleEn
                )
            }
            return
        }

        // Daily session = 7 questions max (or less if not available), distributed across difficulty.
        val picked = pickEvenly(all.sortedBy { it.difficultyScore }, target = 7)

        _uiState.update {
            it.copy(
                isLoading = false,
                error = null,
                unitTitleAr = unit.titleAr,
                unitTitleEn = unit.titleEn,
                questions = picked,
                index = 0,
                selectedIndex = null,
                isAnswered = false,
                isCorrect = null,
                isFinished = false
            )
        }
    }

    fun selectOption(optionIndex: Int) {
        _uiState.update { st ->
            val q = st.current ?: return@update st
            if (st.isAnswered) return@update st // prevent re-answering
            val correct = optionIndex == q.answerIndex
            st.copy(
                selectedIndex = optionIndex,
                isAnswered = true,
                isCorrect = correct
            )
        }
    }

    fun next() {
        _uiState.update { st ->
            if (!st.isAnswered) return@update st
            val next = st.index + 1
            if (next >= st.questions.size) {
                st.copy(isFinished = true)
            } else {
                st.copy(
                    index = next,
                    selectedIndex = null,
                    isAnswered = false,
                    isCorrect = null
                )
            }
        }
    }

    private fun pickEvenly(sorted: List<Question>, target: Int): List<Question> {
        if (sorted.isEmpty()) return emptyList()
        if (sorted.size <= target) return sorted.distinctBy { it.id }

        val count = target.coerceAtMost(sorted.size)
        val step = (sorted.size - 1).toFloat() / (count - 1).toFloat()
        val out = ArrayList<Question>(count)
        for (i in 0 until count) {
            val idx = (i * step).roundToInt().coerceIn(0, sorted.lastIndex)
            out.add(sorted[idx])
        }
        return out.distinctBy { it.id }.let { distinct ->
            if (distinct.size >= count) distinct.take(count)
            else {
                // fill if duplicates removed
                val existing = distinct.map { it.id }.toHashSet()
                val fill = sorted.filterNot { existing.contains(it.id) }.take(count - distinct.size)
                distinct + fill
            }
        }
    }
}

class DailyStudyViewModelFactory(
    private val repo: AppRepository,
    private val globalIndex: Int
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return DailyStudyViewModel(repo, globalIndex) as T
    }
}
