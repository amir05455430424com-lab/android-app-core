package com.emir.englishapp.ui.screens.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.emir.englishapp.data.repository.AppRepository
import com.emir.englishapp.domain.model.daily.DailySummary
import java.text.SimpleDateFormat
import java.util.Locale
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class HomeViewModel(
    private val repo: AppRepository
) : ViewModel() {

    private val dailyDoneFlow = MutableStateFlow(false)
    private val lastDailySummaryFlow = MutableStateFlow<DailySummary?>(null)

    init {
        refreshDailyState()
    }

    fun refreshDailyState() {
        viewModelScope.launch {
            val today = todayKey()
            repo.resetDailyIfNewDay(today)
            dailyDoneFlow.value = repo.isDailySessionDone(today)
            lastDailySummaryFlow.value = repo.getLastDailySummary()
        }
    }

    val uiState = combine(
        repo.momentum,
        // Home should reflect Pro Path progression (the main learning track).
        repo.proCurrentUnitGlobalIndex,
        repo.totalXp,
        repo.dailyXpToday,
        repo.streakDays,
        dailyDoneFlow,
        lastDailySummaryFlow
    ) { values ->

        val momentum = values[0] as Int
        val unitIndex = values[1] as Int
        val totalXp = values[2] as Int
        val xpToday = values[3] as Int
        val streakDays = values[4] as Int
        val dailyDone = values[5] as Boolean
        val lastSummary = values[6] as DailySummary?

        val safeMomentum = momentum.coerceIn(0, 100)

        val hint = when {
            safeMomentum >= 85 -> "🔥 قريب جداً من 100! كمّل لتحصل على مكافأة."
            safeMomentum in 60..84 -> "ممتاز! خلّينا نوصل 80 اليوم."
            safeMomentum in 30..59 -> "خلّينا نرفع الزخم بخطوة صغيرة."
            else -> "ابدأ بخطوة بسيطة… دقيقة واحدة تكفي."
        }

        // Keep Home minimal: one clear CTA + stats.
        val (ctaTitle, ctaSubtitle) = if (!dailyDone) {
            "⚡ ابدأ جلسة اليوم" to "5 أسئلة × 4 مراحل (20 سؤال)"
        } else {
            "▶ استمر بالتعلم" to "تابع وحدتك الحالية رقم $unitIndex"
        }

        val lastTitle = lastSummary?.let { "آخر جلسة: ${it.correct}/${it.total} • +${it.xpEarned} XP" }
        val lastSubtitle = lastSummary?.let { "Score ${it.scorePercent}% • Mastery ${it.masteryPercent}% • ⭐ ${it.stars}/3" }

        HomeUiState(
            momentum = safeMomentum,
            momentumHint = hint,
            currentUnitIndex = unitIndex,
            totalXp = totalXp,
            xpToday = xpToday,
            streakDays = streakDays,
            dailyDone = dailyDone,
            headerTitle = "",
            headerSubtitle = "",
            primaryCtaTitle = ctaTitle,
            primaryCtaSubtitle = ctaSubtitle,
            guideMessage = "",
            lastDailyTitle = lastTitle,
            lastDailySubtitle = lastSubtitle
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = HomeUiState()
    )

    fun onOneMinuteSession() {
        viewModelScope.launch {
            val current = uiState.value.momentum
            repo.setMomentum((current + 5).coerceAtMost(100))
        }
    }

    private fun todayKey(): String {
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        return fmt.format(System.currentTimeMillis())
    }
}