package com.emir.englishapp.ui.screens.path

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt

@Composable
fun PathScreen(
    state: PathUiState,
    onBack: () -> Unit,
    onUnitClick: (globalIndex: Int) -> Unit
) {
    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedButton(onClick = onBack) { Text("رجوع") }
                Text("🧭 المسار", style = MaterialTheme.typography.titleLarge)
            }

            if (state.isLoading) {
                Text("تحميل...", style = MaterialTheme.typography.bodyMedium)
                return@Column
            }

            state.error?.let {
                Text(text = it, color = MaterialTheme.colorScheme.error)
                return@Column
            }

            // Staggered entrance animation for list items
            val visible = remember(state.units.size) { mutableStateListOf<Boolean>().apply { repeat(state.units.size) { add(false) } } }
            LaunchedEffect(state.units.size) {
                // reset
                for (i in visible.indices) visible[i] = false
                // stagger
                visible.indices.forEach { idx ->
                    kotlinx.coroutines.delay(40L * idx)
                    visible[idx] = true
                }
            }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                itemsIndexed(state.units, key = { _, it -> it.unit.globalIndex }) { index, item ->
                    val unit = item.unit
                    val x = unit.pathStyle.xOffset.roundToInt().dp

                    val lockedAlpha = if (item.status == UnitStatus.Locked) 0.55f else 1f

                    AnimatedVisibility(
                        visible = visible.getOrNull(index) == true,
                        enter = fadeIn(tween(220)) + slideInVertically(tween(220)) { it / 6 },
                        exit = fadeOut(tween(120)) + slideOutVertically(tween(120)) { it / 6 }
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .offset(x = x)
                                .alpha(lockedAlpha)
                        ) {
                            UnitCard(
                                item = item,
                                onClick = { onUnitClick(unit.globalIndex) }
                            )
                        }
                    }
                }
                item { Spacer(Modifier.height(24.dp)) }
            }
        }
    }
}

@Composable
private fun UnitCard(
    item: CourseUnitUi,
    onClick: () -> Unit
) {
    val unit = item.unit
    val status = item.status

    // Subtle pulse for the current unit, and for locked lock icon (handled via alpha)
    val infinite = rememberInfiniteTransition(label = "unit_pulse")
    val pulse by infinite.animateFloat(
        initialValue = 0.98f,
        targetValue = 1.02f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 900),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )
    val glowAlpha by infinite.animateFloat(
        initialValue = 0.10f,
        targetValue = 0.22f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 900),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glow_alpha"
    )

    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val pressScale = if (pressed) 0.98f else 1f

    val border = when (status) {
        UnitStatus.Current -> BorderStroke(2.dp, MaterialTheme.colorScheme.primary)
        UnitStatus.Completed -> BorderStroke(1.dp, MaterialTheme.colorScheme.tertiary)
        UnitStatus.Locked -> BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    }

    val container = when (status) {
        UnitStatus.Current -> MaterialTheme.colorScheme.primaryContainer
        UnitStatus.Completed -> MaterialTheme.colorScheme.tertiaryContainer
        UnitStatus.Locked -> MaterialTheme.colorScheme.surfaceVariant
    }

    Box(modifier = Modifier.fillMaxWidth()) {
        // Glow behind current card
        if (status == UnitStatus.Current) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .scale(pulse)
                    .alpha(glowAlpha),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {}
        }

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .scale(if (status == UnitStatus.Current) pulse * pressScale else pressScale),
            shape = RoundedCornerShape(20.dp),
            border = border,
            colors = CardDefaults.cardColors(containerColor = container)
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = when (status) {
                            UnitStatus.Locked -> "🔒"
                            UnitStatus.Current -> "⭐"
                            UnitStatus.Completed -> "✅"
                        },
                        style = MaterialTheme.typography.titleLarge
                    )

                    Text(
                        text = "${unit.globalIndex}. ${unit.titleAr}",
                        style = MaterialTheme.typography.titleMedium
                    )

                    if (unit.isVip) {
                        Text(
                            "VIP",
                            color = MaterialTheme.colorScheme.primary,
                            style = MaterialTheme.typography.labelLarge
                        )
                    }
                }

                Text(
                    text = unit.titleEn,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Text(
                    text = "XP: ${unit.xpReward} • أسئلة: ${unit.questionIds.size} • خطوات: ${item.stepIndex}/${item.stepsTotal}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                // Use interactionSource so we can animate press scale.
                Button(
                    onClick = onClick,
                    enabled = status != UnitStatus.Locked,
                    modifier = Modifier.fillMaxWidth(),
                    interactionSource = interaction
                ) {
                    Text(
                        text = when (status) {
                            UnitStatus.Locked -> "مقفلة"
                            UnitStatus.Current -> "ابدأ"
                            UnitStatus.Completed -> "إعادة"
                        }
                    )
                }
            }
        }
    }
}
