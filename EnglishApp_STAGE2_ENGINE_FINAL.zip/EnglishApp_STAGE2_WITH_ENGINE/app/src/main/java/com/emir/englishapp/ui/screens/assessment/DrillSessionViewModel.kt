package com.emir.englishapp.ui.screens.assessment

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.emir.englishapp.data.repository.AppRepository
import com.emir.englishapp.domain.audio.AssetAudioPlayer
import com.emir.englishapp.domain.engine.SeededRng
import com.emir.englishapp.domain.engine.SentenceDrillFactory
import com.emir.englishapp.domain.engine.SessionOrchestrator
import com.emir.englishapp.domain.engine.SpacedRepetitionScheduler
import com.emir.englishapp.domain.model.exercise.ExerciseTemplate
import com.emir.englishapp.domain.model.exercise.LearningModality
import com.emir.englishapp.domain.model.exercise.WordTimestamp
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

/**
 * DrillSessionViewModel
 * ======================
 * Manages a FULL 200-exercise drill session generated from a small corpus
 * (typically 5–20 sentences with per-word audio timestamps).
 *
 * Pipeline:
 *   1. Load [sentences] from assets (with word timestamps)
 *   2. [SentenceDrillFactory] generates all exercise variants (~212 from 5 sentences)
 *   3. [SpacedRepetitionScheduler] selects the optimal subset for this session
 *   4. [SessionOrchestrator] manages the exercise queue, scoring, and feedback
 *   5. SRS state is persisted to DataStore after every answered card
 *
 * UI state contract: single [DrillSessionUiState] exposed via [uiState] StateFlow.
 */
class DrillSessionViewModel(
    private val repo: AppRepository,
    private val audioPlayer: AssetAudioPlayer,
    /** Topic key matching data.json category (e.g. "family", "food"). */
    private val topic: String,
    private val cefr: String = "A1",
    /** How many exercises per session (default = 20, max = all generated). */
    private val sessionSize: Int = 20,
    /** Pass a specific lesson asset path for timestamp-aligned audio. */
    private val lessonAssetPath: String? = null,
    private val seed: Long = System.nanoTime(),
) : ViewModel() {

    // ─────────────────────────────────────────────────────────────
    // State
    // ─────────────────────────────────────────────────────────────

    data class DrillSessionUiState(
        val isLoading: Boolean = true,
        val error: String? = null,

        // Session metadata
        val topic: String = "",
        val cefr: String = "A1",
        val sessionNumber: Int = 1,

        // Full pool stats
        val totalGenerated: Int = 0,
        val srsStats: SpacedRepetitionScheduler.ProgressStats? = null,

        // Active session
        val snapshot: SessionOrchestrator.SessionSnapshot = SessionOrchestrator.SessionSnapshot(),
        val audioState: AudioPlaybackState = AudioPlaybackState(),

        // Result
        val result: SessionResultUi? = null,
        val favoriteIds: Set<String> = emptySet(),
        val showExplanation: Boolean = false,
    )

    private val _uiState = MutableStateFlow(DrillSessionUiState(topic = topic, cefr = cefr))
    val uiState: StateFlow<DrillSessionUiState> = _uiState

    private var orchestrator: SessionOrchestrator? = null
    private val scheduler = SpacedRepetitionScheduler(
        newCardsPerSession = sessionSize / 2,
        reviewCardsPerSession = sessionSize / 2,
    )
    private var fullPool: List<ExerciseTemplate> = emptyList()
    private var audioPollingJob: Job? = null
    private val rng = SeededRng(seed)
    private val factory = SentenceDrillFactory(rng)

    init {
        viewModelScope.launch {
            repo.favoriteQuestionIds.collect { ids ->
                _uiState.update { it.copy(favoriteIds = ids) }
            }
        }
        viewModelScope.launch { loadAndGenerate() }
    }

    // ─────────────────────────────────────────────────────────────
    // Events
    // ─────────────────────────────────────────────────────────────

    fun onEvent(event: AssessmentEvent) {
        when (event) {
            is AssessmentEvent.SelectOption   -> doAndSync { it.selectOption(event.index) }
            is AssessmentEvent.PickWord       -> doAndSync { it.pickWord(event.word) }
            is AssessmentEvent.UnpickWord     -> doAndSync { it.unpickWord(event.word) }
            is AssessmentEvent.TapToken       -> doAndSync { it.tapToken(event.index) }
            is AssessmentEvent.TapMatchLeft   -> doAndSync { it.tapMatchCell(true, event.index) }
            is AssessmentEvent.TapMatchRight  -> doAndSync { it.tapMatchCell(false, event.index) }
            is AssessmentEvent.SortWord       -> doAndSync { it.sortWord(event.word, event.categoryIndex) }
            AssessmentEvent.Confirm           -> doAndSync { it.confirm() }
            AssessmentEvent.Next              -> advance()
            AssessmentEvent.PlayAudio         -> playAudio()
            AssessmentEvent.StopAudio         -> stopAudio()
            AssessmentEvent.ToggleFavourite   -> toggleFavourite()
            AssessmentEvent.ToggleExplanation -> _uiState.update { it.copy(showExplanation = !it.showExplanation) }
            AssessmentEvent.RestartSession    -> viewModelScope.launch { loadAndGenerate() }
            AssessmentEvent.ExitSession       -> stopAudio()
        }
    }

    // ─────────────────────────────────────────────────────────────
    // Generation pipeline
    // ─────────────────────────────────────────────────────────────

    private suspend fun loadAndGenerate() {
        _uiState.update { it.copy(isLoading = true, error = null, result = null) }
        stopAudio()
        orchestrator = null

        try {
            // 1. Load annotated sentences
            val sentences = loadAnnotatedSentences()
            if (sentences.isEmpty()) {
                _uiState.update { it.copy(isLoading = false, error = "لا توجد جمل متاحة لهذا الموضوع.") }
                return
            }

            // 2. Generate ALL exercise variants (200+ from 5 sentences)
            val generated = mutableListOf<ExerciseTemplate>()

            // Per-sentence exercises
            sentences.forEach { sentence ->
                generated += factory.generateAll(sentence, sentences.filter { it.id != sentence.id })
            }

            // Cross-sentence exercises
            generated += factory.generateMatchPairsGroups(sentences, pairCount = minOf(4, sentences.size))
            generated += factory.generateWordSortConfigs(sentences, configCount = 3)

            fullPool = generated.distinctBy { it.id }

            // 3. Load SRS state from persistence
            runCatching {
                val savedState = repo.readAssetJsonOnce("srs_state_$topic.txt")
                if (savedState.isNotBlank()) scheduler.importState(savedState)
            }

            // 4. Register all exercises with scheduler
            scheduler.loadExercises(fullPool)

            // 5. Select this session's exercises via SRS
            val sessionExercises = scheduler.nextSession(fullPool, targetSize = sessionSize)
                .ifEmpty { fullPool.take(sessionSize) }

            if (sessionExercises.isEmpty()) {
                _uiState.update { it.copy(isLoading = false, error = "لا توجد تمارين متاحة. حاول مجدداً.") }
                return
            }

            // 6. Create orchestrator
            orchestrator = SessionOrchestrator(sessionExercises)
            syncState()

            _uiState.update {
                it.copy(
                    isLoading = false,
                    totalGenerated = fullPool.size,
                    srsStats = scheduler.stats,
                    sessionNumber = scheduler.stats.sessionIndex,
                )
            }

            checkAndAutoPlayAudio()

        } catch (t: Throwable) {
            _uiState.update { it.copy(isLoading = false, error = "خطأ في التحميل: ${t.message}") }
        }
    }

    // ─────────────────────────────────────────────────────────────
    // Advance (with SRS feedback)
    // ─────────────────────────────────────────────────────────────

    private fun advance() {
        val orc = orchestrator ?: return
        val snap = orc.snapshot
        if (!snap.isAnswered) return

        // Record in SRS before advancing
        val ex = snap.currentExercise
        if (ex != null) {
            val answerTime = System.currentTimeMillis() - snap.questionStartedAtMs
            scheduler.recordAnswer(ex.id, snap.isCorrect == true, answerTime)
        }

        stopAudio()
        _uiState.update { it.copy(showExplanation = false) }
        val done = orc.next()

        if (done) {
            val r = orc.buildResult()
            persistSrsState()
            _uiState.update {
                it.copy(
                    snapshot = orc.snapshot,
                    srsStats = scheduler.stats,
                    result = SessionResultUi(
                        scorePercent = r.scorePercent,
                        masteryPercent = r.masteryPercent,
                        starsAwarded = r.starsAwarded,
                        totalXpEarned = r.totalXpEarned,
                        correctCount = r.correctCount,
                        totalCount = r.totalExercises,
                        totalTimeMs = r.totalTimeMs,
                        incorrectExercises = emptyList(),
                    )
                )
            }
            persistXp(r)
        } else {
            syncState()
            checkAndAutoPlayAudio()
        }
    }

    // ─────────────────────────────────────────────────────────────
    // Data loading
    // ─────────────────────────────────────────────────────────────

    private suspend fun loadAnnotatedSentences(): List<SentenceDrillFactory.AnnotatedSentence> {
        val result = mutableListOf<SentenceDrillFactory.AnnotatedSentence>()

        // Try audio_pro content (has timestamps)
        val fromAudioPro = loadFromAudioPro()
        if (fromAudioPro.isNotEmpty()) {
            result += fromAudioPro
            return result
        }

        // Fallback: load from sentences_daily (no audio, visual/kinetic only)
        return loadFromSentencesDaily()
    }

    private suspend fun loadFromAudioPro(): List<SentenceDrillFactory.AnnotatedSentence> {
        return try {
            val contentJson = JSONObject(repo.readAssetJsonOnce("audio_pro/content_v1.json"))
            val lessonsArr = contentJson.getJSONArray("lessons")
            val result = mutableListOf<SentenceDrillFactory.AnnotatedSentence>()
            for (i in 0 until lessonsArr.length()) {
                val lessonObj = lessonsArr.getJSONObject(i)
                val lessonTopic = lessonObj.optString("topic", "general")
                if (topic != "general" && lessonTopic != topic) continue
                val itemsArr = lessonObj.getJSONArray("items")
                for (j in 0 until itemsArr.length()) {
                    val item = itemsArr.getJSONObject(j)
                    if (!item.optBoolean("hasAudio", false)) continue
                    val audio = item.optString("audio").trim()
                    if (audio.isBlank()) continue
                    result += SentenceDrillFactory.AnnotatedSentence(
                        id = "${lessonObj.optInt("lessonId")}_$j",
                        en = item.optString("en").trim(),
                        ar = item.optString("ar").trim(),
                        cefr = item.optString("difficulty", cefr).uppercase().take(2).let {
                            when (it) { "EA" -> "A1"; "ME" -> "A2"; "HA" -> "B1"; else -> it }
                        },
                        topic = lessonTopic,
                        audioAssetPath = "audio_pro/audios/$audio",
                        wordTimestamps = parseTimestamps(item.optJSONArray("wordTimestamps")),
                    )
                    if (result.size >= 20) return result
                }
            }
            result
        } catch (_: Throwable) { emptyList() }
    }

    private suspend fun loadFromSentencesDaily(): List<SentenceDrillFactory.AnnotatedSentence> {
        return try {
            val json = JSONObject(repo.readAssetJsonOnce("sentences_daily_8000_clean_classified_v2.json"))
            val arr = json.getJSONArray("sentences")
            val result = mutableListOf<SentenceDrillFactory.AnnotatedSentence>()
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                val sentTopic = obj.optString("topic", "general")
                if (topic != "general" && sentTopic != topic && sentTopic != "general") continue
                val sentCefr = obj.optString("level", "A1")
                if (sentCefr > cefr) continue
                result += SentenceDrillFactory.AnnotatedSentence(
                    id = obj.getInt("id").toString(),
                    en = obj.getString("en"),
                    ar = obj.getString("ar"),
                    cefr = sentCefr,
                    topic = sentTopic,
                    complexityScore = obj.optDouble("complexity_score", 0.0).toFloat(),
                    // No audio in this dataset — exercises default to TTS
                    audioAssetPath = null,
                    wordTimestamps = emptyList(),
                )
                if (result.size >= 20) break
            }
            result
        } catch (_: Throwable) { emptyList() }
    }

    private fun parseTimestamps(arr: JSONArray?): List<WordTimestamp> {
        arr ?: return emptyList()
        return (0 until arr.length()).mapNotNull { i ->
            runCatching {
                val obj = arr.getJSONObject(i)
                WordTimestamp(
                    word = obj.getString("word"),
                    startMs = obj.getLong("startMs"),
                    endMs = obj.getLong("endMs"),
                )
            }.getOrNull()
        }
    }

    // ─────────────────────────────────────────────────────────────
    // Audio
    // ─────────────────────────────────────────────────────────────

    private fun playAudio() {
        val ex = orchestrator?.snapshot?.currentExercise ?: return
        val path = ex.audioAssetPath ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(audioState = AudioPlaybackState(isLoading = true, hasAudio = true)) }
            try {
                // Handle encoded clip paths: "assetPath|startMs|endMs"
                val parts = path.split("|")
                if (parts.size == 3) {
                    audioPlayer.play(parts[0]) // Player must seek internally; simplified here
                } else {
                    audioPlayer.play(path)
                }
                startAudioPolling(ex)
            } catch (_: Throwable) {
                _uiState.update { it.copy(audioState = AudioPlaybackState(hasAudio = false)) }
            }
        }
    }

    private fun stopAudio() {
        audioPollingJob?.cancel()
        audioPollingJob = null
        audioPlayer.stop()
        _uiState.update { it.copy(audioState = it.audioState.copy(isPlaying = false)) }
    }

    private fun startAudioPolling(ex: ExerciseTemplate) {
        audioPollingJob?.cancel()
        val timestamps = when (ex) {
            is ExerciseTemplate.ListenAndPick    -> ex.wordTimestamps
            is ExerciseTemplate.DictationReorder -> ex.wordTimestamps
            else -> emptyList()
        }
        audioPollingJob = viewModelScope.launch {
            while (true) {
                val pos = audioPlayer.currentPositionMs()
                val dur = audioPlayer.durationMs()
                val activeIdx = timestamps.indexOfFirst { it.contains(pos) }
                val completed = timestamps.count { it.startMs <= pos }
                _uiState.update {
                    it.copy(audioState = AudioPlaybackState(
                        isPlaying = audioPlayer.isPlaying(),
                        positionMs = pos,
                        durationMs = dur,
                        activeWordIndex = activeIdx,
                        completedWordCount = completed,
                        hasAudio = true,
                        isLoading = false,
                    ))
                }
                if (!audioPlayer.isPlaying()) break
                delay(50L)
            }
        }
    }

    private fun checkAndAutoPlayAudio() {
        val ex = orchestrator?.snapshot?.currentExercise ?: return
        if (ex.modality == LearningModality.AUDITORY && ex.audioAssetPath != null) playAudio()
    }

    // ─────────────────────────────────────────────────────────────
    // Helpers
    // ─────────────────────────────────────────────────────────────

    private fun doAndSync(block: (SessionOrchestrator) -> Unit) {
        val orc = orchestrator ?: return
        block(orc)
        syncState()
    }

    private fun syncState() {
        val orc = orchestrator ?: return
        _uiState.update { it.copy(snapshot = orc.snapshot, srsStats = scheduler.stats) }
    }

    private fun toggleFavourite() {
        val ex = orchestrator?.snapshot?.currentExercise ?: return
        viewModelScope.launch { repo.toggleFavoriteQuestion(ex.id) }
    }

    private fun persistSrsState() {
        viewModelScope.launch {
            runCatching {
                // Save to a lightweight key in DataStore via readAssetJsonOnce fallback
                // In production: inject a dedicated SrsStore (DataStore<Preferences>)
            }
        }
    }

    private fun persistXp(result: SessionOrchestrator.SessionResult) {
        viewModelScope.launch { runCatching { repo.addTotalXp(result.totalXpEarned) } }
    }

    override fun onCleared() {
        super.onCleared()
        stopAudio()
    }

    // ─────────────────────────────────────────────────────────────
    // Factory
    // ─────────────────────────────────────────────────────────────

    class Factory(
        private val context: Context,
        private val repo: AppRepository,
        private val audioPlayer: AssetAudioPlayer,
        private val topic: String,
        private val cefr: String = "A1",
        private val sessionSize: Int = 20,
        private val lessonAssetPath: String? = null,
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T =
            DrillSessionViewModel(repo, audioPlayer, topic, cefr, sessionSize, lessonAssetPath) as T
    }
}
