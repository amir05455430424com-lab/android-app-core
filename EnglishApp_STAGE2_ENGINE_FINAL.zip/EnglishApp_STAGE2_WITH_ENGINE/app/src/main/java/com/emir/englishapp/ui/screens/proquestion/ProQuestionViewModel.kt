package com.emir.englishapp.ui.screens.proquestion

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.emir.englishapp.data.repository.AppRepository
import com.emir.englishapp.domain.model.questionv2.FillBlankQuestionV2
import com.emir.englishapp.domain.model.questionv2.McqQuestionV2
import com.emir.englishapp.domain.model.questionv2.QuestionV2
import com.emir.englishapp.domain.model.questionv2.ReorderQuestionV2
import com.emir.englishapp.ui.screens.unitlesson.UnitStepResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

class ProQuestionViewModel(
    private val repo: AppRepository,
    private val globalIndex: Int,
    private val stepIndex: Int,
    private val mode: String = "pro",
    private val stepsTotal: Int = 4,
    // Per spec: 5 questions per step x 4 steps = 20
    private val stepSize: Int = 5
) : ViewModel() {

    // Lightweight adaptive ordering inside the current step.
    // (We keep the question set fixed, but we adapt which question comes next based on performance.)
    private val recentResults: ArrayDeque<Boolean> = ArrayDeque()

    private val _uiState = MutableStateFlow(
        ProQuestionUiState(globalIndex = globalIndex, stepIndex = stepIndex, stepsTotal = stepsTotal)
    )
    val uiState: StateFlow<ProQuestionUiState> = _uiState

    init {
        viewModelScope.launch { load() }
        viewModelScope.launch {
            repo.favoriteQuestionIds.collect { ids ->
                _uiState.update { it.copy(favoriteIds = ids) }
            }
        }
    }

    fun toggleFavoriteCurrent() {
        val q = _uiState.value.questions.getOrNull(_uiState.value.index) ?: return
        viewModelScope.launch { repo.toggleFavoriteQuestion(q.id) }
    }

    fun onEvent(event: ProQuestionEvent, onFinished: ((UnitStepResult) -> Unit)? = null) {
        when (event) {
            is ProQuestionEvent.SelectOption -> selectOption(event.index)
            is ProQuestionEvent.PickWord -> pickWord(event.word)
            is ProQuestionEvent.UnpickWord -> unpickWord(event.word)
            ProQuestionEvent.Confirm -> confirm()
            ProQuestionEvent.Next -> {
                val cb = onFinished ?: return
                next(cb)
            }
        }
    }

    private suspend fun load() {
        _uiState.update { it.copy(isLoading = true, error = null) }

        val unit = runCatching { repo.getAllProUnitsFlat().firstOrNull { u -> u.globalIndex == globalIndex } }.getOrNull()
        if (unit == null) {
            _uiState.update { it.copy(isLoading = false, error = "لم يتم العثور على الوحدة (PRO).") }
            return
        }

        if (stepIndex == 0) {
            runCatching { repo.resetProUnitRun(globalIndex) }
            runCatching { repo.setProUnitStepIndex(globalIndex, 0) }
        }

        var rawQuestions = runCatching {
            repo.getProUnitLessonStepQuestionsV2(
                globalIndex = globalIndex,
                stepIndex = stepIndex,
                stepsTotal = stepsTotal,
                stepSize = stepSize
            )
        }.getOrElse { emptyList() }

        // Daily mode: inject a lightweight listening MCQ (from assets/data.json pool).
        if (mode == "daily") {
            buildListeningMcq(seed = globalIndex * 1000 + stepIndex)?.let { listenQ ->
                val idx = rawQuestions.indexOfFirst { it is McqQuestionV2 }.takeIf { it >= 0 } ?: 0
                rawQuestions = rawQuestions.toMutableList().also { list ->
                    if (list.isEmpty()) list.add(listenQ) else list[idx] = listenQ
                }
            }
        }

        // Order questions from easier to harder by default (especially important for A1/A2).
        val questions = rawQuestions.sortedBy { difficultyScore(it) }

        if (questions.isEmpty()) {
            _uiState.update { it.copy(isLoading = false, error = "لا توجد أسئلة لهذه الخطوة (PRO).") }
            return
        }

        val now = System.currentTimeMillis()
        _uiState.update {
            it.copy(
                isLoading = false,
                error = null,
                unitTitleAr = unit.titleAr,
                unitTitleEn = unit.titleEn,
                xpReward = unit.xpReward,
                questions = questions,
                index = 0,
                selectedIndex = null,
                reorderAvailable = buildReorderAvailable(questions.first()),
                reorderSelected = emptyList(),
                isAnswered = false,
                isCorrect = null,
                feedbackText = null,
                correctCount = 0,
                streakCorrect = 0,
                questionStartedAtMs = now,
                totalAnswerTimeMs = 0L
            )
        }
    }

    private fun difficultyScore(q: QuestionV2): Int {
        // A simple heuristic that works well for A1/A2 ramp:
        // shorter sentences, fewer special patterns => easier.
        val en = when (q) {
            is McqQuestionV2 -> q.sentenceEn ?: q.termEn ?: q.promptEn ?: ""
            is FillBlankQuestionV2 -> q.sentenceEn
            is ReorderQuestionV2 -> q.correctOrder.joinToString(" ")
        }.trim()

        if (en.isBlank()) return 999

        val words = en.split(Regex("\\s+")).filter { it.isNotBlank() }
        val wCount = words.size

        val lower = en.lowercase()
        val hasQuestion = lower.contains("?") || lower.startsWith("who ") || lower.startsWith("what ") || lower.startsWith("where ") || lower.startsWith("when ") || lower.startsWith("why ") || lower.startsWith("how ")
        val hasComplexTense = listOf("will ", "have ", "had ", "has ").any { lower.contains(it) }
        val hasConjunction = listOf(" because ", " although ", " however ", " while ", " since ").any { lower.contains(it) }
        val endsWithPrep = lower.endsWith(" for") || lower.endsWith(" to") || lower.endsWith(" with") || lower.endsWith(" about")

        var score = wCount
        if (hasQuestion) score += 3
        if (hasComplexTense) score += 2
        if (hasConjunction) score += 2
        if (endsWithPrep) score += 1
        return score
    }

    private suspend fun buildListeningMcq(seed: Int): McqQuestionV2? {
        return try {
            val pool = repo.getAllPhrases()
            if (pool.size < 20) return null

            val rnd = java.util.Random(seed.toLong())
            val correct = pool[rnd.nextInt(pool.size)]
            val correctAr = correct.ar.trim()
            if (correctAr.isBlank()) return null

            val opts = LinkedHashSet<String>()
            opts.add(correctAr)
            while (opts.size < 4) {
                val cand = pool[rnd.nextInt(pool.size)].ar.trim()
                if (cand.isNotBlank()) opts.add(cand)
            }
            val options = opts.toList().shuffled(rnd)
            val answerIdx = options.indexOf(correctAr).coerceAtLeast(0)
            return McqQuestionV2(
                id = "listen_${correct.id}",
                promptAr = "استمع واختر المعنى الصحيح",
                promptEn = null,
                termEn = null,
                termAr = null,
                // Show the English sentence/phrase so the user has context (and/or can replay TTS).
                sentenceEn = correct.en,
                // ✅ احذف sentenceAr لأن الموديل عندك لا يحتويه
                optionsEn = null,
                optionsAr = options,
                answerIndex = answerIdx,
                cefr = "A1",
                direction = "listen",
                difficultyScore = 1
            )
        } catch (_: Throwable) {
            null
        }
    }

    private fun buildReorderAvailable(q: QuestionV2): List<String> {
        return if (q is ReorderQuestionV2) q.words else emptyList()
    }

    private fun selectOption(index: Int) {
        if (_uiState.value.isAnswered) return
        _uiState.update { it.copy(selectedIndex = index) }
    }

    private fun pickWord(word: String) {
        _uiState.update { st ->
            if (st.isAnswered) return@update st
            // In Duolingo style, we allow picking the same word if it exists multiple times in available
            // But for simplicity, we'll manage it by index or existence
            st.copy(reorderSelected = st.reorderSelected + word)
        }
    }

    private fun unpickWord(word: String) {
        _uiState.update { st ->
            if (st.isAnswered) return@update st
            if (word !in st.reorderSelected) return@update st
            // Remove only one occurrence (the latest) to support repeated words safely.
            val idx = st.reorderSelected.indexOfLast { it == word }
            if (idx < 0) return@update st
            val next = st.reorderSelected.toMutableList().apply { removeAt(idx) }
            st.copy(reorderSelected = next)
        }
    }

    private fun confirm() {
        _uiState.update { st ->
            if (st.isAnswered) return@update st
            val q = st.questions.getOrNull(st.index) ?: return@update st

            // Validation: require a selection before confirming.
            val hasSelection = when (q) {
                is ReorderQuestionV2 -> st.reorderSelected.isNotEmpty()
                is McqQuestionV2, is FillBlankQuestionV2 -> st.selectedIndex != null
                else -> st.selectedIndex != null
            }
            if (!hasSelection) return@update st

            val spent = (System.currentTimeMillis() - st.questionStartedAtMs).coerceAtLeast(0L)
            val ok = when (q) {
                is McqQuestionV2 -> (st.selectedIndex == q.answerIndex)
                is FillBlankQuestionV2 -> (st.selectedIndex == q.answerIndex)
                is ReorderQuestionV2 -> (st.reorderSelected == q.correctOrder)
                else -> false
            }

            // Record attempt for legacy analytics/history (best effort).
            viewModelScope.launch {
                runCatching {
                    val legacy = repo.getProQuestionByIdMap()[q.id]
                    if (legacy != null) repo.recordQuestionAttempt(question = legacy, correct = ok)
                }
            }

            val feedback = q.explanationAr?.takeIf { it.isNotBlank() }
                ?: if (ok) "إجابة صحيحة ✅" else "إجابة غير صحيحة ❌"

            // Update streak + recent window
            val nextStreak = if (ok) st.streakCorrect + 1 else 0
            recentResults.addLast(ok)
            while (recentResults.size > 5) recentResults.removeFirst()

            st.copy(
                isAnswered = true,
                isCorrect = ok,
                feedbackText = feedback,
                streakCorrect = nextStreak,
                correctCount = st.correctCount + if (ok) 1 else 0,
                totalAnswerTimeMs = st.totalAnswerTimeMs + spent
            )
        }
    }

    private fun next(onFinished: (UnitStepResult) -> Unit) {
        val st = _uiState.value
        if (!st.isAnswered) return

        if (st.index + 1 >= st.questions.size) {
            viewModelScope.launch {
                val result = finalizeStep(st)
                onFinished(result)
            }
        } else {
            // Adaptive selection: choose the next question from the remaining pool.
            // If the user is on a streak, surface a slightly harder item.
            // If they missed recently, surface an easier item.
            val remainingStart = st.index + 1
            val remaining = st.questions.drop(remainingStart)
            val useHarder = st.streakCorrect >= 3
            val recentWrong = recentResults.count { !it }
            val useEasier = recentWrong >= 2

            val pickIdxInRemaining = when {
                useEasier -> remaining.indices.minByOrNull { difficultyScore(remaining[it]) } ?: 0
                useHarder -> remaining.indices.maxByOrNull { difficultyScore(remaining[it]) } ?: 0
                else -> 0
            }

            val nextIndexAbs = remainingStart + pickIdxInRemaining
            val nextQuestions = st.questions.toMutableList().apply {
                // swap into next position
                val tmp = this[remainingStart]
                this[remainingStart] = this[nextIndexAbs]
                this[nextIndexAbs] = tmp
            }

            val nextQ = nextQuestions[remainingStart]
            val now = System.currentTimeMillis()
            _uiState.update {
                it.copy(
                    questions = nextQuestions,
                    index = it.index + 1,
                    selectedIndex = null,
                    reorderAvailable = buildReorderAvailable(nextQ),
                    reorderSelected = emptyList(),
                    isAnswered = false,
                    isCorrect = null,
                    feedbackText = null,
                    questionStartedAtMs = now
                )
            }
        }
    }

    private suspend fun finalizeStep(st: ProQuestionUiState): UnitStepResult {
        val total = st.questions.size.coerceAtLeast(1)
        val accuracy = st.correctCount.toFloat() / total.toFloat()
        val scorePercent = (accuracy * 100f).roundToInt().coerceIn(0, 100)

        val avgSec = (st.totalAnswerTimeMs.toFloat() / total.toFloat()) / 1000f
        val speedBonus = ((10f - avgSec) / 10f).coerceIn(0f, 1f)
        val mastery = (0.7f * accuracy + 0.3f * speedBonus).coerceIn(0f, 1f)
        val masteryPercent = (mastery * 100f).roundToInt().coerceIn(0, 100)

        val stars = when {
            masteryPercent >= 90 -> 3
            masteryPercent >= 80 -> 2
            masteryPercent >= 65 -> 1
            else -> 0
        }

        repo.addToProUnitRun(globalIndex, correctDelta = st.correctCount, totalDelta = total, timeDeltaMs = st.totalAnswerTimeMs)

        val isFinal = (stepIndex >= stepsTotal - 1)
        var unlockedNext = false

        val wrong = (total - st.correctCount).coerceAtLeast(0)
        val xpFromAnswers = st.correctCount * 2 + wrong * 1
        val perfectBonus = if (st.correctCount == total) 10 else 0
        var xpEarned = xpFromAnswers + perfectBonus

        if (!isFinal) {
            repo.setProUnitStepIndex(globalIndex, (stepIndex + 1).coerceAtMost(stepsTotal))
        } else {
            val (cAll, tAll, msAll) = repo.getProUnitRun(globalIndex)
            val tSafe = tAll.coerceAtLeast(1)
            val accAll = cAll.toFloat() / tSafe.toFloat()
            val avgAllSec = (msAll.toFloat() / tSafe.toFloat()) / 1000f
            val speedAll = ((10f - avgAllSec) / 10f).coerceIn(0f, 1f)
            val masteryAll = (0.7f * accAll + 0.3f * speedAll).coerceIn(0f, 1f)
            val masteryAllPercent = (masteryAll * 100f).roundToInt().coerceIn(0, 100)

            val starsAll = when {
                masteryAllPercent >= 90 -> 3
                masteryAllPercent >= 80 -> 2
                masteryAllPercent >= 65 -> 1
                else -> 0
            }

            xpEarned += st.xpReward
            repo.addTotalXp(xpEarned)
            repo.saveProUnitResult(
                globalIndex = globalIndex,
                scorePercent = (accAll * 100f).roundToInt(),
                masteryPercent = masteryAllPercent,
                stars = starsAll
            )

            if (masteryAllPercent >= 80) {
                val current = repo.proCurrentUnitGlobalIndex.first()
                if (current <= globalIndex) {
                    repo.setProCurrentUnitGlobalIndex(globalIndex + 1)
                    unlockedNext = true
                }
            }

            repo.setProUnitStepIndex(globalIndex, stepsTotal)
            repo.resetProUnitRun(globalIndex)

            if (mode == "daily") {
                val today = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
                    .format(java.util.Date())
                runCatching { repo.markDailySessionDone(today) }
                runCatching {
                    repo.saveLastDailySummary(
                        com.emir.englishapp.domain.model.daily.DailySummary(
                            date = today,
                            globalIndex = globalIndex,
                            correct = cAll,
                            total = tSafe,
                            scorePercent = (accAll * 100f).roundToInt().coerceIn(0, 100),
                            masteryPercent = masteryAllPercent,
                            stars = starsAll,
                            xpEarned = xpEarned
                        )
                    )
                }
            }

            return UnitStepResult(
                globalIndex = globalIndex,
                stepIndex = stepIndex,
                stepsTotal = stepsTotal,
                scorePercent = (accAll * 100f).roundToInt().coerceIn(0, 100),
                masteryPercent = masteryAllPercent,
                stars = starsAll,
                correct = cAll,
                total = tSafe,
                xpEarned = xpEarned,
                unlockedNext = unlockedNext,
                isFinal = true
            )
        }

        return UnitStepResult(
            globalIndex = globalIndex,
            stepIndex = stepIndex,
            stepsTotal = stepsTotal,
            scorePercent = scorePercent,
            masteryPercent = masteryPercent,
            stars = stars,
            correct = st.correctCount,
            total = total,
            xpEarned = xpEarned,
            unlockedNext = unlockedNext,
            isFinal = false
        )
    }
}

class ProQuestionViewModelFactory(
    private val repo: AppRepository,
    private val globalIndex: Int,
    private val stepIndex: Int,
    private val mode: String = "pro"
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        @Suppress("UNCHECKED_CAST")
        return ProQuestionViewModel(repo, globalIndex, stepIndex, mode) as T
    }
}