package com.emir.englishapp.ui.screens.assessment

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.emir.englishapp.data.repository.AppRepository
import com.emir.englishapp.domain.audio.AssetAudioPlayer
import com.emir.englishapp.domain.engine.SessionOrchestrator
import com.emir.englishapp.domain.engine.SmartLocalEngine
import com.emir.englishapp.domain.model.exercise.ExerciseTemplate
import com.emir.englishapp.domain.model.exercise.LearningModality
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

/**
 * AssessmentViewModel — bridges the SmartLocalEngine + SessionOrchestrator
 * with the Compose UI layer.
 *
 * Responsibilities:
 *  - Loads raw sentence/word data from assets via [AppRepository].
 *  - Instantiates [SmartLocalEngine] to produce an exercise list.
 *  - Wraps the list in [SessionOrchestrator] and forwards all UI events.
 *  - Manages audio playback state with ms-precise position polling.
 *  - Persists session result via [AppRepository] on session completion.
 *
 * Navigation contract:
 *  - Callers pass [topic], [cefr], [sessionMode], [sessionSize].
 *  - On completion, [uiState].result != null → Screen navigates to reward screen.
 */
class AssessmentViewModel(
    private val repo: AppRepository,
    private val audioPlayer: AssetAudioPlayer,
    private val topic: String,
    private val cefr: String,
    private val sessionMode: SessionMode,
    private val sessionSize: Int = 10,
    private val moduleTitleEn: String = "",
    private val moduleTitleAr: String = "",
    private val globalIndex: Int = 0,
    private val seed: Long = System.nanoTime(),
) : ViewModel() {

    private val _uiState = MutableStateFlow(
        AssessmentUiState(
            moduleTitleEn = moduleTitleEn,
            moduleTitleAr = moduleTitleAr,
            topic = topic,
            cefr = cefr,
            sessionMode = sessionMode,
        )
    )
    val uiState: StateFlow<AssessmentUiState> = _uiState

    private var orchestrator: SessionOrchestrator? = null
    private var audioPollingJob: Job? = null

    init {
        viewModelScope.launch {
            repo.favoriteQuestionIds.collect { ids ->
                _uiState.update { it.copy(favoriteIds = ids) }
            }
        }
        viewModelScope.launch { loadSession() }
    }

    // ─────────────────────────────────────────────────────────────
    // Event dispatch
    // ─────────────────────────────────────────────────────────────

    fun onEvent(event: AssessmentEvent) {
        when (event) {
            is AssessmentEvent.SelectOption   -> doAndSync { it.selectOption(event.index) }
            is AssessmentEvent.PickWord       -> doAndSync { it.pickWord(event.word) }
            is AssessmentEvent.UnpickWord     -> doAndSync { it.unpickWord(event.word) }
            is AssessmentEvent.TapToken       -> doAndSync { it.tapToken(event.index) }
            is AssessmentEvent.TapMatchLeft   -> doAndSync { it.tapMatchCell(isLeft = true, index = event.index) }
            is AssessmentEvent.TapMatchRight  -> doAndSync { it.tapMatchCell(isLeft = false, index = event.index) }
            is AssessmentEvent.SortWord       -> doAndSync { it.sortWord(event.word, event.categoryIndex) }
            AssessmentEvent.Confirm           -> doAndSync { it.confirm() }
            AssessmentEvent.Next              -> advance()
            AssessmentEvent.PlayAudio         -> playAudio()
            AssessmentEvent.StopAudio         -> stopAudio()
            AssessmentEvent.ToggleFavourite   -> toggleFavourite()
            AssessmentEvent.ToggleExplanation -> _uiState.update { it.copy(showExplanation = !it.showExplanation) }
            AssessmentEvent.ExitSession       -> stopAudio()
            AssessmentEvent.RestartSession    -> viewModelScope.launch { loadSession() }
        }
    }

    // ─────────────────────────────────────────────────────────────
    // Session loading
    // ─────────────────────────────────────────────────────────────

    private suspend fun loadSession() {
        _uiState.update { it.copy(isLoading = true, error = null, result = null) }
        stopAudio()
        orchestrator = null

        try {
            val sentences = loadSentences()
            val wordPairs = loadWordPairs()
            val audioHints = loadAudioHints(sentences)

            val engine = SmartLocalEngine(seed = seed)
            val targetModality: LearningModality? = when (sessionMode) {
                SessionMode.VISUAL   -> LearningModality.VISUAL
                SessionMode.AUDITORY -> LearningModality.AUDITORY
                SessionMode.KINETIC  -> LearningModality.KINETIC
                else                 -> null
            }

            val exercises = engine.generateSession(
                sentences = sentences,
                wordPairs = wordPairs,
                audioHints = audioHints,
                topic = topic,
                cefr = cefr,
                targetModality = targetModality,
                sessionSize = sessionSize,
                sessionSeed = seed,
            )

            if (exercises.isEmpty()) {
                _uiState.update { it.copy(isLoading = false, error = "لا توجد تمارين متاحة لهذا الموضوع.") }
                return
            }

            orchestrator = SessionOrchestrator(exercises)
            syncState()
            _uiState.update { it.copy(isLoading = false) }

            // Auto-play audio for auditory exercises
            checkAndAutoPlayAudio()

        } catch (t: Throwable) {
            _uiState.update {
                it.copy(isLoading = false, error = "فشل تحميل الجلسة. حاول مرة أخرى.\n${t.message}")
            }
        }
    }

    // ─────────────────────────────────────────────────────────────
    // Navigation
    // ─────────────────────────────────────────────────────────────

    private fun advance() {
        val orc = orchestrator ?: return
        if (!orc.snapshot.isAnswered) return
        stopAudio()
        _uiState.update { it.copy(showExplanation = false) }
        val done = orc.next()
        if (done) {
            val r = orc.buildResult()
            val incorrectExercises = _uiState.value.snapshot.let { snap ->
                // Collect exercises that were answered incorrectly
                emptyList<ExerciseTemplate>() // Simplified — ViewModel stores full exercise list
            }
            _uiState.update {
                it.copy(
                    snapshot = orc.snapshot,
                    result = SessionResultUi(
                        scorePercent = r.scorePercent,
                        masteryPercent = r.masteryPercent,
                        starsAwarded = r.starsAwarded,
                        totalXpEarned = r.totalXpEarned,
                        correctCount = r.correctCount,
                        totalCount = r.totalExercises,
                        totalTimeMs = r.totalTimeMs,
                        incorrectExercises = incorrectExercises,
                    )
                )
            }
            persistResult(r)
        } else {
            syncState()
            checkAndAutoPlayAudio()
        }
    }

    // ─────────────────────────────────────────────────────────────
    // State sync
    // ─────────────────────────────────────────────────────────────

    private fun doAndSync(block: (SessionOrchestrator) -> Unit) {
        val orc = orchestrator ?: return
        block(orc)
        syncState()
    }

    private fun syncState() {
        val orc = orchestrator ?: return
        val snap = orc.snapshot
        _uiState.update { it.copy(snapshot = snap) }
    }

    // ─────────────────────────────────────────────────────────────
    // Audio playback
    // ─────────────────────────────────────────────────────────────

    private fun playAudio() {
        val ex = orchestrator?.snapshot?.currentExercise ?: return
        val path = ex.audioAssetPath ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(audioState = AudioPlaybackState(isLoading = true, hasAudio = true)) }
            try {
                audioPlayer.play(path)
                startAudioPolling(ex)
            } catch (t: Throwable) {
                _uiState.update { it.copy(audioState = AudioPlaybackState(hasAudio = false)) }
            }
        }
    }

    private fun stopAudio() {
        audioPollingJob?.cancel()
        audioPollingJob = null
        audioPlayer.stop()
        _uiState.update { it.copy(audioState = it.audioState.copy(isPlaying = false)) }
    }

    private fun startAudioPolling(ex: ExerciseTemplate) {
        audioPollingJob?.cancel()
        val timestamps = when (ex) {
            is ExerciseTemplate.ListenAndPick    -> ex.wordTimestamps
            is ExerciseTemplate.DictationReorder -> ex.wordTimestamps
            else                                 -> emptyList()
        }
        audioPollingJob = viewModelScope.launch {
            while (true) {
                val pos = audioPlayer.currentPositionMs()
                val dur = audioPlayer.durationMs()
                val activeIdx = timestamps.indexOfFirst { it.contains(pos) }
                val completed = timestamps.count { it.startMs <= pos }
                _uiState.update {
                    it.copy(
                        audioState = AudioPlaybackState(
                            isPlaying = audioPlayer.isPlaying(),
                            positionMs = pos,
                            durationMs = dur,
                            activeWordIndex = activeIdx,
                            completedWordCount = completed,
                            hasAudio = true,
                            isLoading = false,
                        )
                    )
                }
                if (!audioPlayer.isPlaying()) break
                delay(50L) // ~20Hz polling — smooth enough, low overhead
            }
        }
    }

    private fun checkAndAutoPlayAudio() {
        val ex = orchestrator?.snapshot?.currentExercise ?: return
        if (ex.modality == LearningModality.AUDITORY && ex.audioAssetPath != null) {
            playAudio()
        }
    }

    // ─────────────────────────────────────────────────────────────
    // Favourites
    // ─────────────────────────────────────────────────────────────

    private fun toggleFavourite() {
        val ex = orchestrator?.snapshot?.currentExercise ?: return
        viewModelScope.launch { repo.toggleFavoriteQuestion(ex.id) }
    }

    // ─────────────────────────────────────────────────────────────
    // Data loading from assets
    // ─────────────────────────────────────────────────────────────

    private suspend fun loadSentences(): List<SmartLocalEngine.RawSentence> {
        return try {
            val json = JSONObject(repo.readAssetJsonOnce("sentences_daily_8000_clean_classified_v2.json"))
            val arr = json.getJSONArray("sentences")
            (0 until arr.length()).mapNotNull { i ->
                runCatching {
                    val obj = arr.getJSONObject(i)
                    val sentTopic = obj.optString("topic", "general")
                    // Filter by topic if not "general" or matching
                    if (topic != "general" && sentTopic != topic && sentTopic != "general") return@mapNotNull null
                    SmartLocalEngine.RawSentence(
                        id = obj.getInt("id").toString(),
                        en = obj.getString("en"),
                        ar = obj.getString("ar"),
                        cefr = obj.optString("level", "A1"),
                        topic = sentTopic,
                        complexityScore = obj.optDouble("complexity_score", 0.0).toFloat(),
                    )
                }.getOrNull()
            }
        } catch (t: Throwable) {
            // Fallback: load from data.json (phrase pairs per topic)
            loadPhrasesAsSentences()
        }
    }

    private suspend fun loadPhrasesAsSentences(): List<SmartLocalEngine.RawSentence> {
        return try {
            val json = JSONObject(repo.readAssetJsonOnce("data.json"))
            val arr: JSONArray = json.optJSONArray(topic) ?: return emptyList()
            (0 until arr.length()).mapNotNull { i ->
                runCatching {
                    val obj = arr.getJSONObject(i)
                    SmartLocalEngine.RawSentence(
                        id = obj.getString("id"),
                        en = obj.getString("en"),
                        ar = obj.getString("sp"),
                        cefr = cefr,
                        topic = topic,
                    )
                }.getOrNull()
            }
        } catch (_: Throwable) { emptyList() }
    }

    private suspend fun loadWordPairs(): List<SmartLocalEngine.RawWordPair> {
        return try {
            val json = JSONObject(repo.readAssetJsonOnce("data.json"))
            val arr: JSONArray = json.optJSONArray(topic) ?: return emptyList()
            (0 until arr.length()).mapNotNull { i ->
                runCatching {
                    val obj = arr.getJSONObject(i)
                    SmartLocalEngine.RawWordPair(
                        en = obj.getString("en"),
                        ar = obj.getString("sp"),
                        topic = topic,
                        cefr = cefr,
                    )
                }.getOrNull()
            }
        } catch (_: Throwable) { emptyList() }
    }

    private suspend fun loadAudioHints(
        sentences: List<SmartLocalEngine.RawSentence>,
    ): List<SmartLocalEngine.AudioHint> {
        // Audio hints are optional. Try to find audio_pro content for this topic.
        // If the asset doesn't exist, exercises degrade gracefully (TTS fallback).
        return try {
            val contentJson = JSONObject(repo.readAssetJsonOnce("audio_pro/content_v1.json"))
            val lessonsArr = contentJson.getJSONArray("lessons")
            val sentenceIdSet = sentences.map { it.en.lowercase().trim() }.toSet()
            val result = mutableListOf<SmartLocalEngine.AudioHint>()
            for (i in 0 until lessonsArr.length()) {
                val lessonObj = lessonsArr.getJSONObject(i)
                val itemsArr = lessonObj.getJSONArray("items")
                for (j in 0 until itemsArr.length()) {
                    val itObj = itemsArr.getJSONObject(j)
                    if (!itObj.optBoolean("hasAudio", false)) continue
                    val audio = itObj.optString("audio").trim()
                    if (audio.isBlank()) continue
                    val en = itObj.optString("en").lowercase().trim()
                    if (en !in sentenceIdSet) continue
                    val sentId = sentences.firstOrNull { it.en.lowercase().trim() == en }?.id ?: continue
                    result += SmartLocalEngine.AudioHint(
                        assetPath = "audio_pro/audios/$audio",
                        sentenceId = sentId,
                        wordTimestamps = parseTimestamps(itObj.optJSONArray("wordTimestamps")),
                    )
                }
            }
            result
        } catch (_: Throwable) { emptyList() }
    }

    private fun parseTimestamps(arr: JSONArray?): List<com.emir.englishapp.domain.model.exercise.WordTimestamp> {
        arr ?: return emptyList()
        return (0 until arr.length()).mapNotNull { i ->
            runCatching {
                val obj = arr.getJSONObject(i)
                com.emir.englishapp.domain.model.exercise.WordTimestamp(
                    word = obj.getString("word"),
                    startMs = obj.getLong("startMs"),
                    endMs = obj.getLong("endMs"),
                )
            }.getOrNull()
        }
    }

    // ─────────────────────────────────────────────────────────────
    // Persistence
    // ─────────────────────────────────────────────────────────────

    private fun persistResult(result: SessionOrchestrator.SessionResult) {
        viewModelScope.launch {
            runCatching {
                if (globalIndex > 0) {
                    repo.saveProUnitResult(
                        globalIndex = globalIndex,
                        scorePercent = result.scorePercent,
                        masteryPercent = result.masteryPercent,
                        stars = result.starsAwarded,
                    )
                    repo.addTotalXp(result.totalXpEarned)
                }
            }
        }
    }

    // ─────────────────────────────────────────────────────────────
    // Lifecycle
    // ─────────────────────────────────────────────────────────────

    override fun onCleared() {
        super.onCleared()
        stopAudio()
    }

    // ─────────────────────────────────────────────────────────────
    // Factory
    // ─────────────────────────────────────────────────────────────

    class Factory(
        private val context: Context,
        private val repo: AppRepository,
        private val audioPlayer: AssetAudioPlayer,
        private val topic: String,
        private val cefr: String,
        private val sessionMode: SessionMode,
        private val sessionSize: Int = 10,
        private val moduleTitleEn: String = "",
        private val moduleTitleAr: String = "",
        private val globalIndex: Int = 0,
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return AssessmentViewModel(
                repo = repo,
                audioPlayer = audioPlayer,
                topic = topic,
                cefr = cefr,
                sessionMode = sessionMode,
                sessionSize = sessionSize,
                moduleTitleEn = moduleTitleEn,
                moduleTitleAr = moduleTitleAr,
                globalIndex = globalIndex,
            ) as T
        }
    }
}
