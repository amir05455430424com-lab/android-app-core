package com.emir.englishapp.ui.screens.path

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.emir.englishapp.data.repository.AppRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class PathViewModel(
    private val repo: AppRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(PathUiState())
    val uiState: StateFlow<PathUiState> = _uiState

    private val stepsTotal = 5

    init {
        viewModelScope.launch {
            // Load units ONCE for performance.
            val units = try {
                repo.getAllUnitsFlat().sortedBy { it.globalIndex }
            } catch (t: Throwable) {
                _uiState.update { it.copy(isLoading = false, error = t.message ?: "خطأ في تحميل الكورس") }
                return@launch
            }

            repo.currentUnitGlobalIndex
                .distinctUntilChanged()
                .collect { currentIdx ->
                    val stepMap = runCatching { repo.getUnitStepIndexMap() }.getOrElse { emptyMap() }

                    val uiUnits = units.map { unit ->
                        val stepIdx = (stepMap[unit.globalIndex] ?: 0).coerceIn(0, stepsTotal)
                        val status = when {
                            unit.globalIndex < currentIdx -> UnitStatus.Completed
                            unit.globalIndex == currentIdx -> UnitStatus.Current
                            else -> UnitStatus.Locked
                        }
                        CourseUnitUi(unit = unit, status = status, stepIndex = stepIdx, stepsTotal = stepsTotal)
                    }

                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            error = null,
                            currentUnitGlobalIndex = currentIdx,
                            units = uiUnits
                        )
                    }
                }
        }
    }

    fun setCurrentUnit(globalIndex: Int) {
        // Intentionally left blank (unlock rules are enforced by progress).
    }

}

class PathViewModelFactory(
    private val repo: AppRepository
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        @Suppress("UNCHECKED_CAST")
        return PathViewModel(repo) as T
    }
}
