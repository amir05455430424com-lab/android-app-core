package com.emir.englishapp.ui.screens.propath

import android.view.HapticFeedbackConstants
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.emir.englishapp.ui.screens.path.CourseUnitUi
import com.emir.englishapp.ui.screens.path.UnitStatus
import com.emir.englishapp.ui.theme.Border
import com.emir.englishapp.ui.theme.Locked
import com.emir.englishapp.ui.theme.LockedText
import kotlin.math.sin

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProPathScreen(
    state: ProPathUiState,
    onBack: () -> Unit,
    onUnitClick: (globalIndex: Int) -> Unit
) {
    val completedCount = remember(state.units) {
        state.units.count { it.status == UnitStatus.Completed }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("مسار الـ PRO", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold) },
                navigationIcon = { TextButton(onClick = onBack) { Text("رجوع", style = MaterialTheme.typography.bodyLarge) } },
                actions = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .padding(end = 16.dp)
                            .background(MaterialTheme.colorScheme.secondary.copy(alpha = 0.2f), RoundedCornerShape(12.dp))
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Rounded.Star, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "$completedCount / ${state.units.size}",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.secondary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(vertical = 48.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                items(
                    count = state.units.size,
                    key = { index -> state.units[index].unit.globalIndex }
                ) { index ->
                    val item = state.units[index]
                    val nextItemStatus = state.units.getOrNull(index + 1)?.status ?: UnitStatus.Locked

                    FabulousPathNode(
                        item = item,
                        index = index,
                        isFirst = index == 0,
                        isLast = index == state.units.lastIndex,
                        nextStatus = nextItemStatus,
                        onClick = { if (item.status != UnitStatus.Locked) onUnitClick(item.unit.globalIndex) }
                    )
                }
            }
        }
    }
}

@Composable
private fun FabulousPathNode(
    item: CourseUnitUi,
    index: Int,
    isFirst: Boolean,
    isLast: Boolean,
    nextStatus: UnitStatus,
    onClick: () -> Unit
) {
    val density = LocalDensity.current
    val itemHeight = 130.dp
    val amplitude = 85.dp

    val currentXOffset = remember(index) { sin(index * 0.8f) * amplitude.value }
    val previousXOffset = remember(index) { sin((index - 1) * 0.8f) * amplitude.value }
    val nextXOffset = remember(index) { sin((index + 1) * 0.8f) * amplitude.value }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(130.dp),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier.offset(x = currentXOffset.dp),
            contentAlignment = Alignment.Center
        ) {
            Fabulous3DButton(
                status = item.status,
                label = item.unit.globalIndex.toString(),
                title = item.unit.titleAr,
                onClick = onClick
            )
        }
    }
}

@Composable
private fun Fabulous3DButton(
    status: UnitStatus,
    label: String,
    title: String,
    onClick: () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val view = LocalView.current

    LaunchedEffect(isPressed) {
        if (isPressed && status != UnitStatus.Locked) {
            view.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
        }
    }

    val (topColors, bottomColor) = when (status) {
        UnitStatus.Locked -> listOf(Color(0xFFF0F0F0), Color(0xFFE5E5E5)) to Locked
        UnitStatus.Current -> listOf(MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.primary.copy(alpha = 0.9f)) to MaterialTheme.colorScheme.primary.copy(alpha = 0.8f)
        UnitStatus.Completed -> listOf(MaterialTheme.colorScheme.secondary, MaterialTheme.colorScheme.secondary.copy(alpha = 0.9f)) to Border
    }

    val infiniteTransition = rememberInfiniteTransition(label = "node_animations")
    val scale by infiniteTransition.animateFloat(
        initialValue = 1f, targetValue = if (status == UnitStatus.Current) 1.04f else 1f,
        animationSpec = infiniteRepeatable(tween(1000, easing = EaseInOutSine), RepeatMode.Reverse), label = "scale"
    )
    val bounceY by infiniteTransition.animateFloat(
        initialValue = 0f, targetValue = if (status == UnitStatus.Current) -8f else 0f,
        animationSpec = infiniteRepeatable(tween(600, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "bounce"
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.graphicsLayer {
            scaleX = scale
            scaleY = scale
        }
    ) {
        if (status == UnitStatus.Current) {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                shape = RoundedCornerShape(12.dp),
                shadowElevation = 4.dp,
                modifier = Modifier
                    .graphicsLayer { translationY = bounceY }
                    .padding(bottom = 8.dp)
            ) {
                Text(
                    text = "ابدأ",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Black,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                )
            }
        }

        Box(
            modifier = Modifier
                .size(76.dp)
                .clickable(
                    interactionSource = interactionSource,
                    indication = null,
                    enabled = status != UnitStatus.Locked,
                    onClick = onClick
                ),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clip(CircleShape)
                    .background(bottomColor)
            )

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(bottom = 7.dp)
                    .graphicsLayer { translationY = if (isPressed) 7.dp.toPx() else 0f }
                    .clip(CircleShape)
                    .background(Brush.verticalGradient(topColors)),
                contentAlignment = Alignment.TopCenter
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(24.dp)
                        .clip(RoundedCornerShape(topStart = 38.dp, topEnd = 38.dp, bottomStart = 20.dp, bottomEnd = 20.dp))
                        .background(Brush.verticalGradient(listOf(MaterialTheme.colorScheme.surface.copy(alpha = 0.4f), Color.Transparent)))
                )

                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    when (status) {
                        UnitStatus.Locked -> Icon(Icons.Filled.Lock, contentDescription = null, tint = LockedText, modifier = Modifier.size(30.dp))
                        UnitStatus.Completed -> Icon(Icons.Filled.Check, contentDescription = null, tint = MaterialTheme.colorScheme.surface, modifier = Modifier.size(40.dp))
                        UnitStatus.Current -> Text(text = label, style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.surface, fontWeight = FontWeight.Black)
                    }
                }
            }
        }

        Spacer(Modifier.height(12.dp))

        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            shadowElevation = if (status == UnitStatus.Locked) 0.dp else 4.dp,
            border = if (status == UnitStatus.Locked) BorderStroke(1.dp, Locked) else null,
            modifier = Modifier.padding(horizontal = 8.dp)
        ) {
            Text(
                text = title,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.ExtraBold,
                color = if (status == UnitStatus.Locked) LockedText else MaterialTheme.colorScheme.onSurface
            )
        }
    }
}
