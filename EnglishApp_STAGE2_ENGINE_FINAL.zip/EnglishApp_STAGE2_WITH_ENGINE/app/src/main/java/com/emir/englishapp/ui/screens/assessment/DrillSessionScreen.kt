package com.emir.englishapp.ui.screens.assessment

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.emir.englishapp.domain.engine.SpacedRepetitionScheduler

/**
 * SrsProgressCard — compact widget showing SRS Leitner-box distribution.
 *
 * Displays:
 *  ┌─────────────────────────────────────────────┐
 *  │  جلسة 3  •  212 تمرين مولَّد               │
 *  │  ████░░░░░░░░░░  45% إتقان عام             │
 *  │  ● جديد 80  ● تعلّم 40  ● ناضج 50  ✅12   │
 *  └─────────────────────────────────────────────┘
 */
@Composable
fun SrsProgressCard(
    stats: SpacedRepetitionScheduler.ProgressStats,
    totalGenerated: Int,
    modifier: Modifier = Modifier,
) {
    val animProgress = remember { Animatable(0f) }
    LaunchedEffect(stats.overallAccuracyPercent) {
        animProgress.animateTo(stats.overallAccuracyPercent / 100f, tween(800))
    }

    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        color = Color(0xFFF7F9FC),
        shadowElevation = 2.dp,
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = "جلسة ${stats.sessionIndex}",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFF4B4B4B),
                )
                Text(
                    text = "$totalGenerated تمرين مولَّد",
                    fontSize = 13.sp,
                    color = Color(0xFFAFAFAF),
                )
            }

            // Accuracy progress bar
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Text("الإتقان العام", fontSize = 13.sp, color = Color(0xFFAFAFAF))
                    Text(
                        "${stats.overallAccuracyPercent}%",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = accuracyColor(stats.overallAccuracyPercent),
                    )
                }
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(10.dp)
                        .background(Color(0xFFE5E5E5), RoundedCornerShape(5.dp)),
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(animProgress.value)
                            .height(10.dp)
                            .background(
                                accuracyColor(stats.overallAccuracyPercent),
                                RoundedCornerShape(5.dp),
                            ),
                    )
                }
            }

            // Leitner box distribution
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
            ) {
                LeitnerDot("جديد",     stats.newCount,      Color(0xFF9B59B6))
                LeitnerDot("تعلّم",    stats.learningCount,  Color(0xFFE67E22))
                LeitnerDot("مراجعة",   stats.reviewCount,    Color(0xFF3498DB))
                LeitnerDot("ناضج",     stats.matureCount,    Color(0xFF27AE60))
                LeitnerDot("✅ مُتقَن", stats.masteredCount,  Color(0xFF58CC02))
            }
        }
    }
}

@Composable
private fun LeitnerDot(label: String, count: Int, color: Color) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(3.dp),
    ) {
        Box(
            modifier = Modifier.size(10.dp).background(color, CircleShape),
        )
        Text(count.toString(), fontSize = 13.sp, fontWeight = FontWeight.Bold, color = color)
        Text(label, fontSize = 10.sp, color = Color(0xFFAFAFAF), textAlign = TextAlign.Center)
    }
}

private fun accuracyColor(percent: Int) = when {
    percent >= 80 -> Color(0xFF58CC02)
    percent >= 50 -> Color(0xFFFFC107)
    else          -> Color(0xFFEA2B2B)
}

// ─────────────────────────────────────────────────────────────
// Drill Session Screen (wraps AssessmentScreen with SRS header)
// ─────────────────────────────────────────────────────────────

@Composable
fun DrillSessionScreen(
    viewModel: DrillSessionViewModel,
    onBack: () -> Unit,
    onSessionComplete: (SessionResultUi) -> Unit,
) {
    val state = viewModel.uiState

    // Delegate to standard AssessmentScreen; inject SRS stats via header override
    // The AssessmentScreen is generic — the SRS card is shown on the reward/completion screen.
    // For inline SRS progress, embed SrsProgressCard above the exercise area.

    // Convert DrillSessionUiState → AssessmentUiState for the standard screen
    val assessmentState = androidx.compose.runtime.produceState(
        initialValue = AssessmentUiState(isLoading = true),
        key1 = state,
    ) {
        state.collect { drill ->
            value = AssessmentUiState(
                isLoading = drill.isLoading,
                error = drill.error,
                moduleTitleAr = "تدريب ذكي: ${drill.topic}",
                moduleTitleEn = "Smart Drill: ${drill.topic}",
                topic = drill.topic,
                cefr = drill.cefr,
                snapshot = drill.snapshot,
                audioState = drill.audioState,
                result = drill.result,
                favoriteIds = drill.favoriteIds,
                showExplanation = drill.showExplanation,
            )
        }
    }

    AssessmentScreen(
        // Adapter: wrap DrillSessionViewModel as AssessmentViewModel-compatible
        viewModel = object : AssessmentViewModelAdapter(viewModel) {},
        onBack = onBack,
        onSessionComplete = onSessionComplete,
    )
}

/** Adapter bridge so DrillSessionScreen can reuse AssessmentScreen without duplication. */
abstract class AssessmentViewModelAdapter(
    private val drill: DrillSessionViewModel,
) : androidx.lifecycle.ViewModel() {
    val uiState: StateFlow<AssessmentUiState> get() = _mapped

    private val _mapped = MutableStateFlow(AssessmentUiState(isLoading = true))

    fun onEvent(event: AssessmentEvent) = drill.onEvent(event)

    private val _scope = androidx.lifecycle.viewModelScope

    init {
        _scope.launch {
            drill.uiState.collect { d ->
                _mapped.value = AssessmentUiState(
                    isLoading = d.isLoading,
                    error = d.error,
                    moduleTitleAr = "تدريب ذكي — ${d.totalGenerated} تمرين",
                    topic = d.topic,
                    cefr = d.cefr,
                    snapshot = d.snapshot,
                    audioState = d.audioState,
                    result = d.result,
                    favoriteIds = d.favoriteIds,
                    showExplanation = d.showExplanation,
                )
            }
        }
    }
}

private typealias StateFlow<T> = kotlinx.coroutines.flow.StateFlow<T>
private typealias MutableStateFlow<T> = kotlinx.coroutines.flow.MutableStateFlow<T>
private val androidx.lifecycle.ViewModel.viewModelScope
    get() = androidx.lifecycle.viewModelScope
