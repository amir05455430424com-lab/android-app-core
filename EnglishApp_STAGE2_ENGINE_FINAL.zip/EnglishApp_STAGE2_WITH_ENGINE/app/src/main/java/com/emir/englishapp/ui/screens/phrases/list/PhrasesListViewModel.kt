package com.emir.englishapp.ui.screens.phrases.list

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.emir.englishapp.data.repository.AppRepository
import com.emir.englishapp.domain.audio.AssetAudioPlayer
import com.emir.englishapp.domain.model.PhraseItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class PhrasesListViewModel(
    private val repo: AppRepository,
    private val audioPlayer: AssetAudioPlayer,
    private val categoryKey: String
) : ViewModel() {

    private val _uiState = MutableStateFlow(PhrasesListUiState(categoryKey = categoryKey))
    val uiState: StateFlow<PhrasesListUiState> = _uiState.asStateFlow()

    init {
        load()
    }

    private fun load() {
        viewModelScope.launch {
            _uiState.value = PhrasesListUiState(isLoading = true, categoryKey = categoryKey)
            runCatching {
                val phrases = repo.getPhrasesForCategory(categoryKey)
                val fav = repo.favoritePhraseIds.first()
                Pair(phrases, fav)
            }.onSuccess { (list, fav) ->
                _uiState.value = PhrasesListUiState(
                    isLoading = false,
                    categoryKey = categoryKey,
                    phrases = list,
                    favoritePhraseIds = fav
                )
            }.onFailure { e ->
                _uiState.value = PhrasesListUiState(
                    isLoading = false,
                    categoryKey = categoryKey,
                    errorMessage = e.message ?: "Error loading phrases"
                )
            }
        }
    }

    fun toggleFavorite(item: PhraseItem) {
        viewModelScope.launch {
            repo.toggleFavoritePhrase(item.id.toString())
            val fav = repo.favoritePhraseIds.first()
            _uiState.value = _uiState.value.copy(favoritePhraseIds = fav)
        }
    }

    fun playEnglish(item: PhraseItem) {
        if (item.id > 0) audioPlayer.play("sounds/e${item.id}.mp3")
    }

    fun playArabic(item: PhraseItem) {
        if (item.id > 0) audioPlayer.play("sounds/a${item.id}.mp3")
    }
}
