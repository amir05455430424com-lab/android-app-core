package com.emir.englishapp.ui.screens.daily

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun DailyStudyScreen(
    state: DailyStudyUiState,
    onBack: () -> Unit,
    onFinishStudy: (globalIndex: Int) -> Unit,
    onSelectOption: (index: Int) -> Unit,
    onNext: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(onClick = onBack) { Text("رجوع") }
            Text("📚 جلسة اليوم", style = MaterialTheme.typography.titleLarge)
        }

        if (state.isLoading) {
            Text("تحميل...", style = MaterialTheme.typography.bodyMedium)
            return
        }
        state.error?.let {
            Text(it, style = MaterialTheme.typography.bodyMedium)
            return
        }

        Text(state.unitTitleEn, style = MaterialTheme.typography.titleMedium)
        Text(state.unitTitleAr, style = MaterialTheme.typography.bodyMedium)

        if (state.isFinished) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("✅ انتهت جلسة اليوم!", style = MaterialTheme.typography.titleMedium)
                    Text("جاهز الآن لاختبار سريع.", style = MaterialTheme.typography.bodyMedium)
                    Button(onClick = { onFinishStudy(state.globalIndex) }, modifier = Modifier.fillMaxWidth()) {
                        Text("ابدأ التحدي")
                    }
                }
            }
            return
        }

        val q = state.current

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("سؤال", style = MaterialTheme.typography.labelLarge)
                val prompt = q?.promptEn.orEmpty().ifBlank { q?.promptAr.orEmpty() }
                Text(prompt, style = MaterialTheme.typography.titleMedium)

                Spacer(Modifier.height(4.dp))

                val options = when {
                    q == null -> emptyList()
                    q.optionsAr.isNotEmpty() -> q.optionsAr
                    !q.optionsEn.isNullOrEmpty() -> q.optionsEn
                    else -> emptyList()
                }
                options.forEachIndexed { idx, opt ->
                    val prefix = when {
                        !state.isAnswered -> "• "
                        idx == q?.answerIndex -> "✅ "
                        idx == state.selectedIndex && state.isCorrect == false -> "❌ "
                        else -> "• "
                    }

                    OutlinedButton(
                        onClick = { onSelectOption(idx) },
                        enabled = !state.isAnswered,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(prefix + opt, style = MaterialTheme.typography.bodyLarge)
                    }
                }

                if (state.isAnswered) {
                    Spacer(Modifier.height(6.dp))
                    val correctText = if (state.isCorrect == true) "إجابة صحيحة ✅" else "إجابة خاطئة ❌"
                    Text(correctText, style = MaterialTheme.typography.titleSmall)
                    if (!q?.explanationAr.isNullOrBlank()) {
                        Text(q?.explanationAr.orEmpty(), style = MaterialTheme.typography.bodyMedium)
                    }
                }

                // Force LTR so the fraction does not get visually reversed in RTL layout
                val fraction = "\u200E${state.index + 1}/${state.questions.size}\u200E"
                Text(fraction, style = MaterialTheme.typography.bodySmall)
            }
        }

        Spacer(Modifier.height(6.dp))

        Button(
            onClick = onNext,
            enabled = state.isAnswered,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("التالي")
        }
    }
}