package com.emir.englishapp.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.emir.englishapp.EnglishApp
import com.emir.englishapp.ui.screens.home.HomeScreen
import com.emir.englishapp.ui.screens.home.HomeViewModel
import com.emir.englishapp.ui.screens.home.HomeViewModelFactory
import com.emir.englishapp.ui.screens.favorites.FavoritesScreen
import com.emir.englishapp.ui.screens.favorites.FavoritesViewModel
import com.emir.englishapp.ui.screens.favorites.FavoritesViewModelFactory
import com.emir.englishapp.ui.screens.phrases.categories.PhraseCategoriesScreen
import com.emir.englishapp.ui.screens.phrases.categories.PhraseCategoriesViewModel
import com.emir.englishapp.ui.screens.phrases.categories.PhraseCategoriesViewModelFactory
import com.emir.englishapp.ui.screens.phrases.list.PhrasesListScreen
import com.emir.englishapp.ui.screens.phrases.list.PhrasesListViewModel
import com.emir.englishapp.ui.screens.phrases.list.PhrasesListViewModelFactory
import com.emir.englishapp.ui.screens.phrases.quiz.ListeningQuizScreen
import com.emir.englishapp.ui.screens.phrases.quiz.ListeningQuizViewModel
import com.emir.englishapp.ui.screens.phrases.quiz.ListeningQuizViewModelFactory
import com.emir.englishapp.ui.screens.daily.*
import com.emir.englishapp.ui.screens.unitlesson.*
import com.emir.englishapp.ui.screens.path.PathScreen
import com.emir.englishapp.ui.screens.path.PathViewModel
import com.emir.englishapp.ui.screens.path.PathViewModelFactory
import com.emir.englishapp.ui.screens.propath.ProPathScreen
import com.emir.englishapp.ui.screens.propath.ProPathViewModel
import com.emir.englishapp.ui.screens.propath.ProPathViewModelFactory
import com.emir.englishapp.ui.screens.proquestion.ProQuestionEvent
import com.emir.englishapp.ui.screens.proquestion.ProQuestionScreen
import com.emir.englishapp.ui.screens.proquestion.ProQuestionViewModel
import com.emir.englishapp.ui.screens.proquestion.ProQuestionViewModelFactory
import com.emir.englishapp.ui.screens.lessons.levels.LevelPickerScreen
import com.emir.englishapp.ui.screens.lessons.levels.LevelPickerViewModel
import com.emir.englishapp.ui.screens.lessons.levels.LevelPickerViewModelFactory
import com.emir.englishapp.ui.screens.lessons.level.LevelScreen
import com.emir.englishapp.ui.screens.lessons.level.LevelViewModel
import com.emir.englishapp.ui.screens.lessons.level.LevelViewModelFactory
import com.emir.englishapp.ui.screens.lessons.lesson.LessonScreen
import com.emir.englishapp.ui.screens.lessons.practice.LessonPracticeScreen
import com.emir.englishapp.ui.screens.lessons.lesson.LessonViewModel
import com.emir.englishapp.ui.screens.lessons.lesson.LessonViewModelFactory
import com.emir.englishapp.ui.navigation.PlaceholderScreen
import com.emir.englishapp.ui.screens.audiopro.AudioProScreen
import com.emir.englishapp.ui.screens.audiopro.AudioProViewModel
import com.emir.englishapp.ui.screens.audiopro.AudioProViewModelFactory

// ── Smart Assessment Engine ──────────────────────────────────
import com.emir.englishapp.ui.screens.assessment.AssessmentRewardScreen
import com.emir.englishapp.ui.screens.assessment.AssessmentScreen
import com.emir.englishapp.ui.screens.assessment.AssessmentViewModel
import com.emir.englishapp.ui.screens.assessment.SessionMode
import com.emir.englishapp.ui.screens.assessment.SessionResultUi

@Composable
fun AppNavHost(
    navController: NavHostController,
    startDestination: String = Routes.HOME
) {
    val context = LocalContext.current
    val app = context.applicationContext as EnglishApp
    val repo = app.container.repository
    val audioPlayer = app.container.audioPlayer

    NavHost(
        navController = navController,
        startDestination = startDestination
    ) {
        composable(Routes.FAVORITES) {
            val vm: FavoritesViewModel = viewModel(factory = FavoritesViewModelFactory(repo))
            val state by vm.uiState.collectAsState()
            FavoritesScreen(
                state = state,
                onToggleQuestionFavorite = vm::toggleFavorite,
                onTogglePhraseFavorite = vm::togglePhraseFavorite,
                onToggleLessonFavorite = vm::toggleLessonFavorite
            )
        }

        composable(Routes.SETTINGS) {
            PlaceholderScreen(title = "⚙️ الإعدادات (قريبًا)")
        }

        composable(Routes.HOME) {
            val vm: HomeViewModel = viewModel(factory = HomeViewModelFactory(repo))
            val state by vm.uiState.collectAsState()

            HomeScreen(
                state = state,
                onOneMinuteSession = { navController.navigate("pro/unit/lesson/${state.currentUnitIndex}/0?mode=daily") },
                onOpenAudioPro = { navController.navigate(Routes.AUDIO_PRO) },
                onOpenLessons = { navController.navigate(Routes.LESSONS) },
                onOpenPhrases = { navController.navigate(Routes.PHRASES_CATEGORIES) },
                onOpenProPath = { navController.navigate(Routes.PRO_PATH) },
                onRefresh = vm::refreshDailyState
            )
        }

        composable(Routes.AUDIO_PRO) {
            val vm: AudioProViewModel = viewModel(factory = AudioProViewModelFactory(repo))
            val state by vm.uiState.collectAsState()

            AudioProScreen(
                state = state,
                onBack = { navController.popBackStack() },
                onToggleFavorite = vm::toggleFavoriteCurrent,
                onEvent = vm::onEvent,
                onNext = {
                    vm.next { done ->
                        if (done) navController.popBackStack()
                    }
                },
                onPlayAudio = { path -> audioPlayer.play(path) },
                currentAudioPath = vm.currentAudioPath,
                onStartMode = vm::start
            )
        }

        // =========================================================
        // SMART ASSESSMENT ENGINE — Dynamic Offline Assessment
        // =========================================================

        /**
         * Assessment session screen.
         *
         * Route: assessment/{topic}/{cefr}/{mode}/{size}/{globalIndex}
         *
         * Example navigations from anywhere in the app:
         *   navController.navigate(Routes.assessmentRoute("family", "A1", "mixed", 10))
         *   navController.navigate(Routes.assessmentRoute("food", "B1", "auditory", 15))
         */
        composable(
            route = Routes.ASSESSMENT_PATTERN,
            arguments = listOf(
                navArgument("topic")       { type = NavType.StringType },
                navArgument("cefr")        { type = NavType.StringType },
                navArgument("mode")        { type = NavType.StringType },
                navArgument("size")        { type = NavType.IntType },
                navArgument("globalIndex") { type = NavType.IntType },
            )
        ) { entry ->
            val topic       = entry.arguments?.getString("topic") ?: "general"
            val cefr        = entry.arguments?.getString("cefr") ?: "A1"
            val modeStr     = entry.arguments?.getString("mode") ?: "mixed"
            val size        = entry.arguments?.getInt("size") ?: 10
            val globalIndex = entry.arguments?.getInt("globalIndex") ?: 0

            val sessionMode = when (modeStr.lowercase()) {
                "visual"   -> SessionMode.VISUAL
                "auditory" -> SessionMode.AUDITORY
                "kinetic"  -> SessionMode.KINETIC
                "review"   -> SessionMode.REVIEW
                else       -> SessionMode.MIXED
            }

            val vm: AssessmentViewModel = viewModel(
                factory = AssessmentViewModel.Factory(
                    context     = context,
                    repo        = repo,
                    audioPlayer = audioPlayer,
                    topic       = topic,
                    cefr        = cefr,
                    sessionMode = sessionMode,
                    sessionSize = size,
                    globalIndex = globalIndex,
                )
            )

            AssessmentScreen(
                viewModel = vm,
                onBack = { navController.popBackStack() },
                onSessionComplete = { result: SessionResultUi ->
                    // Navigate to reward screen passing all result data
                    val rewardRoute = Routes.assessmentRewardRoute(
                        topic    = topic,
                        cefr     = cefr,
                        mode     = modeStr,
                        score    = result.scorePercent,
                        mastery  = result.masteryPercent,
                        stars    = result.starsAwarded,
                        correct  = result.correctCount,
                        total    = result.totalCount,
                        xp       = result.totalXpEarned,
                        timeMs   = result.totalTimeMs,
                    )
                    navController.navigate(rewardRoute) {
                        // Remove the session screen from backstack so Back → previous screen
                        popUpTo(Routes.assessmentRoute(topic, cefr, modeStr, size, globalIndex)) {
                            inclusive = true
                        }
                    }
                }
            )
        }

        /**
         * Assessment reward screen.
         *
         * Route: assessment/reward/{topic}/{cefr}/{mode}/{score}/{mastery}
         *        /{stars}/{correct}/{total}/{xp}/{timeMs}
         */
        composable(
            route = Routes.ASSESSMENT_REWARD_PATTERN,
            arguments = listOf(
                navArgument("topic")   { type = NavType.StringType },
                navArgument("cefr")    { type = NavType.StringType },
                navArgument("mode")    { type = NavType.StringType },
                navArgument("score")   { type = NavType.IntType },
                navArgument("mastery") { type = NavType.IntType },
                navArgument("stars")   { type = NavType.IntType },
                navArgument("correct") { type = NavType.IntType },
                navArgument("total")   { type = NavType.IntType },
                navArgument("xp")      { type = NavType.IntType },
                navArgument("timeMs")  { type = NavType.LongType },
            )
        ) { entry ->
            val topic   = entry.arguments?.getString("topic") ?: "general"
            val cefr    = entry.arguments?.getString("cefr") ?: "A1"
            val modeStr = entry.arguments?.getString("mode") ?: "mixed"
            val score   = entry.arguments?.getInt("score") ?: 0
            val mastery = entry.arguments?.getInt("mastery") ?: 0
            val stars   = entry.arguments?.getInt("stars") ?: 0
            val correct = entry.arguments?.getInt("correct") ?: 0
            val total   = entry.arguments?.getInt("total") ?: 0
            val xp      = entry.arguments?.getInt("xp") ?: 0
            val timeMs  = entry.arguments?.getLong("timeMs") ?: 0L

            AssessmentRewardScreen(
                result = SessionResultUi(
                    scorePercent      = score,
                    masteryPercent    = mastery,
                    starsAwarded      = stars,
                    totalXpEarned     = xp,
                    correctCount      = correct,
                    totalCount        = total,
                    totalTimeMs       = timeMs,
                    incorrectExercises = emptyList(),
                ),
                onContinue = {
                    // Pop back to wherever the user came from (Pro Path, Home, etc.)
                    navController.popBackStack()
                },
                onRetry = {
                    navController.navigate(
                        Routes.assessmentRoute(topic, cefr, modeStr)
                    ) {
                        popUpTo(Routes.ASSESSMENT_REWARD_PATTERN) { inclusive = true }
                    }
                }
            )
        }

        // =========================================================
        // Daily Session (Stage 4.1)
        // =========================================================

        composable(Routes.DAILY_START) {
            val vm: DailyStartViewModel = viewModel(factory = DailyStartViewModelFactory(repo))
            val state by vm.uiState.collectAsState()
            DailyStartScreen(
                state = state,
                onBack = { navController.popBackStack() },
                onStart = { globalIndex ->
                    navController.navigate("unit/lesson/$globalIndex/0")
                }
            )
        }

        composable(
            route = Routes.DAILY_STUDY_PATTERN,
            arguments = listOf(navArgument("globalIndex") { type = NavType.IntType })
        ) { entry ->
            val globalIndex = entry.arguments?.getInt("globalIndex") ?: 1
            val vm: DailyStudyViewModel = viewModel(factory = DailyStudyViewModelFactory(repo, globalIndex))
            val state by vm.uiState.collectAsState()
            DailyStudyScreen(
                state = state,
                onBack = { navController.popBackStack() },
                onFinishStudy = { idx -> navController.navigate("daily/challenge/$idx") },
                onSelectOption = vm::selectOption,
                onNext = vm::next
            )
        }

        composable(
            route = Routes.DAILY_CHALLENGE_PATTERN,
            arguments = listOf(navArgument("globalIndex") { type = NavType.IntType })
        ) { entry ->
            val globalIndex = entry.arguments?.getInt("globalIndex") ?: 1
            val vm: DailyChallengeViewModel = viewModel(factory = DailyChallengeViewModelFactory(repo, globalIndex))
            val state by vm.uiState.collectAsState()
            DailyChallengeScreen(
                state = state,
                onBack = { navController.popBackStack() },
                onSelect = vm::select,
                onToggleFavorite = vm::toggleFavoriteCurrent,
                onNext = {
                    vm.next { result ->
                        navController.navigate(
                            "daily/reward/${result.globalIndex}/${result.scorePercent}/${result.masteryPercent}/${result.stars}/${result.correct}/${result.total}/${result.xpEarned}/${if (result.unlockedNext) 1 else 0}"
                        )
                    }
                }
            )
        }

        composable(
            route = Routes.DAILY_REWARD_PATTERN,
            arguments = listOf(
                navArgument("globalIndex") { type = NavType.IntType },
                navArgument("score")       { type = NavType.IntType },
                navArgument("mastery")     { type = NavType.IntType },
                navArgument("stars")       { type = NavType.IntType },
                navArgument("correct")     { type = NavType.IntType },
                navArgument("total")       { type = NavType.IntType },
                navArgument("xp")          { type = NavType.IntType },
                navArgument("unlocked")    { type = NavType.IntType }
            )
        ) { entry ->
            DailyRewardScreen(
                globalIndex    = entry.arguments?.getInt("globalIndex") ?: 1,
                scorePercent   = entry.arguments?.getInt("score") ?: 0,
                masteryPercent = entry.arguments?.getInt("mastery") ?: 0,
                stars          = entry.arguments?.getInt("stars") ?: 0,
                correct        = entry.arguments?.getInt("correct") ?: 0,
                total          = entry.arguments?.getInt("total") ?: 0,
                xp             = entry.arguments?.getInt("xp") ?: 0,
                unlockedNext   = (entry.arguments?.getInt("unlocked") ?: 0) == 1,
                onBackHome     = { navController.navigate(Routes.HOME) { popUpTo(Routes.HOME) { inclusive = true } } },
                onOpenPath     = { navController.navigate(Routes.PATH) }
            )
        }

        // =========================================================
        // Unit Lesson (Stage 4.3)
        // =========================================================

        composable(
            route = Routes.UNIT_LESSON_PATTERN,
            arguments = listOf(
                navArgument("globalIndex") { type = NavType.IntType },
                navArgument("step")        { type = NavType.IntType }
            )
        ) { entry ->
            val globalIndex = entry.arguments?.getInt("globalIndex") ?: 1
            val step = entry.arguments?.getInt("step") ?: 0
            val vm: UnitLessonViewModel = viewModel(factory = UnitLessonViewModelFactory(repo, globalIndex, step))
            val state by vm.uiState.collectAsState()
            UnitLessonScreen(
                state = state,
                onBack = { navController.popBackStack() },
                onSelect = vm::select,
                onToggleFavorite = vm::toggleFavoriteCurrent,
                onNext = {
                    vm.next { result ->
                        navController.navigate(
                            "unit/reward/${result.globalIndex}/${result.stepIndex}/${result.stepsTotal}/${result.scorePercent}/${result.masteryPercent}/${result.stars}/${result.correct}/${result.total}/${result.xpEarned}/${if (result.unlockedNext) 1 else 0}/${if (result.isFinal) 1 else 0}"
                        )
                    }
                }
            )
        }

        composable(
            route = Routes.UNIT_REWARD_PATTERN,
            arguments = listOf(
                navArgument("globalIndex") { type = NavType.IntType },
                navArgument("step")        { type = NavType.IntType },
                navArgument("stepsTotal")  { type = NavType.IntType },
                navArgument("score")       { type = NavType.IntType },
                navArgument("mastery")     { type = NavType.IntType },
                navArgument("stars")       { type = NavType.IntType },
                navArgument("correct")     { type = NavType.IntType },
                navArgument("total")       { type = NavType.IntType },
                navArgument("xp")          { type = NavType.IntType },
                navArgument("unlocked")    { type = NavType.IntType },
                navArgument("isFinal")     { type = NavType.IntType }
            )
        ) { entry ->
            val step       = entry.arguments?.getInt("step") ?: 0
            val stepsTotal = entry.arguments?.getInt("stepsTotal") ?: 5
            val globalIndex = entry.arguments?.getInt("globalIndex") ?: 1
            UnitRewardScreen(
                globalIndex    = globalIndex,
                stepIndex      = step,
                stepsTotal     = stepsTotal,
                scorePercent   = entry.arguments?.getInt("score") ?: 0,
                masteryPercent = entry.arguments?.getInt("mastery") ?: 0,
                stars          = entry.arguments?.getInt("stars") ?: 0,
                correct        = entry.arguments?.getInt("correct") ?: 0,
                total          = entry.arguments?.getInt("total") ?: 0,
                xp             = entry.arguments?.getInt("xp") ?: 0,
                unlockedNext   = (entry.arguments?.getInt("unlocked") ?: 0) == 1,
                isFinal        = (entry.arguments?.getInt("isFinal") ?: 0) == 1,
                onBackToPath   = { navController.navigate(Routes.PATH) },
                onNextStep     = {
                    val next = (step + 1).coerceAtMost(stepsTotal - 1)
                    navController.navigate("unit/lesson/$globalIndex/$next")
                }
            )
        }

        // =========================================================
        // Lessons (Stage 3)
        // =========================================================

        composable(Routes.LESSONS) {
            val vm: LevelPickerViewModel = viewModel(factory = LevelPickerViewModelFactory(repo))
            LevelPickerScreen(
                viewModel = vm,
                onOpenLevel = { levelId -> navController.navigate("lessons/level/$levelId") }
            )
        }

        composable(
            route = Routes.LEVELS_PATTERN,
            arguments = listOf(navArgument("levelId") { type = NavType.IntType })
        ) { backStackEntry ->
            val levelId = backStackEntry.arguments?.getInt("levelId") ?: 1
            val vm: LevelViewModel = viewModel(factory = LevelViewModelFactory(repo, levelId))
            LevelScreen(
                viewModel = vm,
                onBack = { navController.popBackStack() },
                onOpenLesson = { lessonId -> navController.navigate("lessons/level/$levelId/lesson/$lessonId") }
            )
        }

        composable(
            route = Routes.LESSON_PATTERN,
            arguments = listOf(
                navArgument("levelId")  { type = NavType.IntType },
                navArgument("lessonId") { type = NavType.StringType }
            )
        ) { backStackEntry ->
            val levelId  = backStackEntry.arguments?.getInt("levelId") ?: 1
            val lessonId = backStackEntry.arguments?.getString("lessonId") ?: ""
            val vm: LessonViewModel = viewModel(factory = LessonViewModelFactory(repo, levelId, lessonId))
            LessonScreen(
                viewModel = vm,
                onBack = { navController.popBackStack() },
                onStartPractice = { lId, lid -> navController.navigate("lessons/practice/$lId/$lid") }
            )
        }

        composable(
            route = Routes.LESSON_PRACTICE_PATTERN,
            arguments = listOf(
                navArgument("levelId")  { type = NavType.IntType },
                navArgument("lessonId") { type = NavType.StringType }
            )
        ) { backStackEntry ->
            val levelId  = backStackEntry.arguments?.getInt("levelId") ?: 1
            val lessonId = backStackEntry.arguments?.getString("lessonId") ?: ""
            LessonPracticeScreen(
                levelId  = levelId,
                lessonId = lessonId,
                onBack   = { navController.popBackStack() }
            )
        }

        // =========================================================
        // Phrases (Stage 2)
        // =========================================================

        composable(Routes.PHRASES_CATEGORIES) {
            val vm: PhraseCategoriesViewModel = viewModel(factory = PhraseCategoriesViewModelFactory(repo))
            val state by vm.uiState.collectAsState()
            PhraseCategoriesScreen(
                state = state,
                onBack = { navController.popBackStack() },
                onCategoryClick = { key ->
                    if (key == "__MIXED__" || key == "random")
                        navController.navigate("phrases/quiz/__MIXED__")
                    else
                        navController.navigate("phrases/list/$key")
                }
            )
        }

        composable(
            route = Routes.PHRASES_LIST_PATTERN,
            arguments = listOf(navArgument("categoryKey") { type = NavType.StringType })
        ) { entry ->
            val categoryKey = entry.arguments?.getString("categoryKey").orEmpty()
            val vm: PhrasesListViewModel = viewModel(factory = PhrasesListViewModelFactory(repo, audioPlayer, categoryKey))
            val state by vm.uiState.collectAsState()
            PhrasesListScreen(
                state = state,
                onBack = { navController.popBackStack() },
                onPlayEn = vm::playEnglish,
                onPlayAr = vm::playArabic,
                onToggleFavorite = vm::toggleFavorite,
                onOpenQuiz = { navController.navigate("phrases/quiz/$categoryKey") }
            )
        }

        composable(
            route = Routes.PHRASES_QUIZ_PATTERN,
            arguments = listOf(navArgument("categoryKey") { type = NavType.StringType })
        ) { entry ->
            val categoryKey = entry.arguments?.getString("categoryKey").orEmpty()
            val vm: ListeningQuizViewModel = viewModel(factory = ListeningQuizViewModelFactory(repo, audioPlayer, categoryKey))
            val state by vm.uiState.collectAsState()
            ListeningQuizScreen(
                state = state,
                onBack = { navController.popBackStack() },
                onPlay = vm::playQuestionAudio,
                onSelectAnswer = vm::selectAnswer,
                onNext = vm::nextQuestion,
                onRestart = vm::restart
            )
        }

        // =========================================================
        // Pro Path (100 units)
        // =========================================================

        composable(Routes.PRO_PATH) {
            val vm: ProPathViewModel = viewModel(factory = ProPathViewModelFactory(repo))
            val state by vm.uiState.collectAsState()
            ProPathScreen(
                state = state,
                onBack = { navController.popBackStack() },
                onUnitClick = { globalIndex ->
                    navController.navigate("pro/unit/lesson/$globalIndex/0")
                }
            )
        }

        composable(
            route = Routes.PRO_UNIT_LESSON_PATTERN,
            arguments = listOf(
                navArgument("globalIndex") { type = NavType.IntType },
                navArgument("step")        { type = NavType.IntType },
                navArgument("mode")        { type = NavType.StringType; defaultValue = "pro" }
            )
        ) { backStackEntry ->
            val globalIndex = backStackEntry.arguments?.getInt("globalIndex") ?: 1
            val step = backStackEntry.arguments?.getInt("step") ?: 0
            val mode = backStackEntry.arguments?.getString("mode") ?: "pro"
            val vm: ProQuestionViewModel = viewModel(factory = ProQuestionViewModelFactory(repo, globalIndex, step, mode))
            val state by vm.uiState.collectAsState()
            ProQuestionScreen(
                state = state,
                onBack = { navController.popBackStack() },
                onToggleFavorite = vm::toggleFavoriteCurrent,
                onEvent = { ev -> vm.onEvent(ev) },
                onNext = {
                    vm.onEvent(ProQuestionEvent.Next) { result ->
                        navController.navigate(
                            "pro/unit/reward/${result.globalIndex}/${result.stepIndex}/${result.stepsTotal}/${result.scorePercent}/${result.masteryPercent}/${result.stars}/${result.correct}/${result.total}/${result.xpEarned}/${result.unlockedNext}/${result.isFinal}?mode=$mode"
                        )
                    }
                }
            )
        }

        composable(
            route = Routes.PRO_UNIT_REWARD_PATTERN,
            arguments = listOf(
                navArgument("globalIndex") { type = NavType.IntType },
                navArgument("step")        { type = NavType.IntType },
                navArgument("stepsTotal")  { type = NavType.IntType },
                navArgument("score")       { type = NavType.IntType },
                navArgument("mastery")     { type = NavType.IntType },
                navArgument("stars")       { type = NavType.IntType },
                navArgument("correct")     { type = NavType.IntType },
                navArgument("total")       { type = NavType.IntType },
                navArgument("xp")          { type = NavType.IntType },
                navArgument("unlocked")    { type = NavType.BoolType },
                navArgument("isFinal")     { type = NavType.BoolType },
                navArgument("mode")        { type = NavType.StringType; defaultValue = "pro" }
            )
        ) { backStackEntry ->
            val step        = backStackEntry.arguments?.getInt("step") ?: 0
            val stepsTotal  = backStackEntry.arguments?.getInt("stepsTotal") ?: 5
            val globalIndex = backStackEntry.arguments?.getInt("globalIndex") ?: 1
            val mode        = backStackEntry.arguments?.getString("mode") ?: "pro"
            UnitRewardScreen(
                globalIndex    = globalIndex,
                stepIndex      = step,
                stepsTotal     = stepsTotal,
                scorePercent   = backStackEntry.arguments?.getInt("score") ?: 0,
                masteryPercent = backStackEntry.arguments?.getInt("mastery") ?: 0,
                stars          = backStackEntry.arguments?.getInt("stars") ?: 0,
                correct        = backStackEntry.arguments?.getInt("correct") ?: 0,
                total          = backStackEntry.arguments?.getInt("total") ?: 0,
                xp             = backStackEntry.arguments?.getInt("xp") ?: 0,
                unlockedNext   = backStackEntry.arguments?.getBoolean("unlocked") ?: false,
                isFinal        = backStackEntry.arguments?.getBoolean("isFinal") ?: false,
                onBackToPath   = {
                    if (mode == "daily") navController.navigate(Routes.HOME)
                    else navController.navigate(Routes.PRO_PATH)
                },
                onNextStep = {
                    val nextStep = (step + 1).coerceAtMost(stepsTotal - 1)
                    navController.navigate("pro/unit/lesson/$globalIndex/$nextStep?mode=$mode")
                }
            )
        }

        // =========================================================
        // Main Path
        // =========================================================

        composable(Routes.PATH) {
            val vm: PathViewModel = viewModel(factory = PathViewModelFactory(repo))
            val state by vm.uiState.collectAsState()
            PathScreen(
                state = state,
                onBack = { navController.popBackStack() },
                onUnitClick = { globalIndex ->
                    navController.navigate("unit/lesson/$globalIndex/0")
                }
            )
        }
    }
}
