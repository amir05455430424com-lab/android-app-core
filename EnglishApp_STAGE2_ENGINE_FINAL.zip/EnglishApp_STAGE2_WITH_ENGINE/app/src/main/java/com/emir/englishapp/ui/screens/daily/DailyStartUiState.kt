package com.emir.englishapp.ui.screens.daily

data class DailyStartUiState(
    val isLoading: Boolean = true,
    val error: String? = null,
    val today: String = "",
    val isDoneToday: Boolean = false,
    val currentGlobalIndex: Int = 1,
    val unitTitleAr: String = "",
    val unitTitleEn: String = "",
    val xpReward: Int = 0
)
