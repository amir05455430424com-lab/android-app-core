package com.emir.englishapp.domain.model.lesson

data class LevelMeta(
    val id: Int,
    val titleAr: String,
    val titleEn: String,
    val assetFile: String
)

data class LessonLevel(
    val levelId: Int,
    val titleAr: String,
    val titleEn: String,
    val units: List<UnitBlock>
)

data class UnitBlock(
    val unitId: String,
    val titleAr: String,
    val titleEn: String,
    val lessons: List<LessonItem>
)

data class LessonItem(
    val lessonId: String,
    val titleAr: String,
    val titleEn: String,
    val cards: List<CardItem>
)

data class CardItem(
    val type: String = "",
    val text: String? = null,
    val formula: String? = null,
    val notesEn: String? = null,
    val items: List<LessonExampleItem>? = null,
    val bullets: List<String>? = null,
    val textEn: String? = null
)

data class LessonExampleItem(
    val en: String? = null,
    val ar: String? = null
)
