package com.emir.englishapp.data.repository

import com.emir.englishapp.data.local.AssetsDataSource
import com.emir.englishapp.data.local.UserProgressStore
import com.emir.englishapp.domain.model.PhraseCategory
import com.emir.englishapp.domain.model.PhraseItem
import com.emir.englishapp.domain.model.course.CourseCurriculum
import com.emir.englishapp.domain.model.course.CourseLevel
import com.emir.englishapp.domain.model.course.CourseMeta
import com.emir.englishapp.domain.model.course.CourseUnit
import com.emir.englishapp.domain.model.course.PathStyle
import com.emir.englishapp.domain.model.daily.DailySummary
import com.emir.englishapp.domain.model.lesson.CardItem
import com.emir.englishapp.domain.model.lesson.LevelMeta
import com.emir.englishapp.domain.model.lesson.LessonExampleItem
import com.emir.englishapp.domain.model.lesson.LessonItem
import com.emir.englishapp.domain.model.lesson.LessonLevel
import com.emir.englishapp.domain.model.lesson.UnitBlock
import com.emir.englishapp.domain.model.question.Question
import kotlinx.coroutines.flow.Flow
import org.json.JSONArray
import org.json.JSONObject

class AppRepositoryImpl(
    private val progressStore: UserProgressStore,
    private val assets: AssetsDataSource
) : AppRepository {

    
    private fun JSONObject.optStringOrNull(key: String): String? =
        optString(key, "").takeIf { it.isNotBlank() }

override val momentum: Flow<Int> = progressStore.momentum
    override val currentUnitGlobalIndex: Flow<Int> = progressStore.currentUnitGlobalIndex
    override val proCurrentUnitGlobalIndex: Flow<Int> = progressStore.proCurrentUnitGlobalIndex

    override val totalXp: Flow<Int> = progressStore.totalXp
    override val dailyXpToday: Flow<Int> = progressStore.dailyXpToday
    override val streakDays: Flow<Int> = progressStore.streakDays

    override val favoriteQuestionIds: Flow<Set<String>> = progressStore.favoriteQuestionIds
    override val favoritePhraseIds: Flow<Set<String>> = progressStore.favoritePhraseIds
    override val favoriteLessonIds: Flow<Set<String>> = progressStore.favoriteLessonIds

    override suspend fun toggleFavoriteQuestion(id: String) {
        progressStore.toggleFavoriteQuestionId(id)
    }

    override suspend fun toggleFavoritePhrase(id: String) {
        progressStore.toggleFavoritePhraseId(id)
    }

    override suspend fun toggleFavoriteLesson(id: String) {
        progressStore.toggleFavoriteLessonId(id)
    }

    override suspend fun setMomentum(value: Int) = progressStore.setMomentum(value)
    override suspend fun setCurrentUnitGlobalIndex(value: Int) =
        progressStore.setCurrentUnitGlobalIndex(value)

    override suspend fun setProCurrentUnitGlobalIndex(value: Int) =
        progressStore.setProCurrentUnitGlobalIndex(value)

    override suspend fun readAssetJsonOnce(assetPath: String): String =
        assets.readTextOnce(assetPath)


    // ===== New Assets Contracts (Questions v3.0 + Course 100 Units) =====
    private data class QuestionsIndexLevel(
        val level: String,
        val file: String,
        val questionCount: Int,
        val typesSupported: List<String>
    )

    private var cachedQuestionsIndex: List<QuestionsIndexLevel>? = null
    private val cachedLevelQuestionV2ById: LinkedHashMap<String, Map<String, com.emir.englishapp.domain.model.questionv2.QuestionV2>> =
        object : LinkedHashMap<String, Map<String, com.emir.englishapp.domain.model.questionv2.QuestionV2>>(4, 0.75f, true) {
            override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Map<String, com.emir.englishapp.domain.model.questionv2.QuestionV2>>): Boolean {
                // Keep only 2 levels in memory (global-grade, low RAM)
                return size > 2
            }
        }

    private suspend fun getQuestionsIndex(): List<QuestionsIndexLevel> {
        cachedQuestionsIndex?.let { return it }
        val raw = runCatching {
            readAssetJsonOnce("questions/index.json")
        }.getOrElse {
            // Some packs place index.json at the root of assets
            readAssetJsonOnce("index.json")
        }
        val root = JSONObject(raw)
        val levelsArr = root.optJSONArray("levels") ?: JSONArray()
        val out = ArrayList<QuestionsIndexLevel>(levelsArr.length())
        for (i in 0 until levelsArr.length()) {
            val obj = levelsArr.optJSONObject(i) ?: continue
            val lvl = obj.optString("level").trim()
            val file = obj.optString("file").trim()
            if (lvl.isBlank() || file.isBlank()) continue
            val typesArr = obj.optJSONArray("types_supported") ?: JSONArray()
            val types = ArrayList<String>(typesArr.length())
            for (t in 0 until typesArr.length()) {
                val v = typesArr.optString(t)
                if (!v.isNullOrBlank()) types.add(v)
            }
            out.add(
                QuestionsIndexLevel(
                    level = lvl,
                    file = file,
                    questionCount = obj.optInt("question_count", 0),
                    typesSupported = types
                )
            )
        }
        cachedQuestionsIndex = out
        return out
    }

    private fun detectUnitLevel(unitId: String, globalIndex: Int): String {
        val prefix = unitId.substringBefore("_").uppercase()
        if (prefix in listOf("A1", "A2", "B1", "B2", "C1")) return prefix
        return when {
            globalIndex <= 20 -> "A1"
            globalIndex <= 40 -> "A2"
            globalIndex <= 60 -> "B1"
            globalIndex <= 80 -> "B2"
            else -> "C1"
        }
    }

    private fun parseQuestionV2FromJson(q: JSONObject): com.emir.englishapp.domain.model.questionv2.QuestionV2? {
        val id = q.optString("id").trim()
        if (id.isBlank()) return null

        val typeRaw = q.optString("type", "mcq").ifBlank { "mcq" }.lowercase()
        val cefr = q.optString("cefr", "")
        val direction = q.optString("direction", q.optString("dir", ""))
        val skill = q.optStringOrNull("skill")
        val diff = q.optInt("difficulty_score", q.optInt("difficultyScore", 50)).coerceIn(0, 100)
        val explanation = q.optStringOrNull("explanation_ar") ?: q.optStringOrNull("explanationAr")

        fun jsonStringList(vararg keys: String): List<String> {
            for (k in keys) {
                val arr = q.optJSONArray(k) ?: continue
                val out = ArrayList<String>(arr.length())
                for (i in 0 until arr.length()) {
                    val v = arr.optString(i)
                    if (!v.isNullOrBlank()) out.add(v)
                }
                if (out.isNotEmpty()) return out
            }
            return emptyList()
        }

        return when (typeRaw) {
            "reorder" -> {
                val words = jsonStringList("words")
                val correct = jsonStringList("correct_order", "correctOrder")
                if (words.isEmpty() || correct.isEmpty()) return null
                com.emir.englishapp.domain.model.questionv2.ReorderQuestionV2(
                    id = id,
                    cefr = cefr,
                    direction = direction,
                    skill = skill,
                    difficultyScore = diff,
                    promptEn = q.optString("prompt_en", q.optString("promptEn", "Arrange the words to make a correct sentence:")),
                    words = words,
                    correctOrder = correct,
                    explanationAr = explanation
                )
            }

            "fill_blank" -> {
                val optionsEn = jsonStringList("options_en", "optionsEn")
                if (optionsEn.isEmpty()) return null
                com.emir.englishapp.domain.model.questionv2.FillBlankQuestionV2(
                    id = id,
                    cefr = cefr,
                    direction = direction,
                    skill = skill,
                    difficultyScore = diff,
                    promptEn = q.optString("prompt_en", q.optString("promptEn", "Choose the correct word:")),
                    sentenceEn = q.optString("sentence_en", q.optString("sentenceEn", q.optString("prompt_en", ""))),
                    optionsEn = optionsEn,
                    answerIndex = q.optInt("answer_index", q.optInt("answerIndex", 0)),
                    explanationAr = explanation
                )
            }

            else -> {
                val optionsAr = jsonStringList("options_ar", "optionsAr")
                val optionsEn = jsonStringList("options_en", "optionsEn")

                com.emir.englishapp.domain.model.questionv2.McqQuestionV2(
                    id = id,
                    cefr = cefr,
                    direction = direction,
                    skill = skill,
                    difficultyScore = diff,
                    promptAr = q.optStringOrNull("prompt_ar") ?: q.optStringOrNull("promptAr"),
                    promptEn = q.optStringOrNull("prompt_en") ?: q.optStringOrNull("promptEn"),
                    termEn = q.optStringOrNull("term_en") ?: q.optStringOrNull("termEn"),
                    termAr = q.optStringOrNull("term_ar") ?: q.optStringOrNull("termAr"),
                    sentenceEn = q.optStringOrNull("sentence_en") ?: q.optStringOrNull("sentenceEn"),
                    optionsAr = if (optionsAr.isEmpty()) null else optionsAr,
                    optionsEn = if (optionsEn.isEmpty()) null else optionsEn,
                    answerIndex = q.optInt("answer_index", q.optInt("answerIndex", 0)),
                    explanationAr = explanation
                )
            }
        }
    }

    private suspend fun getLevelQuestionV2ByIdMap(level: String): Map<String, com.emir.englishapp.domain.model.questionv2.QuestionV2> {
        cachedLevelQuestionV2ById[level]?.let { return it }

        val index = getQuestionsIndex()
        val entry = index.firstOrNull { it.level.equals(level, ignoreCase = true) }
            ?: throw IllegalStateException("Missing questions index entry for level=$level")

        val raw = readAssetJsonOnce("questions/${entry.file}")
        val root = JSONObject(raw)
        val arr = root.optJSONArray("questions") ?: JSONArray()

        val map = HashMap<String, com.emir.englishapp.domain.model.questionv2.QuestionV2>(arr.length() * 2)
        for (i in 0 until arr.length()) {
            val q = arr.optJSONObject(i) ?: continue
            val v2 = parseQuestionV2FromJson(q) ?: continue
            map[v2.id] = v2
        }

        cachedLevelQuestionV2ById[level] = map
        return map
    }

    private suspend fun getAllQuestionV2ByIdMerged(): Map<String, com.emir.englishapp.domain.model.questionv2.QuestionV2> {
        cachedProQuestionV2ById?.let { return it }

        val merged = HashMap<String, com.emir.englishapp.domain.model.questionv2.QuestionV2>(6000)
        for (lvl in listOf("A1", "A2", "B1", "B2", "C1")) {
            runCatching { getLevelQuestionV2ByIdMap(lvl) }.getOrNull()?.let { m ->
                for ((k, v) in m) merged[k] = v
            }
        }

        cachedProQuestionV2ById = merged
        return merged
    }

    // ===== Pro Path V3 (Dynamic) question generation from sentence pool =====

    private suspend fun getSentencesAll(): List<com.emir.englishapp.domain.model.SentenceItem> {
        cachedSentencesAll?.let { return it }
        val raw = readAssetJsonOnce("sentences_daily_8000_clean_classified_v2.json")
        val root = JSONObject(raw)
        val arr = root.optJSONArray("sentences") ?: JSONArray()
        val out = ArrayList<com.emir.englishapp.domain.model.SentenceItem>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val id = o.optInt("id", -1)
            val en = o.optString("en", "").trim()
            val ar = o.optString("ar", "").trim()
            val level = o.optString("level", "").trim().uppercase()
            if (id <= 0 || en.isBlank() || ar.isBlank() || level.isBlank()) continue
            out.add(
                com.emir.englishapp.domain.model.SentenceItem(
                    id = id,
                    en = en,
                    ar = ar,
                    level = level,
                    topic = o.optStringOrNull("topic"),
                    wordCount = if (o.has("word_count")) o.optInt("word_count") else null,
                    complexityScore = if (o.has("complexity_score")) o.optDouble("complexity_score") else null,
                )
            )
        }
        cachedSentencesAll = out
        return out
    }

    private suspend fun getSentencesByLevel(): Map<String, List<com.emir.englishapp.domain.model.SentenceItem>> {
        cachedSentencesByLevel?.let { return it }
        val all = getSentencesAll()
        val map = all.groupBy { it.level }
        cachedSentencesByLevel = map
        return map
    }

    private fun normalizeEn(s: String): String {
        return s.lowercase()
            .replace(Regex("[^a-z0-9\\s']"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    private fun tokenizeEn(s: String): List<String> {
        val norm = normalizeEn(s)
        if (norm.isBlank()) return emptyList()
        return norm.split(" ").filter { it.isNotBlank() }
    }

    private fun pickBlankWord(tokens: List<String>): Int {
        if (tokens.isEmpty()) return -1
        val stop = setOf(
            "i","you","he","she","it","we","they",
            "a","an","the","to","of","in","on","at","for","and","or","but",
            "is","am","are","was","were","be","been","being",
            "do","does","did","have","has","had",
            "this","that","these","those",
            "my","your","his","her","our","their"
        )
        // prefer non-stopwords with length >= 3
        for (i in tokens.indices) {
            val w = tokens[i]
            if (w.length >= 3 && w !in stop) return i
        }
        // fallback: any token with len>=2
        for (i in tokens.indices) {
            val w = tokens[i]
            if (w.length >= 2) return i
        }
        return -1
    }

    private suspend fun buildDynamicProRunQuestions(globalIndex: Int, level: String): List<com.emir.englishapp.domain.model.questionv2.QuestionV2> {
        val byLevel = getSentencesByLevel()
        fun levelPool(lvl: String): List<com.emir.englishapp.domain.model.SentenceItem> = byLevel[lvl.uppercase()].orEmpty()

        // Expand pool if needed
        val levelOrder = listOf("A1","A2","B1","B2","C1")
        val baseIdx = levelOrder.indexOf(level.uppercase()).coerceAtLeast(0)
        val pools = ArrayList<com.emir.englishapp.domain.model.SentenceItem>()
        pools.addAll(levelPool(level))
        if (pools.size < 80) {
            // Add neighbor levels for robustness
            val left = (baseIdx - 1).coerceAtLeast(0)
            val right = (baseIdx + 1).coerceAtMost(levelOrder.lastIndex)
            if (left != baseIdx) pools.addAll(levelPool(levelOrder[left]))
            if (right != baseIdx && right != left) pools.addAll(levelPool(levelOrder[right]))
        }

        // Anti-repeat history (store sentence ids with prefix s:)
        val used = progressStore.getUsedQuestionIds(limit = 600).toHashSet()
        fun isUsedSentenceId(id: Int): Boolean = ("s:$id" in used)

        // Deterministic-ish seed per unit run (changes each time you reset the run)
        val sessionSalt = ((System.currentTimeMillis() / 1000L) % 1_000_000L).toInt()
        val seed = (globalIndex * 997) xor (level.hashCode() * 31) xor sessionSalt
        val rng = kotlin.random.Random(seed)

        val isA1 = level.equals("A1", ignoreCase = true)

        // Template: 4 steps x 5 questions = 20
        // A1 should feel easy: start with more MCQ and fewer reorder.
        val template = if (isA1) listOf(
            "mcq","mcq","mcq","fill_blank","mcq",
            "mcq","fill_blank","mcq","mcq","reorder",
            "mcq","fill_blank","mcq","mcq","mcq",
            "fill_blank","mcq","mcq","fill_blank","reorder",
        ) else listOf(
            "mcq","fill_blank","reorder","mcq","fill_blank",
            "reorder","mcq","fill_blank","mcq","reorder",
            "fill_blank","mcq","reorder","fill_blank","mcq",
            "mcq","reorder","fill_blank","mcq","fill_blank",
        )

        val pickedIds = hashSetOf<Int>()

        fun sentenceTokens(en: String): List<String> = tokenizeEn(en)

        fun isEasyA1Sentence(s: com.emir.englishapp.domain.model.SentenceItem): Boolean {
            val en = s.en.trim()
            if (en.isBlank()) return false
            val toks = sentenceTokens(en)
            if (toks.size !in 2..5) return false
            // Avoid question forms & complex constructions early.
            val lowWords = toks.map { it.lowercase() }
            val bad = setOf("who","what","where","when","why","how")
            if (lowWords.any { it in bad }) return false
            if (lowWords.any { it == "will" || it == "have" || it == "had" }) return false
            if (en.contains("?")) return false
            if (en.contains("'")) return false // avoid contractions in A1
            // Avoid repeated tokens like "him him" for reorder simplicity
            if (toks.toSet().size != toks.size) return false
            return true
        }

        fun isOkForReorder(s: com.emir.englishapp.domain.model.SentenceItem): Boolean {
            val toks = sentenceTokens(s.en)
            if (toks.size !in 2..6) return false
            if (toks.toSet().size != toks.size) return false
            if (s.en.contains("?")) return false
            return if (isA1) isEasyA1Sentence(s) else true
        }

        fun pickSentence(predicate: (com.emir.englishapp.domain.model.SentenceItem) -> Boolean): com.emir.englishapp.domain.model.SentenceItem? {
            if (pools.isEmpty()) return null
            repeat(160) {
                val s = pools[rng.nextInt(pools.size)]
                if (s.id in pickedIds) return@repeat
                if (isUsedSentenceId(s.id)) return@repeat
                if (!predicate(s)) return@repeat
                return s
            }
            // fallback: any not-yet-picked that matches predicate
            return pools.firstOrNull { it.id !in pickedIds && predicate(it) }
                ?: pools.firstOrNull { it.id !in pickedIds }
        }

        val out = ArrayList<com.emir.englishapp.domain.model.questionv2.QuestionV2>(20)

        // helper to pick distractor translations
        fun pickArDistractors(correctId: Int, count: Int): List<String> {
            val options = LinkedHashSet<String>()
            repeat(200) {
                val s = pools[rng.nextInt(pools.size)]
                if (s.id == correctId) return@repeat
                val a = s.ar.trim()
                if (a.isNotBlank()) options.add(a)
                if (options.size >= count) return options.toList()
            }
            return options.toList().take(count)
        }

        // helper to pick distractor words
        fun pickWordDistractors(correct: String, count: Int): List<String> {
            val options = LinkedHashSet<String>()
            repeat(300) {
                val s = pools[rng.nextInt(pools.size)]
                val toks = tokenizeEn(s.en)
                if (toks.isEmpty()) return@repeat
                val w = toks[rng.nextInt(toks.size)]
                if (w.isNotBlank() && w != correct) options.add(w)
                if (options.size >= count) return options.toList()
            }
            return options.toList().take(count)
        }

        for (i in 0 until 20) {
            val type = template.getOrNull(i) ?: "mcq"
            val s = when (type) {
                "reorder" -> pickSentence(::isOkForReorder)
                "fill_blank" -> pickSentence { it.en.isNotBlank() && (!isA1 || isEasyA1Sentence(it)) }
                else -> pickSentence { it.en.isNotBlank() && it.ar.isNotBlank() && (!isA1 || isEasyA1Sentence(it)) }
            } ?: continue

            pickedIds.add(s.id)
            val cefr = s.level
            when (type) {
                "reorder" -> {
                    val words = tokenizeEn(s.en)
                    if (words.size >= 2) {
                        out.add(
                            com.emir.englishapp.domain.model.questionv2.ReorderQuestionV2(
                                id = "dyn:reorder:${s.id}:$i",
                                cefr = cefr,
                                direction = "en",
                                promptEn = if (isA1) "رتّب الكلمات لتكوين الجملة:" else "Arrange the words:",
                                words = words.shuffled(rng),
                                correctOrder = words,
                                // In A1 we show Arabic meaning as a strong hint.
                                explanationAr = s.ar
                            )
                        )
                    }
                }
                "fill_blank" -> {
                    val words = tokenizeEn(s.en)
                    val idx = pickBlankWord(words)
                    if (idx >= 0) {
                        val answer = words[idx]
                        val sentenceBlank = words.mapIndexed { j, w -> if (j == idx) "____" else w }.joinToString(" ")
                        val distract = pickWordDistractors(answer, 2)
                        val opts = (listOf(answer) + distract).shuffled(rng)
                        val ansIdx = opts.indexOf(answer).coerceAtLeast(0)
                        out.add(
                            com.emir.englishapp.domain.model.questionv2.FillBlankQuestionV2(
                                id = "dyn:fill:${s.id}:$i",
                                cefr = cefr,
                                direction = "en",
                                promptEn = if (isA1) "أكمل الكلمة الناقصة:" else "Fill in the blank:",
                                sentenceEn = sentenceBlank,
                                optionsEn = opts,
                                answerIndex = ansIdx,
                                explanationAr = s.ar
                            )
                        )
                    }
                }
                else -> {
                    // MCQ: choose Arabic meaning for the English sentence
                    val distract = pickArDistractors(s.id, 3)
                    val opts = (listOf(s.ar) + distract).shuffled(rng)
                    val ansIdx = opts.indexOf(s.ar).coerceAtLeast(0)
                    out.add(
                        com.emir.englishapp.domain.model.questionv2.McqQuestionV2(
                            id = "dyn:mcq:${s.id}:$i",
                            cefr = cefr,
                            direction = "en_to_ar",
                            promptAr = if (isA1) "اختر المعنى الصحيح:" else null,
                            promptEn = if (isA1) "Choose the correct meaning:" else "Choose the correct meaning:",
                            // Bind EN sentence to termEn so the UI always shows it first.
                            termEn = s.en,
                            sentenceEn = null,
                            optionsAr = opts,
                            answerIndex = ansIdx,
                            explanationAr = null
                        )
                    )
                }
            }
        }

        // Persist sentence ids into global history immediately to reduce repeats.
        progressStore.appendUsedQuestionIds(pickedIds.map { "s:$it" }, maxSize = 1200)
        return out
    }

    private fun serializeQuestionV2ToJson(q: com.emir.englishapp.domain.model.questionv2.QuestionV2): JSONObject {
        val o = JSONObject()
        o.put("id", q.id)
        o.put("type", q.type)
        o.put("cefr", q.cefr)
        o.put("direction", q.direction)
        q.skill?.let { o.put("skill", it) }
        q.difficultyScore?.let { o.put("difficulty_score", it) }
        q.explanationAr?.let { o.put("explanation_ar", it) }
        when (q) {
            is com.emir.englishapp.domain.model.questionv2.McqQuestionV2 -> {
                q.promptAr?.let { o.put("prompt_ar", it) }
                q.promptEn?.let { o.put("prompt_en", it) }
                q.sentenceEn?.let { o.put("sentence_en", it) }
                q.optionsAr?.let { arr ->
                    val a = JSONArray(); arr.forEach { a.put(it) }; o.put("options_ar", a)
                }
                q.optionsEn?.let { arr ->
                    val a = JSONArray(); arr.forEach { a.put(it) }; o.put("options_en", a)
                }
                o.put("answer_index", q.answerIndex)
            }
            is com.emir.englishapp.domain.model.questionv2.FillBlankQuestionV2 -> {
                o.put("prompt_en", q.promptEn)
                o.put("sentence_en", q.sentenceEn)
                val a = JSONArray(); q.optionsEn.forEach { a.put(it) }
                o.put("options_en", a)
                o.put("answer_index", q.answerIndex)
            }
            is com.emir.englishapp.domain.model.questionv2.ReorderQuestionV2 -> {
                o.put("prompt_en", q.promptEn)
                val w = JSONArray(); q.words.forEach { w.put(it) }
                val c = JSONArray(); q.correctOrder.forEach { c.put(it) }
                o.put("words", w)
                o.put("correct_order", c)
            }
        }
        return o
    }

    private fun parseQuestionV2FromStoredJson(q: JSONObject): com.emir.englishapp.domain.model.questionv2.QuestionV2? {
        // Reuse the robust parser already used for assets.
        return parseQuestionV2FromJson(q)
    }

    private suspend fun parseProPathV2CourseFromAsset(assetPath: String): CourseCurriculum {
        val raw = readAssetJsonOnce(assetPath)
        val root = JSONObject(raw)
        val levelsArr = root.optJSONArray("levels") ?: JSONArray()

        val levelsOrder = listOf("A1", "A2", "B1", "B2", "C1")
        val grouped = linkedMapOf<String, MutableList<CourseUnit>>()

        for (i in 0 until levelsArr.length()) {
            val lvlObj = levelsArr.optJSONObject(i) ?: continue
            val lvl = lvlObj.optString("level", "").trim().uppercase()
            val unitsArr = lvlObj.optJSONArray("units") ?: JSONArray()
            val bucket = grouped.getOrPut(lvl) { mutableListOf() }

            for (uIdx in 0 until unitsArr.length()) {
                val u = unitsArr.optJSONObject(uIdx) ?: continue
                val id = u.optString("unit_id", u.optString("unitId", "")).ifBlank {
                    u.optString("id", "")
                }
                val globalIndex = u.optInt("global_index", u.optInt("globalIndex", uIdx + 1))
                val titleEn = u.optString("title_en", u.optString("titleEn", "Unit $globalIndex"))
                val titleAr = u.optString("title_ar", u.optString("titleAr", "وحدة $globalIndex"))

                val qIdsArr = u.optJSONArray("question_ids") ?: u.optJSONArray("questionIds") ?: JSONArray()
                val qIds = ArrayList<String>(qIdsArr.length())
                for (q in 0 until qIdsArr.length()) {
                    val v = qIdsArr.optString(q)
                    if (!v.isNullOrBlank()) qIds.add(v)
                }

                val amplitude = 34f
                val step = 62f
                val xOffset = (kotlin.math.sin(globalIndex.toDouble() * 0.55) * amplitude).toFloat()

                bucket.add(
                    CourseUnit(
                        unitId = id.ifBlank { "${lvl}_U${globalIndex.toString().padStart(2, '0')}" },
                        globalIndex = globalIndex,
                        titleEn = titleEn,
                        titleAr = titleAr,
                        isVip = false,
                        xpReward = 25,
                        recommendedQuestions = u.optInt("recommended_questions", qIds.size).coerceAtLeast(8),
                        pathStyle = PathStyle(
                            type = "sine",
                            amplitude = amplitude,
                            step = step,
                            xOffset = xOffset
                        ),
                        questionIds = qIds
                    )
                )
            }
        }

        val levels = ArrayList<CourseLevel>(levelsArr.length())
        for ((idx2, lvl) in levelsOrder.withIndex()) {
            val units = grouped[lvl] ?: continue
            levels.add(
                CourseLevel(
                    level = idx2 + 1,
                    titleEn = lvl,
                    titleAr = lvl,
                    focusEn = "",
                    focusAr = "",
                    units = units.sortedBy { it.globalIndex }
                )
            )
        }

        return CourseCurriculum(levels = levels, bonusQuestionIds = emptyList())
    }

private suspend fun parseCourse100UnitsFromAsset(assetPath: String): CourseCurriculum {
        val raw = readAssetJsonOnce(assetPath)
        val root = JSONObject(raw)
        val unitsArr = root.optJSONArray("units") ?: JSONArray()

        val grouped = linkedMapOf<String, MutableList<CourseUnit>>()
        for (i in 0 until unitsArr.length()) {
            val u = unitsArr.optJSONObject(i) ?: continue
            val id = u.optString("id", "").ifBlank { u.optString("unitId", "") }
            val globalIndex = u.optInt("global_index", u.optInt("globalIndex", i + 1))
            val levelStr = u.optString("level", "").uppercase().ifBlank { detectUnitLevel(id, globalIndex) }
            val titleEn = u.optString("title_en", u.optString("titleEn", "Unit $globalIndex"))
            val titleAr = u.optString("title_ar", u.optString("titleAr", "وحدة $globalIndex"))

            val qIdsArr = u.optJSONArray("question_ids") ?: u.optJSONArray("questionIds") ?: JSONArray()
            val qIds = ArrayList<String>(qIdsArr.length())
            for (q in 0 until qIdsArr.length()) {
                val v = qIdsArr.optString(q)
                if (!v.isNullOrBlank()) qIds.add(v)
            }

            val amplitude = 34f
            val step = 62f
            val xOffset = (kotlin.math.sin(globalIndex.toDouble() * 0.55) * amplitude).toFloat()

            val unit = CourseUnit(
                unitId = id.ifBlank { "${levelStr}_U${globalIndex.toString().padStart(2, '0')}" },
                globalIndex = globalIndex,
                titleEn = titleEn,
                titleAr = titleAr,
                isVip = false,
                xpReward = 25,
                recommendedQuestions = qIds.size.coerceAtLeast(8),
                pathStyle = PathStyle(
                    type = "sine",
                    amplitude = amplitude,
                    step = step,
                    xOffset = xOffset
                ),
                questionIds = qIds
            )

            grouped.getOrPut(levelStr) { mutableListOf() }.add(unit)
        }

        val levelsOrder = listOf("A1", "A2", "B1", "B2", "C1")
        val levels = ArrayList<CourseLevel>(grouped.size)
        for ((idx, lvl) in levelsOrder.withIndex()) {
            val units = grouped[lvl] ?: continue
            levels.add(
                CourseLevel(
                    level = idx + 1,
                    titleEn = lvl,
                    titleAr = lvl,
                    focusEn = "",
                    focusAr = "",
                    units = units.sortedBy { it.globalIndex }
                )
            )
        }

        val bonusArr = root.optJSONArray("bonus_question_ids") ?: root.optJSONArray("bonusQuestionIds") ?: JSONArray()
        val bonusIds = ArrayList<String>(bonusArr.length())
        for (i in 0 until bonusArr.length()) {
            val bid = bonusArr.optString(i)
            if (!bid.isNullOrBlank()) bonusIds.add(bid)
        }

        return CourseCurriculum(levels = levels, bonusQuestionIds = bonusIds)
    }

    // ===== Stage 2 cache =====
    private var cachedCategories: List<PhraseCategory>? = null
    private var cachedPhrasesByCategory: Map<String, List<PhraseItem>>? = null

    override suspend fun getPhraseCategories(): List<PhraseCategory> {
        cachedCategories?.let { return it }

        val raw = readAssetJsonOnce("phrases_categories_meta.json").trim()
        // Support BOTH formats:
        // 1) [{...}, {...}]  (array root)
        // 2) {"categories": [{...}, {...}]} / {"items": [...]}
        val arr: JSONArray = if (raw.startsWith("[")) {
            JSONArray(raw)
        } else {
            val root = JSONObject(raw)
            when {
                root.has("categories") -> root.getJSONArray("categories")
                root.has("items") -> root.getJSONArray("items")
                else -> JSONArray()
            }
        }

        val result = ArrayList<PhraseCategory>(arr.length())
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            result.add(
                PhraseCategory(
                    key = obj.optString("key", obj.optString("id", "")),
                    titleEn = obj.optString("title_en", obj.optString("titleEn", obj.optString("en", ""))),
                    titleAr = obj.optString("title_ar", obj.optString("titleAr", obj.optString("ar", ""))),
                    order = obj.optInt("order", i),
                    icon = obj.optString("icon", "chat")
                )
            )
        }

        val sorted = result.sortedBy { it.order }
        cachedCategories = sorted
        return sorted
    }

    override suspend fun getPhrasesForCategory(categoryKey: String): List<PhraseItem> {
        val cached = cachedPhrasesByCategory
        if (cached != null) {
            return cached[categoryKey].orEmpty()
        }

        val jsonText = readAssetJsonOnce("data.json")
        val root = JSONObject(jsonText)

        val map = HashMap<String, List<PhraseItem>>(root.length())
        val keys = root.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            val arr = root.optJSONArray(key) ?: JSONArray()
            val list = ArrayList<PhraseItem>(arr.length())

            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)

                // Common keys in your dataset: id, lesson_id, sp (AR), en
                val idStr = obj.optString("id", "0")
                val lessonStr = obj.optString("lesson_id", "")
                val ar = obj.optString("sp", obj.optString("ar", ""))
                val en = obj.optString("en", obj.optString("eng", ""))

                val id = idStr.toIntOrNull() ?: 0
                val lessonId = lessonStr.toIntOrNull()

                list.add(
                    PhraseItem(
                        id = id,
                        ar = ar,
                        en = en,
                        lessonId = lessonId,
                        categoryKey = key
                    )
                )
            }

            map[key] = list
        }

        cachedPhrasesByCategory = map
        return map[categoryKey].orEmpty()
    }

    override suspend fun getQuizCorrectCounts(): Map<Int, Int> = progressStore.getQuizCorrectCounts()

    override suspend fun incrementQuizCorrect(id: Int) = progressStore.incrementQuizCorrect(id)

    override suspend fun getAllPhrases(): List<PhraseItem> {
        // Ensure cache is populated once, then flatten.
        val cached = cachedPhrasesByCategory
        val map = cached ?: run {
            // Populate cache by triggering a single parse.
            getPhrasesForCategory(categoryKey = "__cache_warmup__")
            cachedPhrasesByCategory.orEmpty()
        }
        return map.values.flatten()
    }

    // ===== Stage 3 (Lessons/Levels) =====
    // Supports two formats:
    // A) Single master file: lessons_master_level1_cards.json
    // B) Index + per-level files: assets/lessons/levels_index.json + assets/lessons/lessons_levelX.json
    private val legacyMasterAssetFile = "lessons_master_level1_cards.json"
    private val newIndexAssetFile = "lessons/levels_index.json"
    private var cachedLevels: List<LevelMeta>? = null
    private var cachedLevelsById: Map<Int, LessonLevel>? = null

    override suspend fun getLevelsIndex(): List<LevelMeta> {
        cachedLevels?.let { return it }
        // Prefer the new index (if present)
        val out = mutableListOf<LevelMeta>()

        val indexRaw = runCatching { readAssetJsonOnce(newIndexAssetFile) }.getOrNull()
        if (!indexRaw.isNullOrBlank()) {
            val root = JSONObject(indexRaw)
            val arr = root.optJSONArray("levels") ?: JSONArray()
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val id = o.optInt("id", o.optInt("levelId", i + 1))
                val file = o.optString("file", o.optString("assetFile", ""))
                out.add(
                    LevelMeta(
                        id = id,
                        titleAr = o.optString("titleAr", ""),
                        titleEn = o.optString("titleEn", ""),
                        assetFile = "lessons/" + file.trim().trimStart('/')
                    )
                )
            }
            cachedLevels = out
            return out
        }

        // Fallback to legacy master
        val raw = readAssetJsonOnce(legacyMasterAssetFile)
        val root = JSONObject(raw)
        val arr = root.optJSONArray("levels") ?: JSONArray()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val id = o.optInt("levelId", i + 1)
            out.add(
                LevelMeta(
                    id = id,
                    titleAr = o.optString("titleAr", ""),
                    titleEn = o.optString("titleEn", ""),
                    assetFile = legacyMasterAssetFile
                )
            )
        }
        cachedLevels = out
        return out
    }

    override suspend fun getLessonLevel(levelId: Int): LessonLevel? {
        cachedLevelsById?.get(levelId)?.let { return it }

        val levelsMap = mutableMapOf<Int, LessonLevel>()

        // Decide source: new per-level file if index exists, else legacy master
        val metas = getLevelsIndex()
        val meta = metas.firstOrNull { it.id == levelId }
        if (meta != null && meta.assetFile != legacyMasterAssetFile) {
            val raw = readAssetJsonOnce(meta.assetFile)
            val levelObj = JSONObject(raw)
            val parsed = parseLevelObject(levelObj, levelId)
            if (parsed != null) {
                levelsMap[levelId] = parsed
                cachedLevelsById = levelsMap
                return parsed
            }
        }

        // Legacy master: contains all levels
        val raw = readAssetJsonOnce(legacyMasterAssetFile)
        val root = JSONObject(raw)
        val arr = root.optJSONArray("levels") ?: JSONArray()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val id = o.optInt("levelId", i + 1)
            parseLevelObject(o, id)?.let { levelsMap[id] = it }
        }

        cachedLevelsById = levelsMap
        return levelsMap[levelId]
    }

    private fun parseLevelObject(o: JSONObject, id: Int): LessonLevel? {
        val titleAr = o.optString("titleAr", "")
        val titleEn = o.optString("titleEn", "")

        // Support both keys: units[] (new) OR sections[] (legacy)
        val blocks: JSONArray = when {
            o.has("units") -> o.optJSONArray("units") ?: JSONArray()
            o.has("sections") -> o.optJSONArray("sections") ?: JSONArray()
            else -> JSONArray()
        }

        val units = mutableListOf<UnitBlock>()
        for (s in 0 until blocks.length()) {
            val sec = blocks.optJSONObject(s) ?: continue
            val lessonsArr = sec.optJSONArray("lessons") ?: JSONArray()
            val lessons = mutableListOf<LessonItem>()

            for (l in 0 until lessonsArr.length()) {
                val les = lessonsArr.optJSONObject(l) ?: continue
                val cardsArr = les.optJSONArray("cards") ?: JSONArray()
                val cards = mutableListOf<CardItem>()
                for (c in 0 until cardsArr.length()) {
                    val card = cardsArr.optJSONObject(c) ?: continue

                    val itemsArr = card.optJSONArray("items")
                    val items = if (itemsArr != null) {
                        val ex = mutableListOf<LessonExampleItem>()
                        for (k in 0 until itemsArr.length()) {
                            val it = itemsArr.optJSONObject(k) ?: continue
                            ex.add(
                                LessonExampleItem(
                                    en = it.optStringOrNull("en"),
                                    ar = it.optStringOrNull("ar")
                                )
                            )
                        }
                        ex
                    } else null

                    val bulletsArr = card.optJSONArray("bullets")
                    val bullets = if (bulletsArr != null) {
                        val b = mutableListOf<String>()
                        for (k in 0 until bulletsArr.length()) {
                            val t = bulletsArr.optString(k, "")
                            if (t.isNotBlank()) b.add(t)
                        }
                        b
                    } else null

                    cards.add(
                        CardItem(
                            type = card.optString("type", ""),
                            text = card.optStringOrNull("text_ar")
                                ?: card.optStringOrNull("text")
                                ?: card.optStringOrNull("textAr"),
                            textEn = card.optStringOrNull("text_en") ?: card.optStringOrNull("textEn"),
                            formula = card.optStringOrNull("formula"),
                            notesEn = card.optStringOrNull("notes_en") ?: card.optStringOrNull("notesEn"),
                            items = items,
                            bullets = bullets
                        )
                    )
                }

                lessons.add(
                    LessonItem(
                        lessonId = les.optString("lessonId", ""),
                        titleAr = les.optString("titleAr", ""),
                        titleEn = les.optString("titleEn", ""),
                        cards = cards
                    )
                )
            }

            units.add(
                UnitBlock(
                    unitId = sec.optString("unitId", sec.optString("sectionId", (s + 1).toString())),
                    titleAr = sec.optString("titleAr", ""),
                    titleEn = sec.optString("titleEn", ""),
                    lessons = lessons
                )
            )
        }

        return LessonLevel(
            levelId = id,
            titleAr = titleAr,
            titleEn = titleEn,
            units = units
        )
    }

    override suspend fun getUnlockedLessonIndex(levelId: Int): Int =
        progressStore.getUnlockedLessonIndex(levelId)

    override suspend fun setUnlockedLessonIndex(levelId: Int, value: Int) {
        progressStore.setUnlockedLessonIndex(levelId, value)
    }

    override suspend fun getCompletedLessonIds(levelId: Int): Set<String> =
        progressStore.getCompletedLessons(levelId)

    override suspend fun addCompletedLessonId(levelId: Int, lessonId: String) {
        progressStore.addCompletedLesson(levelId, lessonId)
    }


override suspend fun getLessonStepIndex(key: String): Int {
    return progressStore.getLessonStepIndex(key)
}

override suspend fun setLessonStepIndex(key: String, index: Int) {
    progressStore.setLessonStepIndex(key, index)
}

    // ===== Stage 4 (Duolingo-like Course + Questions) =====
    private var cachedCurriculum: CourseCurriculum? = null
    private var cachedProCurriculum: CourseCurriculum? = null
    private var cachedUnitsFlat: List<CourseUnit>? = null
    private var cachedProUnitsFlat: List<CourseUnit>? = null
    private var cachedQuestionById: Map<String, Question>? = null
    private var cachedProQuestionById: Map<String, Question>? = null
    private var cachedProQuestionV2ById: Map<String, com.emir.englishapp.domain.model.questionv2.QuestionV2>? = null

    // ===== Pro Path V3 (Dynamic): sentence pools =====
    private var cachedSentencesAll: List<com.emir.englishapp.domain.model.SentenceItem>? = null
    private var cachedSentencesByLevel: Map<String, List<com.emir.englishapp.domain.model.SentenceItem>>? = null


    private suspend fun parseCourseCurriculumFromAsset(assetFile: String): CourseCurriculum {
        val raw = readAssetJsonOnce(assetFile)
        val root = JSONObject(raw)
        val metaObj = root.optJSONObject("meta") ?: JSONObject()
        val curriculumObj = root.optJSONObject("curriculum") ?: JSONObject()
        val levelsArr = curriculumObj.optJSONArray("levels") ?: JSONArray()
        val bonusArr = curriculumObj.optJSONArray("bonus_question_ids") ?: JSONArray()

        val levels = ArrayList<CourseLevel>(levelsArr.length())
        for (i in 0 until levelsArr.length()) {
            val lv = levelsArr.optJSONObject(i) ?: continue
            val unitsArr = lv.optJSONArray("units") ?: JSONArray()
            val units = ArrayList<CourseUnit>(unitsArr.length())
            for (j in 0 until unitsArr.length()) {
                val u = unitsArr.optJSONObject(j) ?: continue
                val ps = u.optJSONObject("path_style") ?: JSONObject()
                val qIdsArr = u.optJSONArray("question_ids") ?: JSONArray()
                val qIds = ArrayList<String>(qIdsArr.length())
                for (k in 0 until qIdsArr.length()) {
                    val id = qIdsArr.optString(k)
                    if (!id.isNullOrBlank()) qIds.add(id)
                }

                units.add(
                    CourseUnit(
                        unitId = u.optString("unit_id"),
                        globalIndex = u.optInt("global_index", 1),
                        titleEn = u.optString("title_en"),
                        titleAr = u.optString("title_ar"),
                        isVip = u.optBoolean("is_vip", false),
                        xpReward = u.optInt("xp_reward", 10),
                        recommendedQuestions = u.optInt("recommended_questions", qIds.size.coerceAtLeast(5)),
                        pathStyle = PathStyle(
                            type = ps.optString("type", "wave"),
                            amplitude = ps.optDouble("amplitude", 56.0).toFloat(),
                            step = ps.optDouble("step", 0.6).toFloat(),
                            xOffset = ps.optDouble("x_offset", 0.0).toFloat()
                        ),
                        questionIds = qIds
                    )
                )
            }

            levels.add(
                CourseLevel(
                    level = lv.optInt("level", i + 1),
                    titleEn = lv.optString("title_en"),
                    titleAr = lv.optString("title_ar"),
                    focusEn = lv.optString("focus_en"),
                    focusAr = lv.optString("focus_ar"),
                    units = units.sortedBy { it.globalIndex }
                )
            )
        }

        val bonusIds = ArrayList<String>(bonusArr.length())
        for (i in 0 until bonusArr.length()) {
            val id = bonusArr.optString(i)
            if (!id.isNullOrBlank()) bonusIds.add(id)
        }

        @Suppress("UNUSED_VARIABLE")
        val meta = CourseMeta(
            version = metaObj.optString("version", ""),
            style = metaObj.optString("style", ""),
            notes = metaObj.optString("notes", "")
        )

        return CourseCurriculum(
            levels = levels.sortedBy { it.level },
            bonusQuestionIds = bonusIds
        )
    }

    override suspend fun getCourseCurriculum(): CourseCurriculum {
        cachedCurriculum?.let { return it }

        val curriculum = parseCourseCurriculumFromAsset("course_5levels_75units_smart.json")
        cachedCurriculum = curriculum
        cachedUnitsFlat = curriculum.levels.flatMap { it.units }.sortedBy { it.globalIndex }
        return curriculum
    }



    override suspend fun getAllUnitsFlat(): List<CourseUnit> {
        cachedUnitsFlat?.let { return it }
        getCourseCurriculum()
        return cachedUnitsFlat.orEmpty()
    }

    
    override suspend fun getProCourseCurriculum(): CourseCurriculum {
        cachedProCurriculum?.let { return it }

        // Pro Path V2 (preferred): root asset contract with levels[] -> units[]
        val curriculum = runCatching {
            parseProPathV2CourseFromAsset("pro_path_course_v2.json")
        }.getOrElse {
            // Backward compatibility fallback
            parseCourse100UnitsFromAsset("courses/course_100units.json")
        }

        cachedProCurriculum = curriculum
        cachedProUnitsFlat = curriculum.levels.flatMap { it.units }.sortedBy { it.globalIndex }
        return curriculum
    }
    override suspend fun getAllProUnitsFlat(): List<CourseUnit> {
        cachedProUnitsFlat?.let { return it }
        getProCourseCurriculum()
        return cachedProUnitsFlat.orEmpty()
    }

override suspend fun getQuestionByIdMap(): Map<String, Question> {
        cachedQuestionById?.let { return it }

        val raw = readAssetJsonOnce("questions_3100_smart.json")
        val root = JSONObject(raw)
        val arr = root.optJSONArray("questions") ?: JSONArray()
        val map = HashMap<String, Question>(arr.length() * 2)

        for (i in 0 until arr.length()) {
            val q = arr.optJSONObject(i) ?: continue
            val id = q.optString("id")
            if (id.isNullOrBlank()) continue

            val tagsArr = q.optJSONArray("tags") ?: JSONArray()
            val tags = ArrayList<String>(tagsArr.length())
            for (t in 0 until tagsArr.length()) {
                val tag = tagsArr.optString(t)
                if (!tag.isNullOrBlank()) tags.add(tag)
            }

            val optsArArr = q.optJSONArray("options_ar") ?: JSONArray()
            val optsAr = ArrayList<String>(optsArArr.length())
            for (o in 0 until optsArArr.length()) {
                val v = optsArArr.optString(o)
                if (!v.isNullOrBlank()) optsAr.add(v)
            }

            val optsEnArr = q.optJSONArray("options_en") ?: JSONArray()
            val optsEn = ArrayList<String>(optsEnArr.length())
            for (o in 0 until optsEnArr.length()) {
                val v = optsEnArr.optString(o)
                if (!v.isNullOrBlank()) optsEn.add(v)
            }

            map[id] = Question(
                id = id,
                type = q.optString("type"),
                difficultyScore = q.optInt("difficulty_score", q.optInt("difficultyScore", 50)).coerceIn(0, 100),
                tags = tags,
                cefr = q.optString("cefr", ""),
                promptEn = q.optString("prompt_en", q.optString("promptEn", "")),
                promptAr = q.optStringOrNull("prompt_ar") ?: q.optStringOrNull("promptAr"),
                optionsAr = optsAr,
                optionsEn = if (optsEn.isEmpty()) null else optsEn,
                answerIndex = q.optInt("answer_index", q.optInt("answerIndex", 0)),
                answerAr = q.optString("answer_ar", q.optString("answerAr", "")),
                answerEn = q.optStringOrNull("answer_en") ?: q.optStringOrNull("answerEn"),
                explanationAr = q.optString("explanation_ar", q.optString("explanationAr", "")),
                skill = q.optStringOrNull("skill"),
                difficulty = q.optStringOrNull("difficulty")
            )
        }

        cachedQuestionById = map
        return map
    }

    override suspend fun getProQuestionByIdMap(): Map<String, Question> {
        cachedProQuestionById?.let { return it }

        // Legacy map: kept only for backward compatibility with old screens.
        // Pro Path V2 uses QuestionV2 models + renderer.
        val v2 = getAllQuestionV2ByIdMerged()
        val out = HashMap<String, Question>(v2.size * 2)

        for ((id, q) in v2) {
            when (q) {
                is com.emir.englishapp.domain.model.questionv2.McqQuestionV2 -> {
                    out[id] = Question(
                        id = id,
                        type = "mcq",
                        difficultyScore = q.difficultyScore ?: 50,
                        tags = emptyList(),
                        cefr = q.cefr ?: "",
                        promptEn = q.promptEn.orEmpty(),
                        promptAr = q.promptAr,
                        optionsAr = q.optionsAr ?: emptyList(),
                        optionsEn = q.optionsEn,
                        answerIndex = q.answerIndex ?: 0,
                        answerAr = "",
                        answerEn = null,
                        explanationAr = q.explanationAr.orEmpty(),
                        skill = q.skill,
                        difficulty = null
                    )
                }
                is com.emir.englishapp.domain.model.questionv2.FillBlankQuestionV2 -> {
                    out[id] = Question(
                        id = id,
                        type = "fill_blank",
                        difficultyScore = q.difficultyScore ?: 50,
                        tags = emptyList(),
                        cefr = q.cefr ?: "",
                        promptEn = q.promptEn.orEmpty(),
                        promptAr = null,
                        optionsAr = emptyList(),
                        optionsEn = q.optionsEn,
                        answerIndex = q.answerIndex ?: 0,
                        answerAr = "",
                        answerEn = null,
                        explanationAr = q.explanationAr.orEmpty(),
                        skill = q.skill,
                        difficulty = null
                    )
                }
                else -> Unit
            }
        }

        cachedProQuestionById = out
        return out
    }


    override suspend fun getProQuestionV2ByIdMap(): Map<String, com.emir.englishapp.domain.model.questionv2.QuestionV2> {
        return getAllQuestionV2ByIdMerged()
    }

    override suspend fun getProQuestionsV2ForUnit(globalIndex: Int): List<com.emir.englishapp.domain.model.questionv2.QuestionV2> {
        val unit = getAllProUnitsFlat().firstOrNull { it.globalIndex == globalIndex } ?: return emptyList()

        // Pro Path V3: dynamic generation from sentence pool.
        // We persist the generated run plan per unit so the user won't lose questions mid-run.
        val existingPlan = progressStore.getProUnitRunPlanJson(globalIndex)
        if (!existingPlan.isNullOrBlank()) {
            val arr = runCatching { JSONArray(existingPlan) }.getOrElse { JSONArray() }
            val out = ArrayList<com.emir.englishapp.domain.model.questionv2.QuestionV2>(arr.length())
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                parseQuestionV2FromStoredJson(o)?.let { out.add(it) }
            }
            if (out.isNotEmpty()) return out
        }

        val level = detectUnitLevel(unit.unitId, unit.globalIndex)
        val questions = buildDynamicProRunQuestions(globalIndex = globalIndex, level = level)
        val arr = JSONArray()
        questions.forEach { arr.put(serializeQuestionV2ToJson(it)) }
        progressStore.setProUnitRunPlanJson(globalIndex, arr.toString())
        return questions
    }

    override suspend fun getQuestionsForUnit(globalIndex: Int): List<Question> {
        val unit = getAllUnitsFlat().firstOrNull { it.globalIndex == globalIndex } ?: return emptyList()
        val qMap = getQuestionByIdMap()
        return unit.questionIds.mapNotNull { qMap[it] }
    }

    override suspend fun getProQuestionsForUnit(globalIndex: Int): List<Question> {
        val unit = getAllProUnitsFlat().firstOrNull { it.globalIndex == globalIndex } ?: return emptyList()
        val qMap = getProQuestionByIdMap()
        return unit.questionIds.mapNotNull { qMap[it] }
    }

    override suspend fun getDailySessionQuestionsForUnit(globalIndex: Int, count: Int, today: String): List<Question> {
        // We intentionally generate a NEW set every time the user enters the session,
        // while still avoiding repetition using the global history.
        // (If you want Duolingo-like "same questions for the day", re-enable cached daily ids.)
        val done = progressStore.isDailySessionDone(today)

        val unit = getAllUnitsFlat().firstOrNull { it.globalIndex == globalIndex } ?: return emptyList()
        val all = getQuestionsForUnit(globalIndex)
        if (all.isEmpty()) return emptyList()

        val targetCount = count.coerceIn(6, 15).coerceAtMost(all.size)
        val usedSet = progressStore.getUsedQuestionIds(limit = 1200).toHashSet()
        val weakTags = progressStore.getWeakTags().toHashSet()

        // Prefer questions from weak tags when available.
        val weakPool = if (weakTags.isEmpty()) emptyList() else all.filter { q -> q.tags.any { it in weakTags } }
        val normalPool = if (weakPool.isEmpty()) all else all.filterNot { q -> q.tags.any { it in weakTags } }

        fun bucket(q: Question): Int = when {
            q.difficultyScore <= 40 -> 0 // easy
            q.difficultyScore <= 70 -> 1 // medium
            else -> 2 // hard
        }

        val sessionSalt = ((System.currentTimeMillis() / 1000L) % 1_000_000L).toInt()
        val seed = (today.hashCode() * 31) xor (globalIndex * 997) xor sessionSalt
        val rng = kotlin.random.Random(seed)


        fun normalizeKey(q: Question): String {
            val raw = (q.promptEn.ifBlank { q.promptAr ?: "" }).lowercase()
            return raw
                .replace(Regex("\\d+"), "#")
                .replace(Regex("\\s+"), " ")
                .trim()
        }
        val selectedKeys = HashSet<String>(targetCount * 2)

        // Desired distribution: Easy 40%, Medium 40%, Hard 20%
        val wantEasy = (targetCount * 0.40f).toInt().coerceAtLeast(2)
        val wantMed = (targetCount * 0.40f).toInt().coerceAtLeast(2)
        val wantHard = (targetCount - wantEasy - wantMed).coerceAtLeast(1)
        val wanted = intArrayOf(wantEasy, wantMed, wantHard)

        fun pickFromPool(pool: List<Question>, out: MutableList<Question>) {
            if (pool.isEmpty()) return
            val byBucket = pool.groupBy(::bucket)
            for (b in 0..2) {
                val candidates = (byBucket[b].orEmpty()).shuffled(rng)

                // Prefer unseen
                val unseen = candidates.filterNot { it.id in usedSet }
                val seen = candidates.filter { it.id in usedSet }
                val ordered = unseen + seen

                val need = wanted[b]
                if (need <= 0) continue
                for (q in ordered) {
                    if (out.size >= targetCount) return
                    if (out.any { it.id == q.id }) continue
                    if (bucket(q) != b) continue
                                        val k = normalizeKey(q)
                    if (k in selectedKeys) continue
                    out.add(q)
                    selectedKeys.add(k)
                    if (out.count { bucket(it) == b } >= need) break
                }
            }
        }

        val selected = mutableListOf<Question>()
        // 1) Weak-tag pool first
        pickFromPool(weakPool, selected)
        // 2) Fill from normal pool
        if (selected.size < targetCount) pickFromPool(normalPool, selected)
        // 3) Absolute fallback
        if (selected.size < targetCount) {
            val shuffled = all.shuffled(rng)
            for (q in shuffled) {
                if (selected.size >= targetCount) break
                if (selected.any { it.id == q.id }) continue
                                val k = normalizeKey(q)
                if (k in selectedKeys) continue
                selected.add(q)
                selectedKeys.add(k)
            }
        }

        val finalList = selected.take(targetCount)
        // Note: we don't persist the selected set; variety comes from history + weak-tag weighting.
        return finalList
    }

    override suspend fun getUnitLessonStepQuestions(globalIndex: Int, stepIndex: Int, stepsTotal: Int, stepSize: Int): List<Question> {
        val unit = getAllUnitsFlat().firstOrNull { it.globalIndex == globalIndex } ?: return emptyList()
        val all = getQuestionsForUnit(globalIndex)
        if (all.isEmpty()) return emptyList()

        val totalSteps = stepsTotal.coerceIn(1, 10)
        val sizePerStep = stepSize.coerceIn(4, 15)

        // Order questions by difficulty (easy -> hard) so each unit feels progressive.
        val ordered = all.sortedBy { it.difficultyScore }

        val start = (stepIndex.coerceAtLeast(0)) * sizePerStep
        if (start >= ordered.size) return emptyList()
        val end = (start + sizePerStep).coerceAtMost(ordered.size)
        return ordered.subList(start, end)
    }

    override suspend fun getUnitStepIndex(globalIndex: Int): Int = progressStore.getUnitStepIndex(globalIndex)

    override suspend fun getUnitStepIndexMap(): Map<Int, Int> = progressStore.getUnitStepIndexMap()

    override suspend fun setUnitStepIndex(globalIndex: Int, stepIndex: Int) {
        progressStore.setUnitStepIndex(globalIndex, stepIndex)
    }

    override suspend fun getProUnitStepIndex(globalIndex: Int): Int =
        progressStore.getProUnitStepIndex(globalIndex)

    override suspend fun getProUnitStepIndexMap(): Map<Int, Int> =
        progressStore.getProUnitStepIndexMap()

    override suspend fun setProUnitStepIndex(globalIndex: Int, stepIndex: Int) {
        progressStore.setProUnitStepIndex(globalIndex, stepIndex)
    }

    override suspend fun resetProUnitRun(globalIndex: Int) {
        progressStore.resetProUnitRun(globalIndex)
    }

    override suspend fun addToProUnitRun(globalIndex: Int, correctDelta: Int, totalDelta: Int, timeDeltaMs: Long) {
        progressStore.addToProUnitRun(globalIndex, correctDelta, totalDelta, timeDeltaMs)
    }

    override suspend fun getProUnitRun(globalIndex: Int): Triple<Int, Int, Long> =
        progressStore.getProUnitRun(globalIndex)

    override suspend fun saveProUnitResult(globalIndex: Int, scorePercent: Int, masteryPercent: Int, stars: Int) {
        progressStore.saveProUnitResult(globalIndex, scorePercent, masteryPercent, stars, System.currentTimeMillis())
    }

    override suspend fun resetUnitRun(globalIndex: Int) {
        progressStore.resetUnitRun(globalIndex)
    }

    override suspend fun addToUnitRun(globalIndex: Int, correctDelta: Int, totalDelta: Int, timeDeltaMs: Long) {
        progressStore.addToUnitRun(globalIndex, correctDelta, totalDelta, timeDeltaMs)
    }

    override suspend fun getUnitRun(globalIndex: Int): Triple<Int, Int, Long> {
        return progressStore.getUnitRun(globalIndex)
    }

    override suspend fun recordQuestionAttempt(question: Question, correct: Boolean) {
        // Update tag stats for adaptive learning
        progressStore.recordTagAttempt(question.tags, correct)
        // Update anti-repeat history
        progressStore.appendUsedQuestionIds(listOf(question.id), maxSize = 1200)
    }


// ===== Daily Session / Unit progress (Stage 4.1) =====
override suspend fun resetDailyIfNewDay(today: String) {
    progressStore.resetDailyIfNewDay(today)
}

override suspend fun isDailySessionDone(today: String): Boolean {
    return progressStore.isDailySessionDone(today)
}

override suspend fun markDailySessionDone(today: String) {
    progressStore.markDailySessionDone(today)
}

override suspend fun addTotalXp(delta: Int) {
    progressStore.addTotalXp(delta)
}

override suspend fun saveUnitResult(globalIndex: Int, scorePercent: Int, masteryPercent: Int, stars: Int) {
    progressStore.saveUnitResult(globalIndex, scorePercent, masteryPercent, stars, addAttempt = true)
}

override suspend fun saveLastDailySummary(summary: DailySummary) {
    val obj = JSONObject()
    obj.put("date", summary.date)
    obj.put("globalIndex", summary.globalIndex)
    obj.put("correct", summary.correct)
    obj.put("total", summary.total)
    obj.put("scorePercent", summary.scorePercent)
    obj.put("masteryPercent", summary.masteryPercent)
    obj.put("stars", summary.stars)
    obj.put("xpEarned", summary.xpEarned)
    progressStore.saveLastDailySummaryJson(obj.toString())
}

override suspend fun getLastDailySummary(): DailySummary? {
    val raw = progressStore.getLastDailySummaryJson().orEmpty()
    if (raw.isBlank()) return null
    return try {
        val obj = JSONObject(raw)
        DailySummary(
            date = obj.optString("date", ""),
            globalIndex = obj.optInt("globalIndex", 0),
            correct = obj.optInt("correct", 0),
            total = obj.optInt("total", 0),
            scorePercent = obj.optInt("scorePercent", 0),
            masteryPercent = obj.optInt("masteryPercent", 0),
            stars = obj.optInt("stars", 0),
            xpEarned = obj.optInt("xpEarned", 0)
        ).takeIf { it.date.isNotBlank() }
    } catch (_: Throwable) {
        null
    }
}


    override suspend fun getProUnitLessonStepQuestions(globalIndex: Int, stepIndex: Int, stepsTotal: Int, stepSize: Int): List<Question> {
        val all = getProQuestionsForUnit(globalIndex)
        if (all.isEmpty()) return emptyList()

        // Progressive order WITH variety:
        // - Sort by difficulty (easy -> hard)
        // - Shuffle داخل نوافذ صغيرة لتجنب تكرار قوالب متشابهة وراء بعض
        val base = all.sortedBy { it.difficultyScore }
        val rng = kotlin.random.Random(globalIndex * 1009 + 17)

        fun normalizeKey(q: Question): String {
            val raw = (q.promptEn.ifBlank { q.promptAr ?: "" }).lowercase()
            return raw
                .replace(Regex("\\d+"), "#")
                .replace(Regex("\\s+"), " ")
                .trim()
        }

        // De-duplicate templates so "I study English 15 times..." doesn't appear many times في نفس الخطوة.
        val seen = HashSet<String>(base.size)
        val deduped = ArrayList<Question>(base.size)
        for (q in base) {
            val k = normalizeKey(q)
            if (seen.add(k)) deduped.add(q)
        }
        val src = if (deduped.size >= stepSize) deduped else base

        val windowSize = 12
        val progressive = ArrayList<Question>(src.size)
        var i = 0
        while (i < src.size) {
            val end = (i + windowSize).coerceAtMost(src.size)
            val window = src.subList(i, end).toMutableList()
            window.shuffle(rng)
            progressive.addAll(window)
            i = end
        }

        val totalSteps = stepsTotal.coerceIn(1, 10)
        val sizePerStep = stepSize.coerceIn(4, 15)
        val step = stepIndex.coerceIn(0, totalSteps - 1)

        if (progressive.isEmpty()) return emptyList()
        val from = (step * sizePerStep).coerceAtMost(progressive.lastIndex)
        val toExclusive = (from + sizePerStep).coerceAtMost(progressive.size)
        return progressive.subList(from, toExclusive)
    }

    override suspend fun getProUnitLessonStepQuestionsV2(
        globalIndex: Int,
        stepIndex: Int,
        stepsTotal: Int,
        stepSize: Int
    ): List<com.emir.englishapp.domain.model.questionv2.QuestionV2> {
        val all = getProQuestionsV2ForUnit(globalIndex)
        if (all.isEmpty()) return emptyList()

        val totalSteps = stepsTotal.coerceIn(1, 10)
        val sizePerStep = stepSize.coerceIn(4, 15)
        val step = stepIndex.coerceIn(0, totalSteps - 1)

        // 1) Stable order by difficulty (easy -> hard)
        val base = all.sortedBy { it.difficultyScore ?: 50 }
        val rng = kotlin.random.Random(globalIndex * 1009 + 31)

        // 2) Template de-dup (same prompt with different numbers)
        fun normalizeKey(q: com.emir.englishapp.domain.model.questionv2.QuestionV2): String {
            val raw = when (q) {
                is com.emir.englishapp.domain.model.questionv2.McqQuestionV2 ->
                    (q.promptEn ?: q.promptAr ?: "") + "|" + (q.termEn ?: q.termAr ?: q.sentenceEn ?: "")
                is com.emir.englishapp.domain.model.questionv2.FillBlankQuestionV2 ->
                    (q.promptEn + "|" + q.sentenceEn)
                is com.emir.englishapp.domain.model.questionv2.ReorderQuestionV2 ->
                    (q.promptEn + "|" + q.correctOrder.joinToString(" "))
            }
            return raw.lowercase()
                .replace(Regex("\\d+"), "#")
                .replace(Regex("\\s+"), " ")
                .trim()
        }

        val seen = HashSet<String>(base.size)
        val deduped = ArrayList<com.emir.englishapp.domain.model.questionv2.QuestionV2>(base.size)
        for (q in base) {
            val k = normalizeKey(q)
            if (seen.add(k)) deduped.add(q)
        }
        val src = if (deduped.size >= sizePerStep) deduped else base

        // 3) Mix types within each step (Duolingo-like variety)
        val stepFrom = (step * sizePerStep).coerceAtMost(src.lastIndex)
        val stepTo = (stepFrom + sizePerStep).coerceAtMost(src.size)
        val window = src.subList(stepFrom, stepTo).toMutableList()

        // If the dataset is still mostly MCQ, this is effectively a shuffle with de-dup.
        // When you start adding fill_blank & reorder, this keeps variety inside the same step.
        window.shuffle(rng)

        // Soft anti-clustering by skill (avoid same skill back-to-back when possible)
        val out = ArrayList<com.emir.englishapp.domain.model.questionv2.QuestionV2>(window.size)
        var lastSkill: String? = null
        val pool = window.toMutableList()
        while (pool.isNotEmpty()) {
            val idx = pool.indexOfFirst { it.skill != null && it.skill != lastSkill }.takeIf { it >= 0 }
                ?: 0
            val pick = pool.removeAt(idx)
            out.add(pick)
            lastSkill = pick.skill
        }

        return out
    }
}

