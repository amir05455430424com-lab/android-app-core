package com.emir.englishapp.ui.screens.daily

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.emir.englishapp.data.repository.AppRepository
import com.emir.englishapp.domain.model.daily.DailySummary
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.time.LocalDate
import kotlin.math.roundToInt

class DailyChallengeViewModel(
    private val repo: AppRepository,
    private val globalIndex: Int
) : ViewModel() {

    private val _uiState = MutableStateFlow(DailyChallengeUiState(globalIndex = globalIndex))
    val uiState: StateFlow<DailyChallengeUiState> = _uiState

    init {
        viewModelScope.launch {
            load()
        }

        viewModelScope.launch {
            repo.favoriteQuestionIds.collect { ids ->
                _uiState.update { it.copy(favoriteIds = ids) }
            }
        }
    }

    fun toggleFavoriteCurrent() {
        val q = _uiState.value.questions.getOrNull(_uiState.value.index) ?: return
        viewModelScope.launch {
            repo.toggleFavoriteQuestion(q.id)
        }
    }

    private suspend fun load() {
        _uiState.update { it.copy(isLoading = true, error = null) }

        val unit = try {
            repo.getAllUnitsFlat().firstOrNull { it.globalIndex == globalIndex }
        } catch (_: Throwable) { null }

        if (unit == null) {
            _uiState.update { it.copy(isLoading = false, error = "لم يتم العثور على الوحدة.") }
            return
        }

        val questions = try {
            // Smart, stable daily set + adaptive learning
            val today = LocalDate.now().toString()
            val n = 7
            repo.getDailySessionQuestionsForUnit(globalIndex = globalIndex, count = n, today = today)
        } catch (_: Throwable) { emptyList() }

        if (questions.isEmpty()) {
            _uiState.update { it.copy(isLoading = false, error = "لا توجد أسئلة لهذه الوحدة.") }
            return
        }

        val now = System.currentTimeMillis()
        _uiState.update {
            it.copy(
                isLoading = false,
                error = null,
                unitTitleAr = unit.titleAr,
                unitTitleEn = unit.titleEn,
                xpReward = unit.xpReward,
                questions = questions,
                index = 0,
                selected = null,
                isCorrect = null,
                correctCount = 0,
                startedAtMs = now,
                questionStartedAtMs = now,
                totalAnswerTimeMs = 0L,
                isFinished = false
            )
        }
    }

    fun select(optionIndex: Int) {
        _uiState.update { st ->
            if (st.selected != null || st.isFinished) return@update st
            val q = st.questions.getOrNull(st.index) ?: return@update st
            val ok = optionIndex == q.answerIndex
            val spent = (System.currentTimeMillis() - st.questionStartedAtMs).coerceAtLeast(0L)

            // Record attempt for adaptive learning + anti-repeat.
            viewModelScope.launch {
                runCatching { repo.recordQuestionAttempt(question = q, correct = ok) }
            }

            st.copy(
                selected = optionIndex,
                isCorrect = ok,
                correctCount = st.correctCount + if (ok) 1 else 0,
                totalAnswerTimeMs = st.totalAnswerTimeMs + spent
            )
        }
    }

    fun next(onFinished: (DailyResult) -> Unit) {
        val st = _uiState.value
        if (st.selected == null || st.isFinished) return

        if (st.index + 1 >= st.questions.size) {
            // finish
            viewModelScope.launch {
                val result = finalizeResult(st)
                onFinished(result)
            }
        } else {
            val now = System.currentTimeMillis()
            _uiState.update {
                it.copy(
                    index = it.index + 1,
                    selected = null,
                    isCorrect = null,
                    questionStartedAtMs = now
                )
            }
        }
    }

    private suspend fun finalizeResult(st: DailyChallengeUiState): DailyResult {
        val total = st.questions.size.coerceAtLeast(1)
        val accuracy = st.correctCount.toFloat() / total.toFloat()
        val scorePercent = (accuracy * 100f).roundToInt().coerceIn(0, 100)

        val avgSec = (st.totalAnswerTimeMs.toFloat() / total.toFloat()) / 1000f
        val speedBonus = ((8f - avgSec) / 8f).coerceIn(0f, 1f) // 0..1
        val mastery = (0.7f * accuracy + 0.3f * speedBonus).coerceIn(0f, 1f)
        val masteryPercent = (mastery * 100f).roundToInt().coerceIn(0, 100)

        val stars = when {
            masteryPercent >= 90 -> 3
            masteryPercent >= 80 -> 2
            masteryPercent >= 65 -> 1
            else -> 0
        }

        // ===== XP Economy (Stage 4.A)
        // Correct = +10, Wrong = +3, Perfect bonus = +20
        val wrong = (total - st.correctCount).coerceAtLeast(0)
        val xpFromAnswers = st.correctCount * 10 + wrong * 3
        val perfectBonus = if (st.correctCount == total) 20 else 0
        val xpEarned = xpFromAnswers + perfectBonus

        // Save + XP + Unlock
        val today = LocalDate.now().toString()
        repo.markDailySessionDone(today) // also updates streak
        repo.addTotalXp(xpEarned)
        repo.saveUnitResult(globalIndex = globalIndex, scorePercent = scorePercent, masteryPercent = masteryPercent, stars = stars)

        // Persist last daily summary for Smart Home
        repo.saveLastDailySummary(
            DailySummary(
                date = today,
                globalIndex = globalIndex,
                correct = st.correctCount,
                total = total,
                scorePercent = scorePercent,
                masteryPercent = masteryPercent,
                stars = stars,
                xpEarned = xpEarned
            )
        )

        // Unlock logic (Auto Path Unlock)
        var unlockedNext = false
        if (masteryPercent >= 80) {
            val current = repo.currentUnitGlobalIndex.first()
            if (current <= globalIndex) {
                repo.setCurrentUnitGlobalIndex(globalIndex + 1)
                unlockedNext = true
            }
        }

        return DailyResult(
            globalIndex = globalIndex,
            scorePercent = scorePercent,
            masteryPercent = masteryPercent,
            stars = stars,
            correct = st.correctCount,
            total = total,
            xpEarned = xpEarned,
            unlockedNext = unlockedNext
        )
    }
}

data class DailyResult(
    val globalIndex: Int,
    val scorePercent: Int,
    val masteryPercent: Int,
    val stars: Int,
    val correct: Int,
    val total: Int,
    val xpEarned: Int,
    val unlockedNext: Boolean
)

class DailyChallengeViewModelFactory(
    private val repo: AppRepository,
    private val globalIndex: Int
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return DailyChallengeViewModel(repo, globalIndex) as T
    }
}
