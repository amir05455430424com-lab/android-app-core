package com.emir.englishapp.ui.screens.daily

import com.emir.englishapp.domain.model.question.Question

data class DailyStudyUiState(
    val isLoading: Boolean = true,
    val error: String? = null,
    val globalIndex: Int = 1,
    val unitTitleAr: String = "",
    val unitTitleEn: String = "",
    val questions: List<Question> = emptyList(),
    val index: Int = 0,
    val selectedIndex: Int? = null,
    val isAnswered: Boolean = false,
    val isCorrect: Boolean? = null,
    val isFinished: Boolean = false
) {
    val current: Question? get() = questions.getOrNull(index)
}
