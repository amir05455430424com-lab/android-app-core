package com.emir.englishapp.domain.engine

import com.emir.englishapp.domain.model.exercise.AnswerLanguage
import com.emir.englishapp.domain.model.exercise.ExerciseTemplate
import com.emir.englishapp.domain.model.exercise.LearningModality
import com.emir.englishapp.domain.model.exercise.SortCategory
import com.emir.englishapp.domain.model.exercise.SortWord
import com.emir.englishapp.domain.model.exercise.WordPair

/**
 * SmartLocalEngine — Procedural, deterministic, offline exercise generator.
 *
 * Design contract:
 *  - PURE KOTLIN: zero Android dependencies. Fully unit-testable.
 *  - DETERMINISTIC: same [seed] + same input always produces the same output.
 *  - NO AI / NO CLOUD: all logic is heuristic-based procedural generation.
 *  - EXTENSIBLE: adding a new exercise template requires only one new private
 *    `generate*` function + one routing rule in [generateForSentence].
 *
 * Primary entry points:
 *  1. [generateModule] — produces up to 200 exercises for a full module.
 *  2. [generateSession] — produces a short session (N exercises) for a node/lesson.
 *  3. [generateForSentence] — produces all applicable templates for one sentence pair.
 *
 * Input types:
 *  - [RawSentence]: the fundamental unit (EN + AR text, CEFR, topic).
 *  - [RawWordPair]: a single EN↔AR word mapping (used for MCQ distractors & MatchPairs).
 *  - [AudioHint]: optional audio asset path + word timestamps for a sentence.
 */
class SmartLocalEngine(
    private val seed: Long = 42L,
) {

    // ─────────────────────────────────────────────────────────────
    // Public input types
    // ─────────────────────────────────────────────────────────────

    data class RawSentence(
        val id: String,
        val en: String,
        val ar: String,
        val cefr: String = "A1",
        val topic: String = "general",
        val complexityScore: Float = 0f,
    ) {
        val wordCount: Int get() = en.trim().split(Regex("\\s+")).size
    }

    data class RawWordPair(
        val en: String,
        val ar: String,
        val topic: String = "general",
        val cefr: String = "A1",
    )

    data class AudioHint(
        val assetPath: String,
        val sentenceId: String,
        val wordTimestamps: List<com.emir.englishapp.domain.model.exercise.WordTimestamp> = emptyList(),
    )

    // ─────────────────────────────────────────────────────────────
    // Generation policy constants
    // ─────────────────────────────────────────────────────────────

    private object Policy {
        const val MODULE_MAX_EXERCISES = 200
        const val MCQ_OPTION_COUNT = 4
        const val MATCH_PAIRS_COUNT = 5      // pairs per MatchPairs exercise
        const val WORD_SORT_POOL_SIZE = 8    // words in a WordSort pool
        const val REORDER_MIN_WORDS = 3      // minimum words for Reorder
        const val REORDER_MAX_WORDS = 10     // above this → FillBlank preferred
        const val FILL_BLANK_PREFERRED_WORD_COUNT = 5  // sentences with 5+ words
        const val SPOT_ERROR_MIN_WORDS = 4
        const val DISTRACTOR_GUARD_ITERATIONS = 3000
    }

    // ─────────────────────────────────────────────────────────────
    // Internal seeded RNG (pure, no kotlin.Random reliance on SDK)
    // ─────────────────────────────────────────────────────────────

    private inner class Rng(seed: Long) {
        private var state = seed xor 6364136223846793005L

        fun nextLong(): Long {
            state = state * 6364136223846793005L + 1442695040888963407L
            return state
        }

        fun nextInt(bound: Int): Int {
            if (bound <= 0) return 0
            return ((nextLong() ushr 1) % bound).toInt().let { if (it < 0) -it else it }
        }

        fun nextBoolean(): Boolean = (nextLong() and 1L) == 0L

        fun <T> shuffle(list: MutableList<T>): MutableList<T> {
            for (i in list.size - 1 downTo 1) {
                val j = nextInt(i + 1)
                val tmp = list[i]; list[i] = list[j]; list[j] = tmp
            }
            return list
        }

        fun <T> pick(list: List<T>): T = list[nextInt(list.size)]
        fun <T> pickN(list: List<T>, n: Int): List<T> {
            val copy = list.toMutableList()
            shuffle(copy)
            return copy.take(n)
        }
    }

    private val rng = Rng(seed)

    // ─────────────────────────────────────────────────────────────
    // Primary API
    // ─────────────────────────────────────────────────────────────

    /**
     * Generate up to [Policy.MODULE_MAX_EXERCISES] exercises for a full module.
     * Balances modalities: ~40% Visual, ~30% Auditory, ~30% Kinetic.
     *
     * @param sentences     all sentences for this module's topic
     * @param wordPairs     word-level pairs used for distractors and MatchPairs
     * @param audioHints    optional audio data; exercises degrade to TTS fallback if absent
     * @param topic         topic key (aligns with data.json category keys)
     * @param cefr          CEFR ceiling for difficulty filtering
     */
    fun generateModule(
        sentences: List<RawSentence>,
        wordPairs: List<RawWordPair>,
        audioHints: List<AudioHint> = emptyList(),
        topic: String = "general",
        cefr: String = "A1",
    ): List<ExerciseTemplate> {
        val audioIndex = audioHints.associateBy { it.sentenceId }
        val pool = mutableListOf<ExerciseTemplate>()
        var idCounter = 0

        fun nextId(prefix: String) = "${prefix}_${topic}_${++idCounter}"

        // ── Visual exercises (TranslateArEn, TranslateEnAr, FillBlank, SpotError, SentComplete, PronBridge) ──
        val visualSentences = sentences.filter { it.cefr <= cefr }

        for (s in visualSentences) {
            if (pool.size >= Policy.MODULE_MAX_EXERCISES) break

            pool += generateTranslateEnToAr(nextId("ten_ar"), s, sentences, rng)
            if (pool.size >= Policy.MODULE_MAX_EXERCISES) break

            pool += generateTranslateArToEn(nextId("ar_en"), s, sentences, rng)
            if (pool.size >= Policy.MODULE_MAX_EXERCISES) break

            if (s.wordCount >= Policy.FILL_BLANK_PREFERRED_WORD_COUNT) {
                pool += generateFillBlank(nextId("fb"), s, sentences, rng)
                if (pool.size >= Policy.MODULE_MAX_EXERCISES) break
            }

            if (s.wordCount >= Policy.SPOT_ERROR_MIN_WORDS) {
                generateSpotTheError(nextId("ste"), s, sentences, rng)?.let {
                    pool += it
                    if (pool.size >= Policy.MODULE_MAX_EXERCISES) return@let
                }
            }

            if (s.wordCount >= Policy.FILL_BLANK_PREFERRED_WORD_COUNT) {
                generateSentenceComplete(nextId("sc"), s, sentences, rng)?.let {
                    pool += it
                }
            }
        }

        // ── Kinetic exercises (SentenceReorder, MatchPairs, WordSort) ──
        val kineticSentences = sentences
            .filter { it.wordCount in Policy.REORDER_MIN_WORDS..Policy.REORDER_MAX_WORDS }
            .filter { it.cefr <= cefr }

        for (s in kineticSentences) {
            if (pool.size >= Policy.MODULE_MAX_EXERCISES) break
            pool += generateSentenceReorder(nextId("re"), s, audioIndex[s.id], rng)
        }

        // MatchPairs: group word pairs into chunks of MATCH_PAIRS_COUNT
        val matchChunks = wordPairs
            .filter { it.cefr <= cefr }
            .chunked(Policy.MATCH_PAIRS_COUNT)

        for ((idx, chunk) in matchChunks.withIndex()) {
            if (pool.size >= Policy.MODULE_MAX_EXERCISES) break
            if (chunk.size < 2) continue
            pool += generateMatchPairs(nextId("mp_$idx"), chunk, topic, cefr, rng)
        }

        // WordSort: pair up word pairs by POS-like heuristic (verbs vs nouns)
        if (wordPairs.size >= Policy.WORD_SORT_POOL_SIZE && pool.size < Policy.MODULE_MAX_EXERCISES) {
            generateWordSort(nextId("ws"), wordPairs, topic, cefr, rng)?.let { pool += it }
        }

        // ── Auditory exercises (ListenAndPick, DictationReorder, TypeWhatYouHear) ──
        val audioSentences = sentences.filter { audioIndex.containsKey(it.id) && it.cefr <= cefr }

        for (s in audioSentences) {
            if (pool.size >= Policy.MODULE_MAX_EXERCISES) break
            val audio = audioIndex[s.id]!!
            pool += generateListenAndPick(nextId("lap"), s, sentences, audio, rng)

            if (pool.size >= Policy.MODULE_MAX_EXERCISES) break
            if (s.wordCount in Policy.REORDER_MIN_WORDS..7) {
                pool += generateDictationReorder(nextId("dr"), s, audio, rng)
            }
        }

        // Shuffle to prevent modality clustering
        return rng.shuffle(pool.toMutableList()).take(Policy.MODULE_MAX_EXERCISES)
    }

    /**
     * Generate a short session (typically 5–20 exercises) for a specific node/lesson.
     * Respects modality target and difficulty band.
     */
    fun generateSession(
        sentences: List<RawSentence>,
        wordPairs: List<RawWordPair>,
        audioHints: List<AudioHint> = emptyList(),
        topic: String = "general",
        cefr: String = "A1",
        targetModality: LearningModality? = null,
        sessionSize: Int = 10,
        sessionSeed: Long = System.nanoTime(),
    ): List<ExerciseTemplate> {
        val sessionRng = Rng(seed xor sessionSeed)
        val full = generateModule(sentences, wordPairs, audioHints, topic, cefr)
        val filtered = if (targetModality != null)
            full.filter { it.modality == targetModality }.ifEmpty { full }
        else full

        return sessionRng.pickN(filtered, minOf(sessionSize, filtered.size))
    }

    /**
     * Generate all applicable exercise types for a single sentence pair.
     * Useful for preview/testing and for the EduCMS content studio.
     */
    fun generateForSentence(
        sentence: RawSentence,
        allSentences: List<RawSentence>,
        audio: AudioHint? = null,
    ): List<ExerciseTemplate> {
        val result = mutableListOf<ExerciseTemplate>()
        var n = 0
        fun nextId(prefix: String) = "${prefix}_preview_${++n}"

        result += generateTranslateEnToAr(nextId("ten_ar"), sentence, allSentences, rng)
        result += generateTranslateArToEn(nextId("ar_en"), sentence, allSentences, rng)

        if (sentence.wordCount >= Policy.REORDER_MIN_WORDS) {
            result += generateSentenceReorder(nextId("re"), sentence, audio, rng)
        }
        if (sentence.wordCount >= Policy.FILL_BLANK_PREFERRED_WORD_COUNT) {
            result += generateFillBlank(nextId("fb"), sentence, allSentences, rng)
            generateSentenceComplete(nextId("sc"), sentence, allSentences, rng)?.let { result += it }
        }
        if (sentence.wordCount >= Policy.SPOT_ERROR_MIN_WORDS) {
            generateSpotTheError(nextId("ste"), sentence, allSentences, rng)?.let { result += it }
        }
        if (audio != null) {
            result += generateListenAndPick(nextId("lap"), sentence, allSentences, audio, rng)
            if (sentence.wordCount in Policy.REORDER_MIN_WORDS..7) {
                result += generateDictationReorder(nextId("dr"), sentence, audio, rng)
            }
        }
        return result
    }

    // ─────────────────────────────────────────────────────────────
    // Private generators — one per exercise type
    // ─────────────────────────────────────────────────────────────

    private fun generateTranslateEnToAr(
        id: String,
        s: RawSentence,
        pool: List<RawSentence>,
        r: Rng,
    ): ExerciseTemplate.TranslateEnToAr {
        val distractors = buildArDisractors(s.ar, pool, r, Policy.MCQ_OPTION_COUNT - 1)
        val options = buildShuffledOptions(s.ar, distractors, r)
        return ExerciseTemplate.TranslateEnToAr(
            id = id,
            cefr = s.cefr,
            difficultyScore = cefrToDifficulty(s.cefr) + (s.complexityScore * 20).toInt(),
            topic = s.topic,
            promptEn = s.en,
            optionsAr = options.list,
            answerIndex = options.correctIndex,
            explanationAr = "الترجمة الصحيحة: ${s.ar}",
        )
    }

    private fun generateTranslateArToEn(
        id: String,
        s: RawSentence,
        pool: List<RawSentence>,
        r: Rng,
    ): ExerciseTemplate.TranslateArToEn {
        val distractors = buildEnDistractors(s.en, pool, r, Policy.MCQ_OPTION_COUNT - 1)
        val options = buildShuffledOptions(s.en, distractors, r)
        return ExerciseTemplate.TranslateArToEn(
            id = id,
            cefr = s.cefr,
            difficultyScore = cefrToDifficulty(s.cefr) + (s.complexityScore * 20).toInt(),
            topic = s.topic,
            promptAr = "ما معنى هذه الجملة بالإنجليزية؟",
            optionsEn = options.list,
            answerIndex = options.correctIndex,
            explanationAr = "الإجابة: ${s.en}",
        )
    }

    private fun generateSentenceReorder(
        id: String,
        s: RawSentence,
        audio: AudioHint?,
        r: Rng,
    ): ExerciseTemplate.SentenceReorder {
        val words = s.en.trim().split(Regex("\\s+"))
        val shuffled = r.shuffle(words.toMutableList())
        return ExerciseTemplate.SentenceReorder(
            id = id,
            cefr = s.cefr,
            difficultyScore = cefrToDifficulty(s.cefr) + words.size * 2,
            topic = s.topic,
            promptAr = s.ar,
            shuffledWords = shuffled,
            correctOrder = words,
            audioAssetPath = audio?.assetPath,
            explanationAr = "الترتيب الصحيح: ${s.en}",
        )
    }

    private fun generateFillBlank(
        id: String,
        s: RawSentence,
        pool: List<RawSentence>,
        r: Rng,
    ): ExerciseTemplate.FillBlank {
        val words = s.en.trim().split(Regex("\\s+"))
        // Pick a content word (non-function) as the blank target
        val candidateIndices = words.indices.filter { i ->
            val w = words[i].lowercase().trimEnd('.', ',', '?', '!')
            w.length >= 3 && w !in FUNCTION_WORDS
        }
        val blankIdx = if (candidateIndices.isEmpty()) words.size / 2
                       else r.pick(candidateIndices)

        val correctWord = words[blankIdx]
        val sentence = words.mapIndexed { i, w -> if (i == blankIdx) "___" else w }.joinToString(" ")

        val distractors = buildEnDistractors(correctWord, pool, r, Policy.MCQ_OPTION_COUNT - 1,
            singleWord = true)
        val options = buildShuffledOptions(correctWord, distractors, r)

        return ExerciseTemplate.FillBlank(
            id = id,
            cefr = s.cefr,
            difficultyScore = cefrToDifficulty(s.cefr) + 5,
            topic = s.topic,
            sentenceWithPlaceholder = sentence,
            optionsEn = options.list,
            answerIndex = options.correctIndex,
            arHint = s.ar,
            explanationAr = "الكلمة الصحيحة: $correctWord",
        )
    }

    private fun generateSpotTheError(
        id: String,
        s: RawSentence,
        pool: List<RawSentence>,
        r: Rng,
    ): ExerciseTemplate.SpotTheError? {
        val words = s.en.trim().split(Regex("\\s+"))
        if (words.size < Policy.SPOT_ERROR_MIN_WORDS) return null

        // Pick a content word to swap with a plausible wrong word
        val candidates = words.indices.filter { i ->
            val w = words[i].lowercase().trimEnd('.', ',', '?', '!')
            w.length >= 3 && w !in FUNCTION_WORDS
        }
        if (candidates.isEmpty()) return null
        val errorIdx = r.pick(candidates)
        val originalWord = words[errorIdx]

        // Find a distractor from pool
        val wrongWord = pool
            .asSequence()
            .flatMap { it.en.split(Regex("\\s+")).asSequence() }
            .map { it.trimEnd('.', ',', '?', '!') }
            .filter { it.length >= 3 && it.lowercase() != originalWord.lowercase() && it !in FUNCTION_WORDS }
            .distinct()
            .firstOrNull() ?: return null

        val tokensWithError = words.toMutableList().also { it[errorIdx] = wrongWord }

        return ExerciseTemplate.SpotTheError(
            id = id,
            cefr = s.cefr,
            difficultyScore = cefrToDifficulty(s.cefr) + 15,
            topic = s.topic,
            sentenceTokens = tokensWithError,
            errorIndex = errorIdx,
            correctedWord = originalWord,
            arHint = s.ar,
            explanationAr = "الكلمة الخاطئة هي '${wrongWord}'. الصحيحة: '$originalWord'",
        )
    }

    private fun generateMatchPairs(
        id: String,
        pairs: List<RawWordPair>,
        topic: String,
        cefr: String,
        r: Rng,
    ): ExerciseTemplate.MatchPairs {
        val wordPairs = pairs.map { WordPair(en = it.en, ar = it.ar) }
        return ExerciseTemplate.MatchPairs(
            id = id,
            cefr = cefr,
            difficultyScore = cefrToDifficulty(cefr) + pairs.size * 3,
            topic = topic,
            pairs = wordPairs,
            explanationAr = "طابق الكلمات مع معانيها الصحيحة",
        )
    }

    private fun generateListenAndPick(
        id: String,
        s: RawSentence,
        pool: List<RawSentence>,
        audio: AudioHint,
        r: Rng,
    ): ExerciseTemplate.ListenAndPick {
        val distractors = buildArDisractors(s.ar, pool, r, Policy.MCQ_OPTION_COUNT - 1)
        val options = buildShuffledOptions(s.ar, distractors, r)
        return ExerciseTemplate.ListenAndPick(
            id = id,
            cefr = s.cefr,
            difficultyScore = cefrToDifficulty(s.cefr) + 8,
            topic = s.topic,
            audioAssetPath = audio.assetPath,
            correctText = s.en,
            targetLanguage = AnswerLanguage.ARABIC,
            options = options.list,
            answerIndex = options.correctIndex,
            wordTimestamps = audio.wordTimestamps,
            explanationAr = "المعنى: ${s.ar}",
        )
    }

    private fun generateDictationReorder(
        id: String,
        s: RawSentence,
        audio: AudioHint,
        r: Rng,
    ): ExerciseTemplate.DictationReorder {
        val words = s.en.trim().split(Regex("\\s+"))
        val shuffled = r.shuffle(words.toMutableList())
        return ExerciseTemplate.DictationReorder(
            id = id,
            cefr = s.cefr,
            difficultyScore = cefrToDifficulty(s.cefr) + words.size * 3,
            topic = s.topic,
            audioAssetPath = audio.assetPath,
            shuffledWords = shuffled,
            correctOrder = words,
            wordTimestamps = audio.wordTimestamps,
            explanationAr = "الجملة الصحيحة: ${s.en}",
        )
    }

    private fun generateSentenceComplete(
        id: String,
        s: RawSentence,
        pool: List<RawSentence>,
        r: Rng,
    ): ExerciseTemplate.SentenceComplete? {
        val words = s.en.trim().split(Regex("\\s+"))
        if (words.size < 4) return null
        val splitAt = maxOf(2, words.size / 2)
        val prefix = words.take(splitAt).joinToString(" ") + " ___"
        val correctCompletion = words.drop(splitAt).joinToString(" ")

        val distractors = pool
            .filter { it.id != s.id && it.wordCount >= 3 }
            .map { it.en.trim().split(Regex("\\s+")).drop(it.wordCount / 2).joinToString(" ") }
            .filter { it.isNotBlank() && it != correctCompletion }
            .distinct()
            .shuffled()
            .take(Policy.MCQ_OPTION_COUNT - 1)
            .ifEmpty { listOf("is at home", "was very nice", "to the store") }

        val options = buildShuffledOptions(correctCompletion, distractors, r)
        return ExerciseTemplate.SentenceComplete(
            id = id,
            cefr = s.cefr,
            difficultyScore = cefrToDifficulty(s.cefr) + 10,
            topic = s.topic,
            sentencePrefix = prefix,
            optionsEn = options.list,
            answerIndex = options.correctIndex,
            arHint = s.ar,
            explanationAr = "إكمال الجملة: $correctCompletion",
        )
    }

    private fun generateWordSort(
        id: String,
        pairs: List<RawWordPair>,
        topic: String,
        cefr: String,
        r: Rng,
    ): ExerciseTemplate.WordSort? {
        if (pairs.size < Policy.WORD_SORT_POOL_SIZE) return null

        // Heuristic POS split: verbs tend to start with common verb patterns
        val verbHints = setOf("go", "run", "eat", "drink", "play", "work", "study",
            "walk", "talk", "read", "write", "see", "come", "take")
        val sample = r.pickN(pairs, Policy.WORD_SORT_POOL_SIZE)
        val words = sample.mapIndexed { i, p ->
            val isVerb = p.en.lowercase().split(Regex("\\s+")).first() in verbHints
            SortWord(text = p.en, correctCategory = if (isVerb) 0 else 1)
        }

        return ExerciseTemplate.WordSort(
            id = id,
            cefr = cefr,
            difficultyScore = cefrToDifficulty(cefr) + 12,
            topic = topic,
            categoryA = SortCategory(labelEn = "Actions / Verbs", labelAr = "الأفعال"),
            categoryB = SortCategory(labelEn = "Things / Nouns", labelAr = "الأسماء"),
            wordPool = r.shuffle(words.toMutableList()),
            explanationAr = "رتّب الكلمات حسب نوعها",
        )
    }

    // ─────────────────────────────────────────────────────────────
    // Distractor generation helpers
    // ─────────────────────────────────────────────────────────────

    private data class ShuffledOptions(val list: List<String>, val correctIndex: Int)

    private fun buildShuffledOptions(correct: String, distractors: List<String>, r: Rng): ShuffledOptions {
        val opts = (listOf(correct) + distractors.take(Policy.MCQ_OPTION_COUNT - 1)).toMutableList()
        while (opts.size < Policy.MCQ_OPTION_COUNT) opts += "—"
        r.shuffle(opts)
        return ShuffledOptions(list = opts, correctIndex = opts.indexOf(correct).coerceAtLeast(0))
    }

    private fun buildArDisractors(correct: String, pool: List<RawSentence>, r: Rng, count: Int): List<String> {
        val seen = mutableSetOf(normalizeAr(correct))
        val result = mutableListOf<String>()
        var guard = 0
        while (result.size < count && guard++ < Policy.DISTRACTOR_GUARD_ITERATIONS) {
            val cand = r.pick(pool).ar.trim()
            if (normalizeAr(cand) !in seen && cand.isNotBlank() && hasArabic(cand)) {
                seen += normalizeAr(cand)
                result += cand
            }
        }
        while (result.size < count) result += FALLBACK_AR[result.size % FALLBACK_AR.size]
        return result
    }

    private fun buildEnDistractors(
        correct: String,
        pool: List<RawSentence>,
        r: Rng,
        count: Int,
        singleWord: Boolean = false,
    ): List<String> {
        val norm = correct.lowercase().trim()
        val seen = mutableSetOf(norm)
        val result = mutableListOf<String>()
        var guard = 0
        while (result.size < count && guard++ < Policy.DISTRACTOR_GUARD_ITERATIONS) {
            val s = r.pick(pool)
            val cand = if (singleWord) {
                val words = s.en.split(Regex("\\s+")).filter { it.length >= 3 && it.lowercase() !in FUNCTION_WORDS }
                if (words.isEmpty()) continue else r.pick(words)
            } else s.en.trim()
            if (cand.lowercase() !in seen && cand.isNotBlank()) {
                seen += cand.lowercase()
                result += cand
            }
        }
        while (result.size < count) result += FALLBACK_EN[result.size % FALLBACK_EN.size]
        return result
    }

    // ─────────────────────────────────────────────────────────────
    // Utility
    // ─────────────────────────────────────────────────────────────

    private fun cefrToDifficulty(cefr: String): Int = when (cefr.uppercase().take(2)) {
        "A1" -> 10; "A2" -> 25; "B1" -> 45; "B2" -> 65; "C1" -> 80; "C2" -> 95; else -> 50
    }

    private fun normalizeAr(s: String): String = s.trim().replace(Regex("\\s+"), " ")
    private fun hasArabic(s: String): Boolean = s.any { it in '\u0600'..'\u06FF' }

    private companion object {
        // High-frequency English function words excluded from FillBlank / SpotError targets
        val FUNCTION_WORDS = setOf(
            "the", "a", "an", "is", "are", "was", "were", "be", "been", "being",
            "have", "has", "had", "do", "does", "did", "will", "would", "shall",
            "should", "may", "might", "must", "can", "could", "to", "of", "in",
            "on", "at", "by", "for", "with", "and", "or", "but", "not", "i",
            "he", "she", "it", "we", "they", "you", "me", "him", "her", "us",
            "them", "my", "his", "its", "our", "their", "this", "that", "these",
            "those", "as", "so", "if", "than", "then", "when", "where", "who",
        )

        val FALLBACK_AR = listOf("أنا ذاهب إلى المنزل", "الطقس جيد اليوم", "أحب القهوة كثيرًا")
        val FALLBACK_EN = listOf("I like coffee", "The weather is nice", "She goes to school")
    }
}
