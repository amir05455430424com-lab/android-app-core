package com.emir.englishapp.ui.screens.daily

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun DailyRewardScreen(
    globalIndex: Int,
    scorePercent: Int,
    masteryPercent: Int,
    stars: Int,
    correct: Int,
    total: Int,
    xp: Int,
    unlockedNext: Boolean,
    onBackHome: () -> Unit,
    onOpenPath: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("🎉 تهانينا!", style = MaterialTheme.typography.titleLarge)

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
        ) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("نتيجة التحدي", style = MaterialTheme.typography.titleMedium)
                Text("الإجابات الصحيحة: $correct / ${total.coerceAtLeast(1)}", style = MaterialTheme.typography.bodyMedium)
                Text("Score: $scorePercent%", style = MaterialTheme.typography.bodyMedium)
                Text("Mastery: $masteryPercent%", style = MaterialTheme.typography.bodyMedium)
                Text("Stars: $stars / 3", style = MaterialTheme.typography.bodyMedium)
                Text("XP: +$xp", style = MaterialTheme.typography.bodyMedium)
                if (unlockedNext) {
                    Text("✅ تم فتح الوحدة التالية!", style = MaterialTheme.typography.bodyMedium)
                } else {
                    Text("🔒 لم يتم فتح التالي بعد (تحتاج Mastery ≥ 80%)", style = MaterialTheme.typography.bodyMedium)
                }
            }
        }

        Spacer(Modifier.height(6.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onClick = onOpenPath, modifier = Modifier.weight(1f)) { Text("المسار") }
            OutlinedButton(onClick = onBackHome, modifier = Modifier.weight(1f)) { Text("الرئيسية") }
        }
    }
}
