package com.emir.englishapp.ui.screens.lessons.level

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.emir.englishapp.domain.model.lesson.LessonItem
import com.emir.englishapp.domain.model.lesson.UnitBlock

@Composable
fun LevelScreen(
    viewModel: LevelViewModel,
    onBack: () -> Unit,
    onOpenLesson: (lessonId: String) -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()

    LaunchedEffect(Unit) { viewModel.load() }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        when {
            uiState.isLoading -> {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                    CircularProgressIndicator()
                }
            }

            uiState.error != null -> {
                Text(text = uiState.error ?: "", color = MaterialTheme.colorScheme.error)
            }

            else -> {
                // Flatten order to apply unlock rules across the level
                val flatIds = buildList {
                    uiState.units.forEach { u -> u.lessons.forEach { add(it.lessonId) } }
                }

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 32.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    itemsIndexed(uiState.units) { _, unit ->
                        UnitSection(
                            unit = unit,
                            levelId = viewModel.levelId,
                            flatIds = flatIds,
                            unlockedIndex = uiState.unlockedIndex,
                            completed = uiState.completed,
                            stepMap = uiState.lessonStepIndex,
                            favoriteKeys = uiState.favoriteLessonKeys,
                            onToggleFavorite = { lessonId -> viewModel.toggleFavoriteLesson(lessonId) },
                            onOpenLesson = onOpenLesson
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun UnitSection(
    unit: UnitBlock,
    levelId: Int,
    flatIds: List<String>,
    unlockedIndex: Int,
    completed: Set<String>,
    stepMap: Map<String, Int>,
    favoriteKeys: Set<String>,
    onToggleFavorite: (lessonId: String) -> Unit,
    onOpenLesson: (lessonId: String) -> Unit
) {
    Column {
        Text(
            text = unit.titleAr.ifBlank { unit.titleEn },
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.ExtraBold
        )
        Spacer(Modifier.height(8.dp))

        unit.lessons.forEach { lesson ->
            val idx = flatIds.indexOf(lesson.lessonId).coerceAtLeast(0)
            val isCompleted = completed.contains(lesson.lessonId)
            val isLocked = idx > unlockedIndex && !isCompleted

            val key = "$levelId|${lesson.lessonId}"
            val stepIndex = stepMap.getOrDefault(key, 0)
            val isInProgress = !isCompleted && !isLocked && stepIndex > 0
            val isFav = favoriteKeys.contains(key)

            LessonCard(
                lesson = lesson,
                isLocked = isLocked,
                isFav = isFav,
                isInProgress = isInProgress,
                isCompleted = isCompleted,
                stepIndex = stepIndex,
                stepsCount = 6, // ✅ يعتمد على lesson.steps
                onOpenLesson = onOpenLesson,
                onToggleFavorite = onToggleFavorite
            )

            Spacer(Modifier.height(10.dp))
        }
    }
}

@Composable
private fun LessonCard(
    lesson: LessonItem,
    isLocked: Boolean,
    isFav: Boolean,
    isInProgress: Boolean,
    isCompleted: Boolean,
    stepIndex: Int,
    stepsCount: Int,
    onOpenLesson: (String) -> Unit,
    onToggleFavorite: (String) -> Unit,
) {
    val containerColor = when {
        isLocked -> MaterialTheme.colorScheme.surfaceVariant
        isCompleted -> MaterialTheme.colorScheme.primaryContainer
        isInProgress -> MaterialTheme.colorScheme.tertiaryContainer
        else -> MaterialTheme.colorScheme.surface
    }

    val statusText = when {
        isLocked -> "مقفول"
        isCompleted -> "مكتمل"
        isInProgress -> "قيد التعلم"
        else -> "غير مبدوء"
    }

    val progressText = "${stepIndex.coerceAtLeast(0)}/${stepsCount.coerceAtLeast(1)}"

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(enabled = !isLocked) { onOpenLesson(lesson.lessonId) },
        colors = CardDefaults.cardColors(containerColor = containerColor)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {

            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.secondaryContainer
                ) {
                    Icon(
                        imageVector = if (isLocked) Icons.Filled.Lock else Icons.Filled.MenuBook,
                        contentDescription = null,
                        modifier = Modifier.padding(8.dp)
                    )
                }

                Text(
                    text = lesson.titleAr.ifBlank { lesson.titleEn },
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .weight(1f)
                        .padding(start = 10.dp)
                )

                IconButton(onClick = { onToggleFavorite(lesson.lessonId) }) {
                    Icon(
                        imageVector = if (isFav) Icons.Filled.Star else Icons.Filled.StarBorder,
                        contentDescription = null
                    )
                }
            }

            Spacer(Modifier.height(8.dp))

            Surface(
                shape = RoundedCornerShape(999.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 0.dp
            ) {
                Text(
                    text = statusText,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                )
            }

            Spacer(Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "$stepsCount Steps",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.weight(1f)
                )

                Text(
                    text = "Progress: $progressText",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold
                )
            }

        }
    }

}