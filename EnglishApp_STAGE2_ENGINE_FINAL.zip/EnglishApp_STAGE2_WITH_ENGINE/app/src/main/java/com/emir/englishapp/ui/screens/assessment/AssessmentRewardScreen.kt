package com.emir.englishapp.ui.screens.assessment

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// ─────────────────────────────────────────────────────────────
// Colors
// ─────────────────────────────────────────────────────────────
private val Green = Color(0xFF58CC02)
private val GreenDark = Color(0xFF46A302)
private val GreenLight = Color(0xFFD7FFB8)
private val StarYellow = Color(0xFFFFC800)
private val StarGray = Color(0xFFE5E5E5)
private val Red = Color(0xFFEA2B2B)
private val Blue = Color(0xFF1CB0F6)
private val TextDark = Color(0xFF4B4B4B)
private val TextMuted = Color(0xFFAFAFAF)
private val XpPurple = Color(0xFF9B59B6)
private val XpPurpleLight = Color(0xFFF5E6FF)

// ─────────────────────────────────────────────────────────────
// Screen
// ─────────────────────────────────────────────────────────────

@Composable
fun AssessmentRewardScreen(
    result: SessionResultUi,
    moduleTitleAr: String = "",
    moduleTitleEn: String = "",
    onContinue: () -> Unit,
    onRetry: () -> Unit,
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
            .statusBarsPadding()
            .navigationBarsPadding(),
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 28.dp, vertical = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(24.dp),
        ) {
            Spacer(Modifier.height(8.dp))

            // ── Module title ─────────────────────────────────────
            if (moduleTitleAr.isNotBlank()) {
                Text(
                    text = moduleTitleAr,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = TextDark,
                    textAlign = TextAlign.Center,
                )
            }

            // ── Stars ─────────────────────────────────────────────
            AnimatedStars(stars = result.starsAwarded)

            // ── Mastery ring ─────────────────────────────────────
            MasteryRing(
                masteryPercent = result.masteryPercent,
                scorePercent = result.scorePercent,
            )

            // ── Stats row ─────────────────────────────────────────
            StatsRow(result = result)

            // ── XP badge ─────────────────────────────────────────
            XpBadge(xp = result.totalXpEarned)

            // ── Time stat ─────────────────────────────────────────
            val seconds = result.totalTimeMs / 1000
            Text(
                text = "⏱ ${seconds}s • ${result.correctCount}/${result.totalCount} صحيح",
                fontSize = 15.sp,
                color = TextMuted,
                textAlign = TextAlign.Center,
            )

            Spacer(Modifier.height(8.dp))

            // ── Action buttons ────────────────────────────────────
            Button(
                onClick = onContinue,
                modifier = Modifier.fillMaxWidth().height(58.dp),
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Green),
            ) {
                Text(
                    text = "متابعة ←",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color.White,
                )
            }

            OutlinedButton(
                onClick = onRetry,
                modifier = Modifier.fillMaxWidth().height(54.dp),
                shape = RoundedCornerShape(18.dp),
                border = androidx.compose.foundation.BorderStroke(2.dp, Green),
            ) {
                Text(
                    text = "إعادة المحاولة",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Green,
                )
            }

            Spacer(Modifier.height(16.dp))
        }
    }
}

// ─────────────────────────────────────────────────────────────
// Stars with pop animation
// ─────────────────────────────────────────────────────────────

@Composable
private fun AnimatedStars(stars: Int) {
    val scales = List(3) { remember { Animatable(0f) } }

    LaunchedEffect(stars) {
        scales.forEachIndexed { i, anim ->
            launch {
                delay(i * 200L)
                anim.animateTo(1.3f, tween(200))
                anim.animateTo(1f, tween(120))
            }
        }
    }

    Row(
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        scales.forEachIndexed { i, scale ->
            val earned = i < stars
            Icon(
                imageVector = if (earned) Icons.Default.Star else Icons.Outlined.StarBorder,
                contentDescription = null,
                tint = if (earned) StarYellow else StarGray,
                modifier = Modifier
                    .size(if (i == 1) 64.dp else 52.dp)
                    .scale(scale.value),
            )
        }
    }
}

// ─────────────────────────────────────────────────────────────
// Mastery ring
// ─────────────────────────────────────────────────────────────

@Composable
private fun MasteryRing(masteryPercent: Int, scorePercent: Int) {
    val animProgress = remember { Animatable(0f) }
    LaunchedEffect(masteryPercent) {
        animProgress.animateTo(masteryPercent / 100f, tween(1000))
    }

    val ringColor = when {
        masteryPercent >= 80 -> Green
        masteryPercent >= 50 -> Color(0xFFFFC107)
        else -> Red
    }

    Box(contentAlignment = Alignment.Center, modifier = Modifier.size(160.dp)) {
        CircularProgressIndicator(
            progress = { animProgress.value },
            modifier = Modifier.fillMaxSize(),
            color = ringColor,
            trackColor = Color(0xFFE5E5E5),
            strokeWidth = 14.dp,
            strokeCap = StrokeCap.Round,
        )
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = "$masteryPercent%",
                fontSize = 32.sp,
                fontWeight = FontWeight.ExtraBold,
                color = ringColor,
            )
            Text(
                text = "إتقان",
                fontSize = 14.sp,
                color = TextMuted,
            )
        }
    }
}

// ─────────────────────────────────────────────────────────────
// Stats row
// ─────────────────────────────────────────────────────────────

@Composable
private fun StatsRow(result: SessionResultUi) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceEvenly,
    ) {
        StatCard(
            emoji = "✅",
            value = result.correctCount.toString(),
            label = "صحيح",
            color = Green,
            bgColor = GreenLight,
        )
        StatCard(
            emoji = "❌",
            value = result.incorrectExercises.size.toString(),
            label = "خطأ",
            color = Red,
            bgColor = Color(0xFFFFDFE0),
        )
        StatCard(
            emoji = "🎯",
            value = "${result.scorePercent}%",
            label = "النتيجة",
            color = Blue,
            bgColor = Color(0xFFDDF4FF),
        )
    }
}

@Composable
private fun StatCard(emoji: String, value: String, label: String, color: Color, bgColor: Color) {
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = bgColor,
        modifier = Modifier.size(width = 96.dp, height = 88.dp),
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Text(text = emoji, fontSize = 22.sp)
            Text(text = value, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = color)
            Text(text = label, fontSize = 12.sp, color = TextMuted)
        }
    }
}

// ─────────────────────────────────────────────────────────────
// XP badge
// ─────────────────────────────────────────────────────────────

@Composable
private fun XpBadge(xp: Int) {
    val animXp = remember { Animatable(0f) }
    LaunchedEffect(xp) {
        animXp.animateTo(xp.toFloat(), tween(800))
    }

    Surface(
        shape = RoundedCornerShape(20.dp),
        color = XpPurpleLight,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 24.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
        ) {
            Box(
                modifier = Modifier.size(48.dp).background(XpPurple, CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                Text("⚡", fontSize = 22.sp)
            }
            Column(modifier = Modifier.padding(start = 16.dp)) {
                Text(
                    text = "+${animXp.value.toInt()} XP",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = XpPurple,
                )
                Text(
                    text = "نقاط الخبرة المكتسبة",
                    fontSize = 13.sp,
                    color = TextMuted,
                )
            }
        }
    }
}
