package com.emir.englishapp.ui.theme

import androidx.compose.ui.graphics.Color

// الألوان الأساسية
val Primary = Color(0xFF58CC02)
val Secondary = Color(0xFFFFC800)
val Background = Color(0xFFF7F9FC)
val Surface = Color(0xFFFFFFFF)

// ألوان الحالة
val Success = Color(0xFF58CC02)
val Warning = Color(0xFFFFC107)
val Locked = Color(0xFFE5E5E5)
val LockedText = Color(0xFFAFAFAF)
val Border = Color(0xFFE2A000)
