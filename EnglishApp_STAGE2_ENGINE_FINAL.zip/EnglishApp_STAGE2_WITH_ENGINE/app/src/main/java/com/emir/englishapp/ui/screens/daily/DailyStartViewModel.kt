package com.emir.englishapp.ui.screens.daily

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.emir.englishapp.data.repository.AppRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.time.LocalDate

class DailyStartViewModel(
    private val repo: AppRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(DailyStartUiState())
    val uiState: StateFlow<DailyStartUiState> = _uiState

    init {
        viewModelScope.launch {
            val today = LocalDate.now().toString()
            try { repo.resetDailyIfNewDay(today) } catch (_: Throwable) {}

            val idx = try { repo.currentUnitGlobalIndex.first() } catch (_: Throwable) { 1 }
            load(today, idx)
        }
    }

    fun refresh() {
        viewModelScope.launch {
            val today = LocalDate.now().toString()
            try { repo.resetDailyIfNewDay(today) } catch (_: Throwable) {}

            val idx = try { repo.currentUnitGlobalIndex.first() } catch (_: Throwable) {
                _uiState.value.currentGlobalIndex.coerceAtLeast(1)
            }

            load(today, idx)
        }
    }

    private suspend fun load(today: String, currentGlobalIndex: Int) {
        _uiState.update { it.copy(isLoading = true, error = null, today = today) }

        val done = try { repo.isDailySessionDone(today) } catch (_: Throwable) { false }

        // 1) Load all units once
        val units = try { repo.getAllUnitsFlat() } catch (_: Throwable) { emptyList() }

        // 2) If course is empty
        if (units.isEmpty()) {
            _uiState.update {
                it.copy(
                    isLoading = false,
                    error = "الكورس غير محمّل أو فارغ.",
                    isDoneToday = done,
                    currentGlobalIndex = currentGlobalIndex
                )
            }
            return
        }

        // 3) Resolve current unit (fallback to first by globalIndex)
        val resolvedUnit = units.firstOrNull { it.globalIndex == currentGlobalIndex }
            ?: units.minByOrNull { it.globalIndex }

        val resolvedIndex = resolvedUnit?.globalIndex ?: currentGlobalIndex

        // 4) Persist corrected index so the error never repeats
        if (resolvedIndex != currentGlobalIndex) {
            try { repo.setCurrentUnitGlobalIndex(resolvedIndex) } catch (_: Throwable) {}
        }

        if (resolvedUnit == null) {
            _uiState.update {
                it.copy(
                    isLoading = false,
                    error = "لم يتم العثور على وحدة صالحة في الكورس.",
                    isDoneToday = done,
                    currentGlobalIndex = resolvedIndex
                )
            }
            return
        }

        // 5) Update UI
        _uiState.update {
            it.copy(
                isLoading = false,
                error = null,
                isDoneToday = done,
                currentGlobalIndex = resolvedIndex,
                unitTitleAr = resolvedUnit.titleAr,
                unitTitleEn = resolvedUnit.titleEn,
                xpReward = resolvedUnit.xpReward
            )
        }
    }
}

class DailyStartViewModelFactory(
    private val repo: AppRepository
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return DailyStartViewModel(repo) as T
    }
}