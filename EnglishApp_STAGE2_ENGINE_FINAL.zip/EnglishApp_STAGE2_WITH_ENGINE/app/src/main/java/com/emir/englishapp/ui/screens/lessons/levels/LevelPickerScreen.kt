package com.emir.englishapp.ui.screens.lessons.levels

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun LevelPickerScreen(
    viewModel: LevelPickerViewModel,
    onOpenLevel: (levelId: Int) -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()

    // ensure loaded once
    androidx.compose.runtime.LaunchedEffect(Unit) {
        viewModel.load()
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
when {
            uiState.isLoading -> {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                    CircularProgressIndicator()
                }
            }
            uiState.error != null -> {
                Text(
                    text = uiState.error ?: "",
                    color = MaterialTheme.colorScheme.error
                )
            }
            else -> {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 32.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(uiState.levels) { row ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable(enabled = row.meta.id == 1) { onOpenLevel(row.meta.id) }
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text(
                                    row.meta.titleAr.ifBlank { "Level ${row.meta.id}" },
                                    style = MaterialTheme.typography.titleMedium
                                )
                                if (row.meta.id != 1) {
                                    Spacer(Modifier.height(6.dp))
                                    Text("قريباً", color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                                }
                                Spacer(Modifier.height(6.dp))
                                Text("Units: ${row.unitsCount}  •  Lessons: ${row.lessonsCount}")
                                Text("Completed: ${row.completedCount}")
                            }
                        }
                    }
                }
            }
        }
    }
}
