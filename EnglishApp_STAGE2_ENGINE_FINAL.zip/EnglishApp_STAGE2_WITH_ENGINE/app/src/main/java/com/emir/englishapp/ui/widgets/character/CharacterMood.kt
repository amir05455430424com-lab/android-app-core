package com.emir.englishapp.ui.widgets.character

enum class CharacterMood {
    IDLE,
    HAPPY,
    ENCOURAGE,
    THINKING,
    WARNING,
    LEVEL_UP
}
