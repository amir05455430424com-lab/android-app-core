package com.emir.englishapp.ui.screens.prounitlesson

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.emir.englishapp.data.repository.AppRepository
import com.emir.englishapp.ui.screens.unitlesson.UnitLessonUiState
import com.emir.englishapp.ui.screens.unitlesson.UnitStepResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

class ProUnitLessonViewModel(
    private val repo: AppRepository,
    private val globalIndex: Int,
    private val stepIndex: Int,
    private val stepsTotal: Int = 4,
    private val stepSize: Int = 5
) : ViewModel() {

    private val _uiState = MutableStateFlow(UnitLessonUiState(globalIndex = globalIndex, stepIndex = stepIndex, stepsTotal = stepsTotal))
    val uiState: StateFlow<UnitLessonUiState> = _uiState

    init {
        viewModelScope.launch { load() }

        // Favorites apply to questions too
        viewModelScope.launch {
            repo.favoriteQuestionIds.collect { ids ->
                _uiState.update { it.copy(favoriteIds = ids) }
            }
        }
    }

    fun toggleFavoriteCurrent() {
        val q = _uiState.value.questions.getOrNull(_uiState.value.index) ?: return
        viewModelScope.launch { repo.toggleFavoriteQuestion(q.id) }
    }

    private suspend fun load() {
        _uiState.update { it.copy(isLoading = true, error = null) }

        val unit = runCatching { repo.getAllProUnitsFlat().firstOrNull { u -> u.globalIndex == globalIndex } }.getOrNull()
        if (unit == null) {
            _uiState.update { it.copy(isLoading = false, error = "لم يتم العثور على الوحدة (PRO).") }
            return
        }

        if (stepIndex == 0) {
            runCatching { repo.resetProUnitRun(globalIndex) }
            runCatching { repo.setProUnitStepIndex(globalIndex, 0) }
        }

        val questions = runCatching {
            repo.getProUnitLessonStepQuestions(globalIndex = globalIndex, stepIndex = stepIndex, stepsTotal = stepsTotal, stepSize = stepSize)
        }.getOrElse { emptyList() }

        if (questions.isEmpty()) {
            _uiState.update { it.copy(isLoading = false, error = "لا توجد أسئلة لهذه الخطوة (PRO).") }
            return
        }

        val now = System.currentTimeMillis()
        _uiState.update {
            it.copy(
                isLoading = false,
                error = null,
                unitTitleAr = unit.titleAr,
                unitTitleEn = unit.titleEn,
                xpReward = unit.xpReward,
                questions = questions,
                index = 0,
                selected = null,
                correctCount = 0,
                questionStartedAtMs = now,
                totalAnswerTimeMs = 0L
            )
        }
    }

    fun select(optionIndex: Int) {
        _uiState.update { st ->
            if (st.selected != null) return@update st
            val q = st.questions.getOrNull(st.index) ?: return@update st
            val ok = optionIndex == q.answerIndex
            val spent = (System.currentTimeMillis() - st.questionStartedAtMs).coerceAtLeast(0L)

            viewModelScope.launch {
                runCatching { repo.recordQuestionAttempt(question = q, correct = ok) }
            }

            st.copy(
                selected = optionIndex,
                correctCount = st.correctCount + if (ok) 1 else 0,
                totalAnswerTimeMs = st.totalAnswerTimeMs + spent
            )
        }
    }

    fun next(onFinished: (UnitStepResult) -> Unit) {
        val st = _uiState.value
        if (st.selected == null) return

        if (st.index + 1 >= st.questions.size) {
            viewModelScope.launch {
                val result = finalizeStep(st)
                onFinished(result)
            }
        } else {
            val now = System.currentTimeMillis()
            _uiState.update {
                it.copy(
                    index = it.index + 1,
                    selected = null,
                    questionStartedAtMs = now
                )
            }
        }
    }

    private suspend fun finalizeStep(st: UnitLessonUiState): UnitStepResult {
        val total = st.questions.size.coerceAtLeast(1)
        val accuracy = st.correctCount.toFloat() / total.toFloat()
        val scorePercent = (accuracy * 100f).roundToInt().coerceIn(0, 100)

        val avgSec = (st.totalAnswerTimeMs.toFloat() / total.toFloat()) / 1000f
        val speedBonus = ((10f - avgSec) / 10f).coerceIn(0f, 1f)
        val mastery = (0.7f * accuracy + 0.3f * speedBonus).coerceIn(0f, 1f)
        val masteryPercent = (mastery * 100f).roundToInt().coerceIn(0, 100)

        val stars = when {
            masteryPercent >= 90 -> 3
            masteryPercent >= 80 -> 2
            masteryPercent >= 65 -> 1
            else -> 0
        }

        repo.addToProUnitRun(globalIndex, correctDelta = st.correctCount, totalDelta = total, timeDeltaMs = st.totalAnswerTimeMs)

        val isFinal = (stepIndex >= stepsTotal - 1)
        var unlockedNext = false

        val wrong = (total - st.correctCount).coerceAtLeast(0)
        val xpFromAnswers = st.correctCount * 2 + wrong * 1
        val perfectBonus = if (st.correctCount == total) 10 else 0
        var xpEarned = xpFromAnswers + perfectBonus

        if (!isFinal) {
            repo.setProUnitStepIndex(globalIndex, (stepIndex + 1).coerceAtMost(stepsTotal))
        } else {
            val (cAll, tAll, msAll) = repo.getProUnitRun(globalIndex)
            val tSafe = tAll.coerceAtLeast(1)
            val accAll = cAll.toFloat() / tSafe.toFloat()
            val avgAllSec = (msAll.toFloat() / tSafe.toFloat()) / 1000f
            val speedAll = ((10f - avgAllSec) / 10f).coerceIn(0f, 1f)
            val masteryAll = (0.7f * accAll + 0.3f * speedAll).coerceIn(0f, 1f)
            val masteryAllPercent = (masteryAll * 100f).roundToInt().coerceIn(0, 100)

            val starsAll = when {
                masteryAllPercent >= 90 -> 3
                masteryAllPercent >= 80 -> 2
                masteryAllPercent >= 65 -> 1
                else -> 0
            }

            xpEarned += st.xpReward
            repo.addTotalXp(xpEarned)
            repo.saveProUnitResult(globalIndex = globalIndex, scorePercent = (accAll * 100f).roundToInt(), masteryPercent = masteryAllPercent, stars = starsAll)

            if (masteryAllPercent >= 80) {
                val current = repo.proCurrentUnitGlobalIndex.first()
                if (current <= globalIndex) {
                    repo.setProCurrentUnitGlobalIndex(globalIndex + 1)
                    unlockedNext = true
                }
            }

            repo.setProUnitStepIndex(globalIndex, stepsTotal)
            repo.resetProUnitRun(globalIndex)

            return UnitStepResult(
                globalIndex = globalIndex,
                stepIndex = stepIndex,
                stepsTotal = stepsTotal,
                scorePercent = (accAll * 100f).roundToInt().coerceIn(0, 100),
                masteryPercent = masteryAllPercent,
                stars = starsAll,
                correct = cAll,
                total = tSafe,
                xpEarned = xpEarned,
                unlockedNext = unlockedNext,
                isFinal = true
            )
        }

        return UnitStepResult(
            globalIndex = globalIndex,
            stepIndex = stepIndex,
            stepsTotal = stepsTotal,
            scorePercent = scorePercent,
            masteryPercent = masteryPercent,
            stars = stars,
            correct = st.correctCount,
            total = total,
            xpEarned = xpEarned,
            unlockedNext = unlockedNext,
            isFinal = false
        )
    }
}

class ProUnitLessonViewModelFactory(
    private val repo: AppRepository,
    private val globalIndex: Int,
    private val stepIndex: Int
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        @Suppress("UNCHECKED_CAST")
        return ProUnitLessonViewModel(repo, globalIndex, stepIndex) as T
    }
}
