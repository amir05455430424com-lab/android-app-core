package com.emir.englishapp.ui.screens.proquestion

import androidx.compose.runtime.Composable
import com.emir.englishapp.domain.model.questionv2.FillBlankQuestionV2
import com.emir.englishapp.domain.model.questionv2.McqQuestionV2
import com.emir.englishapp.domain.model.questionv2.QuestionV2
import com.emir.englishapp.domain.model.questionv2.ReorderQuestionV2

/**
 * V2 renderer for Pro Path questions.
 *
 * Pure UI dispatching: no business logic here.
 */
@Composable
fun QuestionRenderer(
    question: QuestionV2,
    state: ProQuestionUiState,
    onEvent: (ProQuestionEvent) -> Unit,
) {
    when (question) {
        is McqQuestionV2 -> McqView(q = question, state = state, onEvent = onEvent)
        is FillBlankQuestionV2 -> FillBlankView(q = question, state = state, onEvent = onEvent)
        is ReorderQuestionV2 -> ReorderView(q = question, state = state, onEvent = onEvent)
    }
}

@Composable
private fun McqView(
    q: McqQuestionV2,
    state: ProQuestionUiState,
    onEvent: (ProQuestionEvent) -> Unit,
) {
    ProMcqBlock(
        q = q,
        selectedIndex = state.selectedIndex,
        isAnswered = state.isAnswered,
        isCorrect = state.isCorrect,
        onSelect = { onEvent(ProQuestionEvent.SelectOption(it)) },
    )
}

@Composable
private fun FillBlankView(
    q: FillBlankQuestionV2,
    state: ProQuestionUiState,
    onEvent: (ProQuestionEvent) -> Unit,
) {
    ProFillBlankBlock(
        q = q,
        selectedIndex = state.selectedIndex,
        isAnswered = state.isAnswered,
        isCorrect = state.isCorrect,
        onSelect = { onEvent(ProQuestionEvent.SelectOption(it)) },
    )
}

@Composable
private fun ReorderView(
    q: ReorderQuestionV2,
    state: ProQuestionUiState,
    onEvent: (ProQuestionEvent) -> Unit,
) {
    ProReorderBlock(
        q = q,
        available = state.reorderAvailable,
        selected = state.reorderSelected,
        isAnswered = state.isAnswered,
        isCorrect = state.isCorrect,
        onPick = { onEvent(ProQuestionEvent.PickWord(it)) },
        onUnpick = { onEvent(ProQuestionEvent.UnpickWord(it)) },
    )
}
