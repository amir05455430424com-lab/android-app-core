package com.emir.englishapp.ui.screens.proquestion

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.emir.englishapp.ui.widgets.character.CharacterMood
import com.emir.englishapp.ui.widgets.character.LearningCharacterBanner

@Composable
fun ProQuestionScreen(
    state: ProQuestionUiState,
    onBack: () -> Unit,
    onToggleFavorite: () -> Unit,
    onEvent: (ProQuestionEvent) -> Unit,
    onNext: () -> Unit,
    currentAudioPath: String? = null,
    onPlayAudio: ((String) -> Unit)? = null,
) {
    val successColor = Color(0xFF58CC02) // Duolingo Green
    val errorColor = Color(0xFFEA2B2B)   // Duolingo Red

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // 1. Top Bar with Progress
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.Gray)
                }
                
                val total = state.questions.size.coerceAtLeast(1)
                val progress = (state.index).toFloat() / total.toFloat()
                
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier
                        .weight(1f)
                        .height(12.dp)
                        .padding(horizontal = 8.dp),
                    color = successColor,
                    trackColor = Color(0xFFE5E5E5),
                    strokeCap = StrokeCap.Round
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Star, contentDescription = null, tint = Color(0xFFFFC107), modifier = Modifier.size(20.dp))
                    Text(
                        text = "${state.correctCount}",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        modifier = Modifier.padding(start = 4.dp)
                    )
                }
            }

            // 2. Main Content Area (Scrollable)
            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 24.dp)
            ) {
                Spacer(modifier = Modifier.height(16.dp))

                // Character as the "Question Speaker"
                val q = state.questions.getOrNull(state.index)
                
                LearningCharacterBanner(
                    mood = when {
                        state.isAnswered && state.isCorrect == true -> CharacterMood.HAPPY
                        state.isAnswered && state.isCorrect == false -> CharacterMood.ENCOURAGE
                        else -> CharacterMood.IDLE
                    },
                    message = when(q) {
                        is com.emir.englishapp.domain.model.questionv2.McqQuestionV2 -> q.promptAr ?: "اختر الإجابة الصحيحة"
                        is com.emir.englishapp.domain.model.questionv2.ReorderQuestionV2 -> "رتب الكلمات لتكوين جملة"
                        else -> "أكمل الفراغ بالكلمة المناسبة"
                    },
                    bubbleText = null
                )

                Spacer(modifier = Modifier.height(24.dp))

                // The Question Text (The missing English sentence)
                AnimatedContent(
                    targetState = state.index,
                    transitionSpec = {
                        (slideInHorizontally { it } + fadeIn()) togetherWith
                        (slideOutHorizontally { -it } + fadeOut())
                    },
                    label = "QuestionAnimation"
                ) { targetIndex ->
                    val currentQ = state.questions.getOrNull(targetIndex)
                    if (currentQ != null) {
                        Column {
                            // Important: Display the actual English question prominently!
                            val mainText = when(currentQ) {
                                is com.emir.englishapp.domain.model.questionv2.McqQuestionV2 -> currentQ.sentenceEn ?: currentQ.termEn ?: ""
                                is com.emir.englishapp.domain.model.questionv2.FillBlankQuestionV2 -> currentQ.sentenceEn
                                is com.emir.englishapp.domain.model.questionv2.ReorderQuestionV2 -> currentQ.explanationAr ?: "رتب الجملة الإنجليزية التالية:"
                                else -> ""
                            }

                            if (mainText.isNotBlank()) {
                                Column(modifier = Modifier.padding(bottom = 24.dp)) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                    ) {
                                        if (!currentAudioPath.isNullOrBlank() && onPlayAudio != null) {
                                            IconButton(
                                                onClick = { onPlayAudio(currentAudioPath) },
                                                modifier = Modifier
                                                    .background(Color(0xFF1CB0F6), RoundedCornerShape(12.dp))
                                                    .size(48.dp)
                                            ) {
                                                Icon(Icons.Filled.VolumeUp, contentDescription = "Play", tint = Color.White)
                                            }
                                            Spacer(modifier = Modifier.padding(12.dp))
                                        }
                                        
                                        Text(
                                            text = mainText,
                                            style = MaterialTheme.typography.headlineSmall.copy(
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 24.sp,
                                                lineHeight = 32.sp,
                                                color = Color(0xFF4B4B4B)
                                            ),
                                            modifier = Modifier.weight(1f)
                                        )

                                        val isFav = state.favoriteIds.contains(currentQ.id)
                                        IconButton(onClick = onToggleFavorite) {
                                            Icon(
                                                if (isFav) Icons.Filled.Star else Icons.Outlined.StarBorder,
                                                contentDescription = "Fav",
                                                tint = if (isFav) Color(0xFFFFC107) else Color.Gray
                                            )
                                        }
                                    }
                                    
                                    // Explanation/Hint under the main text
                                    if (currentQ is com.emir.englishapp.domain.model.questionv2.ReorderQuestionV2 && currentQ.explanationAr != null) {
                                        Text(
                                            text = currentQ.explanationAr ?: "",
                                            style = MaterialTheme.typography.bodyMedium.copy(
                                                color = Color.Gray,
                                                fontWeight = FontWeight.Medium
                                            ),
                                            modifier = Modifier.padding(top = 8.dp, start = if (!currentAudioPath.isNullOrBlank()) 60.dp else 0.dp)
                                        )
                                    }
                                }
                            }

                            QuestionRenderer(
                                question = currentQ,
                                state = state,
                                onEvent = onEvent,
                            )
                        }
                    }
                }
                
                Spacer(modifier = Modifier.height(100.dp)) // Padding for bottom bar
            }
        }

        // 3. Duolingo Style Bottom Feedback Bar
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .background(
                    if (!state.isAnswered) Color.Transparent 
                    else if (state.isCorrect == true) Color(0xFFD7FFB8) 
                    else Color(0xFFFFDFE0)
                )
                .padding(bottom = 16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 16.dp)
            ) {
                if (state.isAnswered) {
                    val ok = state.isCorrect == true
                    Text(
                        text = if (ok) "ممتاز! إجابة صحيحة ✅" else "الإجابة الصحيحة هي: ❌",
                        color = if (ok) Color(0xFF43A047) else Color(0xFFE53935),
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 20.sp
                    )
                    
                    // If wrong, show the correct answer clearly
                    if (!ok) {
                        val qNow = state.questions.getOrNull(state.index)
                        val correctAnswerText = when(qNow) {
                            is com.emir.englishapp.domain.model.questionv2.McqQuestionV2 -> {
                                (qNow.optionsAr ?: emptyList()).getOrNull(qNow.answerIndex) ?: (qNow.optionsEn ?: emptyList()).getOrNull(qNow.answerIndex)
                            }
                            is com.emir.englishapp.domain.model.questionv2.ReorderQuestionV2 -> qNow.correctOrder.joinToString(" ")
                            is com.emir.englishapp.domain.model.questionv2.FillBlankQuestionV2 -> qNow.optionsEn.getOrNull(qNow.answerIndex)
                            else -> ""
                        }
                        
                        Text(
                            text = correctAnswerText ?: "",
                            color = Color(0xFFE53935),
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                }

                Button(
                    onClick = { if (state.isAnswered) onNext() else onEvent(ProQuestionEvent.Confirm) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = when {
                            !state.isAnswered -> if (canConfirm(state)) successColor else Color(0xFFE5E5E5)
                            state.isCorrect == true -> successColor
                            else -> errorColor
                        },
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(16.dp),
                    enabled = (!state.isAnswered && canConfirm(state)) || state.isAnswered
                ) {
                    Text(
                        text = if (!state.isAnswered) "تحقق" else "متابعة",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                }
            }
        }
    }
}

private fun canConfirm(state: ProQuestionUiState): Boolean {
    val q = state.questions.getOrNull(state.index) ?: return false
    return when (q) {
        is com.emir.englishapp.domain.model.questionv2.McqQuestionV2 -> state.selectedIndex != null
        is com.emir.englishapp.domain.model.questionv2.FillBlankQuestionV2 -> state.selectedIndex != null
        is com.emir.englishapp.domain.model.questionv2.ReorderQuestionV2 -> state.reorderSelected.isNotEmpty()
    }
}
