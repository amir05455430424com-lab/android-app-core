package com.emir.englishapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.navigation.compose.rememberNavController
import com.emir.englishapp.data.local.SettingsStore
import com.emir.englishapp.ui.navigation.AppNavHost
import com.emir.englishapp.ui.navigation.AppScaffold
import com.emir.englishapp.ui.theme.EnglishAppTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val settings = remember { SettingsStore(this) }
            val darkMode by settings.darkModeFlow.collectAsState(initial = false)

            EnglishAppTheme(darkTheme = darkMode) {
                val navController = rememberNavController()
                AppScaffold(
                    navController = navController,
                    title = "English App",
                ) {
                    AppNavHost(navController = navController)
                }
            }
        }
    }
}
