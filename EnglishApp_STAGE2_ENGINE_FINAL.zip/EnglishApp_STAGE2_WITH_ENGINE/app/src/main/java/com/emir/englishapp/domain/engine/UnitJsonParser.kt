package com.emir.englishapp.domain.engine

import com.emir.englishapp.domain.model.exercise.ExerciseTemplate
import com.emir.englishapp.domain.model.exercise.SortCategory
import com.emir.englishapp.domain.model.exercise.SortWord
import com.emir.englishapp.domain.model.exercise.WordPair
import com.emir.englishapp.domain.model.exercise.WordTimestamp
import org.json.JSONObject

/**
 * UnitJsonParser
 * ==============
 * Parses the Smart Assessment Engine unit JSON format (unit_engine_schema_v1)
 * into domain objects consumed by [SentenceDrillFactory] and [SessionOrchestrator].
 *
 * This is the central data bridge:
 *   JSON Asset File → UnitDefinition → SentenceDrillFactory → ExerciseTemplate list
 *
 * Usage:
 *   val raw   = repo.readAssetJsonOnce("units/unit_001_greetings_a1.json")
 *   val unit  = UnitJsonParser.parse(raw)
 *   val pool  = UnitJsonParser.generateExercises(unit, seed = System.nanoTime())
 */
object UnitJsonParser {

    // ─────────────────────────────────────────────────────────────
    // Parsed domain models
    // ─────────────────────────────────────────────────────────────

    data class UnitDefinition(
        val meta: UnitMeta,
        val sentences: List<SentenceDrillFactory.AnnotatedSentence>,
        val crossExercises: CrossExercises,
        val sessionPlan: SessionPlan,
        val srsConfig: SrsConfig,
    )

    data class UnitMeta(
        val unitId: String,
        val globalIndex: Int,
        val titleEn: String,
        val titleAr: String,
        val descriptionAr: String,
        val cefr: String,
        val topic: String,
        val sectionId: String,
        val iconRes: String,
        val xpReward: Int,
        val isVip: Boolean,
    )

    data class CrossExercises(
        val matchPairsGroups: List<MatchPairsGroup>,
        val wordSortConfigs: List<WordSortConfig>,
    )

    data class MatchPairsGroup(
        val groupId: String,
        val pairs: List<WordPair>,
    )

    data class WordSortConfig(
        val configId: String,
        val categoryA: SortCategory,
        val categoryB: SortCategory,
        val wordPool: List<SortWord>,
    )

    data class SessionPlan(
        val totalExercisesGenerated: Int,
        val sessionSize: Int,
        val newCardsPerSession: Int,
        val reviewCardsPerSession: Int,
        val passes: List<LearningPass>,
    )

    data class LearningPass(
        val passNumber: Int,
        val nameAr: String,
        val nameEn: String,
        val focusModalities: List<String>,
        val exerciseTypeWeights: Map<String, Float>,
        val masteryThresholdPercent: Int,
    )

    data class SrsConfig(
        val initialEaseFactor: Float,
        val minEaseFactor: Float,
        val maxEaseFactor: Float,
        val graduatingIntervalDays: Float,
        val easyIntervalDays: Float,
    )

    // ─────────────────────────────────────────────────────────────
    // Parsing
    // ─────────────────────────────────────────────────────────────

    fun parse(json: String): UnitDefinition {
        val root = JSONObject(json)
        return UnitDefinition(
            meta          = parseMeta(root.getJSONObject("meta")),
            sentences     = parseSentences(root),
            crossExercises = parseCrossExercises(root),
            sessionPlan   = parseSessionPlan(root.getJSONObject("session_plan")),
            srsConfig     = parseSrsConfig(root.getJSONObject("srs_config")),
        )
    }

    private fun parseMeta(obj: JSONObject) = UnitMeta(
        unitId        = obj.getString("unit_id"),
        globalIndex   = obj.getInt("global_index"),
        titleEn       = obj.getString("title_en"),
        titleAr       = obj.getString("title_ar"),
        descriptionAr = obj.optString("description_ar", ""),
        cefr          = obj.getString("cefr"),
        topic         = obj.getString("topic"),
        sectionId     = obj.optString("section_id", ""),
        iconRes       = obj.optString("icon_res", ""),
        xpReward      = obj.optInt("xp_reward", 15),
        isVip         = obj.optBoolean("is_vip", false),
    )

    private fun parseSentences(root: JSONObject): List<SentenceDrillFactory.AnnotatedSentence> {
        val arr = root.getJSONArray("sentences")
        return (0 until arr.length()).mapNotNull { i ->
            runCatching { parseSentence(arr.getJSONObject(i)) }.getOrNull()
        }
    }

    private fun parseSentence(obj: JSONObject): SentenceDrillFactory.AnnotatedSentence {
        val audioObj = obj.optJSONObject("audio")
        val timestamps = if (audioObj != null) {
            parseTimestamps(audioObj)
        } else emptyList()

        return SentenceDrillFactory.AnnotatedSentence(
            id                = obj.getString("sentence_id"),
            en                = obj.getString("en"),
            ar                = obj.getString("ar"),
            cefr              = obj.optString("cefr", "A1"),
            topic             = obj.optString("topic", "general"),
            complexityScore   = obj.optDouble("complexity_score", 0.0).toFloat(),
            audioAssetPath    = audioObj?.optString("asset_path"),
            wordTimestamps    = timestamps,
        )
    }

    private fun parseTimestamps(audioObj: JSONObject): List<WordTimestamp> {
        val arr = audioObj.optJSONArray("word_timestamps") ?: return emptyList()
        return (0 until arr.length()).mapNotNull { i ->
            runCatching {
                val ts = arr.getJSONObject(i)
                WordTimestamp(
                    word    = ts.getString("word"),
                    startMs = ts.getLong("start_ms"),
                    endMs   = ts.getLong("end_ms"),
                )
            }.getOrNull()
        }
    }

    private fun parseCrossExercises(root: JSONObject): CrossExercises {
        val cross = root.optJSONObject("cross_exercises") ?: return CrossExercises(emptyList(), emptyList())

        // Match Pairs Groups
        val mpGroups = mutableListOf<MatchPairsGroup>()
        cross.optJSONArray("match_pairs_groups")?.let { arr ->
            for (i in 0 until arr.length()) {
                val g = arr.getJSONObject(i)
                val pairs = mutableListOf<WordPair>()
                val pairsArr = g.getJSONArray("pairs")
                for (j in 0 until pairsArr.length()) {
                    val p = pairsArr.getJSONObject(j)
                    pairs += WordPair(en = p.getString("en"), ar = p.getString("ar"))
                }
                mpGroups += MatchPairsGroup(groupId = g.getString("group_id"), pairs = pairs)
            }
        }

        // Word Sort Configs
        val wsConfigs = mutableListOf<WordSortConfig>()
        cross.optJSONArray("word_sort_configs")?.let { arr ->
            for (i in 0 until arr.length()) {
                val c = arr.getJSONObject(i)
                val catA = c.getJSONObject("category_a")
                val catB = c.getJSONObject("category_b")
                val pool = mutableListOf<SortWord>()
                val poolArr = c.getJSONArray("word_pool")
                for (j in 0 until poolArr.length()) {
                    val w = poolArr.getJSONObject(j)
                    pool += SortWord(
                        text            = w.getString("text"),
                        correctCategory = w.getInt("correct_category"),
                    )
                }
                wsConfigs += WordSortConfig(
                    configId  = c.getString("config_id"),
                    categoryA = SortCategory(
                        labelEn = catA.getString("label_en"),
                        labelAr = catA.getString("label_ar"),
                    ),
                    categoryB = SortCategory(
                        labelEn = catB.getString("label_en"),
                        labelAr = catB.getString("label_ar"),
                    ),
                    wordPool  = pool,
                )
            }
        }

        return CrossExercises(matchPairsGroups = mpGroups, wordSortConfigs = wsConfigs)
    }

    private fun parseSessionPlan(obj: JSONObject): SessionPlan {
        val passesArr = obj.optJSONArray("passes")
        val passes = if (passesArr != null) {
            (0 until passesArr.length()).map { i ->
                val p = passesArr.getJSONObject(i)
                val weightsObj = p.optJSONObject("exercise_type_weights")
                val weights = if (weightsObj != null) {
                    weightsObj.keys().asSequence().associateWith { k ->
                        weightsObj.optDouble(k, 0.0).toFloat()
                    }
                } else emptyMap()
                val modalitiesArr = p.optJSONArray("focus_modalities")
                val modalities = if (modalitiesArr != null)
                    (0 until modalitiesArr.length()).map { modalitiesArr.getString(it) }
                else emptyList()
                LearningPass(
                    passNumber             = p.getInt("pass_number"),
                    nameAr                 = p.optString("name_ar", ""),
                    nameEn                 = p.optString("name_en", ""),
                    focusModalities        = modalities,
                    exerciseTypeWeights    = weights,
                    masteryThresholdPercent = p.optInt("mastery_threshold_percent", 80),
                )
            }
        } else emptyList()

        return SessionPlan(
            totalExercisesGenerated = obj.optInt("total_exercises_generated", 0),
            sessionSize             = obj.optInt("session_size", 20),
            newCardsPerSession      = obj.optInt("new_cards_per_session", 10),
            reviewCardsPerSession   = obj.optInt("review_cards_per_session", 10),
            passes                  = passes,
        )
    }

    private fun parseSrsConfig(obj: JSONObject) = SrsConfig(
        initialEaseFactor      = obj.optDouble("initial_ease_factor", 2.5).toFloat(),
        minEaseFactor          = obj.optDouble("min_ease_factor", 1.3).toFloat(),
        maxEaseFactor          = obj.optDouble("max_ease_factor", 5.0).toFloat(),
        graduatingIntervalDays = obj.optDouble("graduating_interval_days", 1.0).toFloat(),
        easyIntervalDays       = obj.optDouble("easy_interval_days", 4.0).toFloat(),
    )

    // ─────────────────────────────────────────────────────────────
    // Exercise generation from a parsed unit
    // ─────────────────────────────────────────────────────────────

    /**
     * Generate the full exercise pool for a unit.
     * Returns all variants from [SentenceDrillFactory] + authored cross-sentence exercises.
     *
     * @param unit  the parsed [UnitDefinition]
     * @param seed  RNG seed for shuffling — use [System.nanoTime()] for each new session
     */
    fun generateExercises(
        unit: UnitDefinition,
        seed: Long = System.nanoTime(),
    ): List<ExerciseTemplate> {
        val rng     = SeededRng(seed)
        val factory = SentenceDrillFactory(rng)
        val result  = mutableListOf<ExerciseTemplate>()

        // Per-sentence exercises
        unit.sentences.forEach { sentence ->
            val distractors = unit.sentences.filter { it.id != sentence.id }
            result += factory.generateAll(sentence, distractors)
        }

        // Cross-sentence: MatchPairs from authored groups
        unit.crossExercises.matchPairsGroups.forEach { group ->
            if (group.pairs.size >= 2) {
                result += ExerciseTemplate.MatchPairs(
                    id            = "mp_${group.groupId}",
                    cefr          = unit.meta.cefr,
                    difficultyScore = cefrScore(unit.meta.cefr) + group.pairs.size * 3,
                    topic         = unit.meta.topic,
                    pairs         = group.pairs,
                    explanationAr = "طابق الكلمات مع معانيها الصحيحة",
                )
            }
        }

        // Cross-sentence: WordSort from authored configs
        unit.crossExercises.wordSortConfigs.forEach { config ->
            if (config.wordPool.isNotEmpty()) {
                result += ExerciseTemplate.WordSort(
                    id            = "ws_${config.configId}",
                    cefr          = unit.meta.cefr,
                    difficultyScore = cefrScore(unit.meta.cefr) + 12,
                    topic         = unit.meta.topic,
                    categoryA     = config.categoryA,
                    categoryB     = config.categoryB,
                    wordPool      = rng.shuffle(config.wordPool.toMutableList()),
                    explanationAr = "صنّف الكلمات في المجموعة الصحيحة",
                )
            }
        }

        return result.distinctBy { it.id }
    }

    /**
     * Build a [SpacedRepetitionScheduler] pre-configured from unit's [srs_config].
     */
    fun buildScheduler(unit: UnitDefinition): SpacedRepetitionScheduler =
        SpacedRepetitionScheduler(
            newCardsPerSession    = unit.sessionPlan.newCardsPerSession,
            reviewCardsPerSession = unit.sessionPlan.reviewCardsPerSession,
        )

    /**
     * Select exercises for the current SRS pass based on pass weights.
     * Returns exercises weighted by the current [passNumber]'s [exercise_type_weights].
     */
    fun filterByPassWeights(
        exercises: List<ExerciseTemplate>,
        plan: SessionPlan,
        passNumber: Int,
        rng: SeededRng,
        targetSize: Int,
    ): List<ExerciseTemplate> {
        val pass = plan.passes.firstOrNull { it.passNumber == passNumber }
            ?: return rng.pickN(exercises, minOf(targetSize, exercises.size))

        val weights = pass.exerciseTypeWeights
        fun typeKey(ex: ExerciseTemplate): String = when (ex) {
            is ExerciseTemplate.TranslateEnToAr   -> "translate_en_to_ar"
            is ExerciseTemplate.TranslateArToEn   -> "translate_ar_to_en"
            is ExerciseTemplate.SentenceReorder   -> "sentence_reorder"
            is ExerciseTemplate.FillBlank         -> "fill_blank"
            is ExerciseTemplate.SpotTheError      -> "spot_the_error"
            is ExerciseTemplate.SentenceComplete  -> "sentence_complete"
            is ExerciseTemplate.ListenAndPick     -> "listen_and_pick"
            is ExerciseTemplate.DictationReorder  -> "dictation_reorder"
            is ExerciseTemplate.TypeWhatYouHear   -> "type_what_you_hear"
            is ExerciseTemplate.MatchPairs        -> "match_pairs"
            is ExerciseTemplate.WordSort          -> "word_sort"
            is ExerciseTemplate.PronunciationBridge -> "pronunciation_bridge"
        }

        // Weighted bucket selection
        val byType = exercises.groupBy { typeKey(it) }
        val result = mutableListOf<ExerciseTemplate>()
        val total = weights.values.sum().coerceAtLeast(0.001f)

        weights.entries.sortedByDescending { it.value }.forEach { (type, weight) ->
            if (weight <= 0f) return@forEach
            val quota = ((weight / total) * targetSize).toInt().coerceAtLeast(1)
            val pool = byType[type] ?: return@forEach
            result += rng.pickN(pool, minOf(quota, pool.size))
        }

        return result.distinctBy { it.id }.take(targetSize)
    }

    private fun cefrScore(cefr: String) = when (cefr.uppercase().take(2)) {
        "A1" -> 10; "A2" -> 25; "B1" -> 45; "B2" -> 65; "C1" -> 80; else -> 30
    }
}
