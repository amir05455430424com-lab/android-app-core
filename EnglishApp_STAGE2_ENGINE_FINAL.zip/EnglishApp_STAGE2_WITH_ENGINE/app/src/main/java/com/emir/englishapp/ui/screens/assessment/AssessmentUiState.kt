package com.emir.englishapp.ui.screens.assessment

import com.emir.englishapp.domain.engine.SessionOrchestrator
import com.emir.englishapp.domain.model.exercise.ExerciseTemplate

/**
 * AssessmentUiState — Single source of truth for the Assessment Screen.
 *
 * Produced by [AssessmentViewModel] and consumed by [AssessmentScreen].
 * All fields are immutable. State transitions are handled exclusively
 * by the ViewModel — the Screen never mutates this directly.
 */
data class AssessmentUiState(

    // ── Loading / Error ──────────────────────────────────────────
    val isLoading: Boolean = true,
    val error: String? = null,

    // ── Session identity ─────────────────────────────────────────
    val moduleTitleEn: String = "",
    val moduleTitleAr: String = "",
    val topic: String = "",
    val cefr: String = "A1",
    val sessionMode: SessionMode = SessionMode.MIXED,

    // ── Exercise snapshot (forwarded from SessionOrchestrator) ───
    val snapshot: SessionOrchestrator.SessionSnapshot = SessionOrchestrator.SessionSnapshot(),

    // ── Audio playback (for Auditory exercises) ──────────────────
    val audioState: AudioPlaybackState = AudioPlaybackState(),

    // ── Session complete ─────────────────────────────────────────
    val result: SessionResultUi? = null,

    // ── User preferences ─────────────────────────────────────────
    val favoriteIds: Set<String> = emptySet(),
    val showExplanation: Boolean = false,
)

/** Audio playback state for Auditory exercises (ListenAndPick, DictationReorder). */
data class AudioPlaybackState(
    val isPlaying: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    /** Index of the word currently being highlighted (-1 = none). */
    val activeWordIndex: Int = -1,
    /** Number of words already completed during playback. */
    val completedWordCount: Int = 0,
    val hasAudio: Boolean = false,
    val isLoading: Boolean = false,
)

/** UI-ready session result (after all exercises are answered). */
data class SessionResultUi(
    val scorePercent: Int,
    val masteryPercent: Int,
    val starsAwarded: Int,       // 0..3
    val totalXpEarned: Int,
    val correctCount: Int,
    val totalCount: Int,
    val totalTimeMs: Long,
    val incorrectExercises: List<ExerciseTemplate>,
)

enum class SessionMode {
    MIXED,      // balanced Visual + Auditory + Kinetic
    VISUAL,     // TranslateArEn, TranslateEnAr, FillBlank, SpotError
    AUDITORY,   // ListenAndPick, DictationReorder, TypeWhatYouHear
    KINETIC,    // SentenceReorder, MatchPairs, WordSort
    REVIEW,     // only previously-incorrect exercises
}

// ─────────────────────────────────────────────────────────────────────────────
// Events — the Screen communicates back to the ViewModel exclusively via events
// ─────────────────────────────────────────────────────────────────────────────

sealed interface AssessmentEvent {

    /** User tapped an MCQ option. */
    data class SelectOption(val index: Int) : AssessmentEvent

    /** User tapped a word chip to add to the reorder area. */
    data class PickWord(val word: String) : AssessmentEvent

    /** User returned a word chip to the available pool. */
    data class UnpickWord(val word: String) : AssessmentEvent

    /** User tapped a sentence token in SpotTheError. */
    data class TapToken(val index: Int) : AssessmentEvent

    /** User tapped a left-column cell in MatchPairs. */
    data class TapMatchLeft(val index: Int) : AssessmentEvent

    /** User tapped a right-column cell in MatchPairs. */
    data class TapMatchRight(val index: Int) : AssessmentEvent

    /** User dropped a word into a WordSort category. */
    data class SortWord(val word: String, val categoryIndex: Int) : AssessmentEvent

    /** User confirmed their answer (explicit confirm button). */
    object Confirm : AssessmentEvent

    /** User advanced to the next question after seeing feedback. */
    object Next : AssessmentEvent

    /** User tapped the audio play button. */
    object PlayAudio : AssessmentEvent

    /** User tapped the audio stop/replay button. */
    object StopAudio : AssessmentEvent

    /** User toggled favourite for the current exercise. */
    object ToggleFavourite : AssessmentEvent

    /** User toggled the explanation panel. */
    object ToggleExplanation : AssessmentEvent

    /** User explicitly exits the session before completion. */
    object ExitSession : AssessmentEvent

    /** User restarts the session with the same config. */
    object RestartSession : AssessmentEvent
}
