package com.emir.englishapp.ui.screens.daily

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun DailyStartScreen(
    state: DailyStartUiState,
    onBack: () -> Unit,
    onStart: (globalIndex: Int) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(onClick = onBack) { Text("رجوع") }
            Text("⚡ جلسة اليوم", style = MaterialTheme.typography.titleLarge)
        }

        if (state.isLoading) {
            Text("تحميل...", style = MaterialTheme.typography.bodyMedium)
            return
        }
        state.error?.let {
            Text(it, style = MaterialTheme.typography.bodyMedium)
            return
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("الوحدة الحالية:", style = MaterialTheme.typography.labelLarge)
                Text(state.unitTitleEn, style = MaterialTheme.typography.titleMedium)
                Text(state.unitTitleAr, style = MaterialTheme.typography.bodyMedium)
                Text("مكافأة XP: ${state.xpReward}", style = MaterialTheme.typography.bodyMedium)
            }
        }

        if (state.isDoneToday) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("✅ أنهيت جلسة اليوم!", style = MaterialTheme.typography.titleMedium)
                    Text("تقدر تكمل على المسار أو تعمل تدريب إضافي.", style = MaterialTheme.typography.bodyMedium)
                }
            }
        }

        Spacer(Modifier.height(6.dp))

        Button(
            onClick = { onStart(state.currentGlobalIndex) },
            modifier = Modifier.fillMaxWidth()
        ) { Text("ابدأ") }
    }
}
